# SPDX-FileCopyrightText: 2023-2024 AIM GmbH <info@aim-online.com>
# SPDX-License-Identifier: MIT

"""1553 and generic structures used for the MIL API."""

import copy
import ctypes

from . import mil_bindings as amb
from . import mil_bindings_types as ambt
from . import mil_bindings_defines as ambd

class PY_TY_API_BC_ACYC(object):
    def __init__(self, cnt = 0, instr = None, xid = None):
        self.cnt = cnt # <class 'ctypes.c_ubyte'>
        self.padding1 = 0 # <class 'ctypes.c_ubyte'>
        self.instr = [] if instr == None else instr # <class 'mil_bindings.c_ushort_Array_127'>
        self.xid = [] if instr == None else xid # <class 'mil_bindings.c_ushort_Array_127'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.cnt, [struct.instr[i] for i in range(struct.cnt)], [struct.xid[i] for i in range(struct.cnt)])
    
    def toStruct(self):
        struct = amb.ty_api_bc_acyc()
        struct.cnt = self.cnt
        struct.padding1 = 0
        for i in range(self.cnt):
            struct.instr[i] = self.instr[i]
        for i in range(self.cnt):
            struct.xid[i] = self.xid[i]
        return struct


class PY_TY_API_BC_BH_INFO(object):
    def __init__(self, bid = 0, sid = 0, eid = 0, nbufs = 0, hid_addr = 0, bq_addr = 0, sq_addr = 0, eq_addr = 0):
        self.bid = bid # <class 'ctypes.c_ushort'>
        self.sid = sid # <class 'ctypes.c_ushort'>
        self.eid = eid # <class 'ctypes.c_ushort'>
        self.nbufs = nbufs # <class 'ctypes.c_ushort'>
        self.hid_addr = hid_addr # <class 'ctypes.c_ulong'>
        self.bq_addr = bq_addr # <class 'ctypes.c_ulong'>
        self.sq_addr = sq_addr # <class 'ctypes.c_ulong'>
        self.eq_addr = eq_addr # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.bid, struct.sid, struct.eid, struct.nbufs, struct.hid_addr, struct.bq_addr, struct.sq_addr, struct.eq_addr)
    
    def toStruct(self):
        struct = amb.ty_api_bc_bh_info()
        struct.bid = self.bid
        struct.sid = self.sid
        struct.eid = self.eid
        struct.nbufs = self.nbufs
        struct.hid_addr = self.hid_addr
        struct.bq_addr = self.bq_addr
        struct.sq_addr = self.sq_addr
        struct.eq_addr = self.eq_addr
        return struct


class PY_TY_API_BC_DYTAG(object):
    def __init__(self, tag_fct = 0, min = 0, max = 0, step = 0, wpos = 0):
        self.tag_fct = tag_fct # <class 'ctypes.c_ushort'>
        self.min = min # <class 'ctypes.c_ushort'>
        self.max = max # <class 'ctypes.c_ushort'>
        self.step = step # <class 'ctypes.c_ushort'>
        self.wpos = wpos # <class 'ctypes.c_ushort'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.tag_fct, struct.min, struct.max, struct.step, struct.wpos)
    
    def toStruct(self):
        struct = amb.ty_api_bc_dytag()
        struct.tag_fct = self.tag_fct
        struct.min = self.min
        struct.max = self.max
        struct.step = self.step
        struct.wpos = self.wpos
        return struct


class PY_TY_API_BC_ERR(object):
    def __init__(self, type = 0, sync = 0, contig = 0, err_spec = 0):
        self.type = type # <class 'ctypes.c_ubyte'>
        self.sync = sync # <class 'ctypes.c_ubyte'>
        self.contig = contig # <class 'ctypes.c_ubyte'>
        self.padding1 = 0 # <class 'ctypes.c_ubyte'>
        self.err_spec = err_spec # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.type, struct.sync, struct.contig, struct.err_spec)
    
    def toStruct(self):
        struct = amb.ty_api_bc_err()
        struct.type = self.type
        struct.sync = self.sync
        struct.contig = self.contig
        struct.padding1 = self.padding1
        struct.err_spec = self.err_spec
        return struct


class PY_TY_API_BC_ERROR(object):
    def __init__(self, ul_Type = 0, ul_Sync = 0, ul_Contig = 0, ul_ErrSpec = 0):
        self.ul_Type = ul_Type # <class 'ctypes.c_ulong'>
        self.ul_Sync = ul_Sync # <class 'ctypes.c_ulong'>
        self.ul_Contig = ul_Contig # <class 'ctypes.c_ulong'>
        self.ul_Padding1 = 0 # <class 'ctypes.c_ulong'>
        self.ul_ErrSpec = ul_ErrSpec # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_Type, struct.ul_Sync, struct.ul_Contig, struct.ul_ErrSpec)
    
    def toStruct(self):
        struct = amb.ty_api_bc_error()
        struct.ul_Type = self.ul_Type
        struct.ul_Sync = self.ul_Sync
        struct.ul_Contig = self.ul_Contig
        struct.ul_Padding1 = self.ul_Padding1
        struct.ul_ErrSpec = self.ul_ErrSpec
        return struct


class PY_TY_API_BC_FRAME(object):
    def __init__(self, id = 0, cnt = 0, instr = None, xid = None):
        self.id = id # <class 'ctypes.c_ubyte'>
        self.cnt = cnt # <class 'ctypes.c_ubyte'>
        self.instr = [] if instr == None else instr # <class 'mil_bindings.c_ushort_Array_128'>
        self.xid = [] if xid == None else xid # <class 'mil_bindings.c_ushort_Array_128'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.id, struct.cnt, [struct.instr[i] for i in range(struct.cnt)], [struct.xid[i] for i in range(struct.cnt)])
    
    def toStruct(self):
        struct = amb.ty_api_bc_frame()
        struct.id = self.id
        struct.cnt = self.cnt
        for i in range(self.cnt):
            struct.instr[i] = self.instr[i]
        for i in range(self.cnt):
            struct.xid[i] = self.xid[i]

        return struct


class PY_TY_API_BC_FW_INSTR(object):
    def __init__(self, label = 0, op = 0, res = 0, par1 = 0, par2 = 0, laddr = 0):
        self.label = label # <class 'ctypes.c_ushort'>
        self.op = op # <class 'ctypes.c_ubyte'>
        self.res = res # <class 'ctypes.c_ubyte'>
        self.par1 = par1 # <class 'ctypes.c_ulong'>
        self.par2 = par2 # <class 'ctypes.c_ulong'>
        self.laddr = laddr # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.label, struct.op, struct.res, struct.par1, struct.par2, struct.laddr)
    
    def toStruct(self):
        struct = amb.ty_api_bc_fw_instr()
        struct.label = self.label
        struct.op = self.op
        struct.res = self.res
        struct.par1 = self.par1
        struct.par2 = self.par2
        struct.laddr = self.laddr
        return struct


class PY_TY_API_BC_FW_RSRC_DESC(object):
    def __init__(self, max_cnt = 0, start_addr = 0):
        self.max_cnt = max_cnt # <class 'ctypes.c_ulong'>
        self.start_addr = start_addr # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.max_cnt, struct.start_addr)
    
    def toStruct(self):
        struct = amb.ty_api_bc_fw_rsrc_desc()
        struct.max_cnt = self.max_cnt
        struct.start_addr = self.start_addr
        return struct


class PY_TY_API_BC_MFRAME(object):
    def __init__(self, cnt = 0, fid = None):
        self.cnt = cnt # <class 'ctypes.c_ubyte'>
        self.fid = [] if fid == None else fid # <class 'mil_bindings.c_ubyte_Array_64'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.cnt, [struct.fid[i] for i in range(struct.cnt)])
    
    def toStruct(self):
        struct = amb.ty_api_bc_mframe()
        struct.cnt = self.cnt
        for i in range(min(self.cnt, len(struct.fid))):
            struct.fid[i] = self.fid[i]
        return struct


class PY_TY_API_BC_MFRAME_EX(object):
    def __init__(self, cnt = 0, fid = None):
        self.cnt = cnt # <class 'ctypes.c_ushort'>
        self.padding1 = 0 # <class 'ctypes.c_ushort'>
        self.fid = [] if fid == None else fid # <class 'mil_bindings.c_ubyte_Array_512'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.cnt, [struct.fid[i] for i in range(struct.cnt)] )
    
    def toStruct(self):
        struct = amb.ty_api_bc_mframe_ex()
        struct.cnt = self.cnt
        struct.padding1 = self.padding1
        for i in range(min(self.cnt, len(struct.fid))):
            struct.fid[i] = self.fid[i]
        return struct


class PY_TY_API_BC_MODE_CTRL(object):
    def __init__(self, ul_BcMode = 0, ul_Ctrl = 0, ul_Param1 = 0, ul_Param2 = 0, ul_Param3 = 0):
        self.ul_BcMode = ul_BcMode # <class 'ctypes.c_ulong'>
        self.ul_Ctrl = ul_Ctrl # <class 'ctypes.c_ulong'>
        self.ul_Param1 = ul_Param1 # <class 'ctypes.c_ulong'>
        self.ul_Param2 = ul_Param2 # <class 'ctypes.c_ulong'>
        self.ul_Param3 = ul_Param3 # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_BcMode, struct.ul_Ctrl, struct.ul_Param1, struct.ul_Param2, struct.ul_Param3)
    
    def toStruct(self):
        struct = amb.ty_api_bc_mode_ctrl()
        struct.ul_BcMode = self.ul_BcMode
        struct.ul_Ctrl = self.ul_Ctrl
        struct.ul_Param1 = self.ul_Param1
        struct.ul_Param2 = self.ul_Param2
        struct.ul_Param3 = self.ul_Param3
        return struct


class PY_TY_API_BC_MODIFY_INSTRUCTION(object):
    def __init__(self, type = 0, compare_control = 0, write_type = 0, arithmetic_operation = 0, re_load = 0, operand = 0, compare_word_source_offset = 0, destination_offset = 0, mask_word = 0, compare_word = 0, destination_argument = 0):
        self.type = type # <class 'ctypes.c_ulong'>
        self.compare_control = compare_control # <class 'ctypes.c_ulong'>
        self.write_type = write_type # <class 'ctypes.c_ulong'>
        self.arithmetic_operation = arithmetic_operation # <class 'ctypes.c_ulong'>
        self.re_load = re_load # <class 'ctypes.c_ulong'>
        self.operand = operand # <class 'ctypes.c_ulong'>
        self.compare_word_source_offset = compare_word_source_offset # <class 'ctypes.c_ulong'>
        self.destination_offset = destination_offset # <class 'ctypes.c_ulong'>
        self.mask_word = mask_word # <class 'ctypes.c_ulong'>
        self.compare_word = compare_word # <class 'ctypes.c_ulong'>
        self.destination_argument = destination_argument # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.type, struct.compare_control, struct.write_type, struct.arithmetic_operation, struct.re_load, struct.operand, struct.compare_word_source_offset, struct.destination_offset, struct.mask_word, struct.compare_word, struct.destination_argument)
    
    def toStruct(self):
        struct = amb.ty_api_bc_modify_instruction()
        struct.type = self.type
        struct.compare_control = self.compare_control
        struct.write_type = self.write_type
        struct.arithmetic_operation = self.arithmetic_operation
        struct.re_load = self.re_load
        struct.operand = self.operand
        struct.compare_word_source_offset = self.compare_word_source_offset
        struct.destination_offset = self.destination_offset
        struct.mask_word = self.mask_word
        struct.compare_word = self.compare_word
        struct.destination_argument = self.destination_argument
        return struct


class PY_TY_API_BC_SRVW(object):
    def __init__(self, uw_XferId = 0, uw_LastVecWord = 0, ul_SrvReqCnt = 0):
        self.uw_XferId = uw_XferId # <class 'ctypes.c_ushort'>
        self.uw_LastVecWord = uw_LastVecWord # <class 'ctypes.c_ushort'>
        self.ul_SrvReqCnt = ul_SrvReqCnt # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.uw_XferId, struct.uw_LastVecWord, struct.ul_SrvReqCnt)
    
    def toStruct(self):
        struct = amb.ty_api_bc_srvw()
        struct.uw_XferId = self.uw_XferId
        struct.uw_LastVecWord = self.uw_LastVecWord
        struct.ul_SrvReqCnt = self.ul_SrvReqCnt
        return struct


class PY_TY_API_BC_SRVW_CON(object):
    def __init__(self, uc_SubAddress = 0, uc_Padding1 = 0, uw_Padding2 = 0, ul_Reserved1 = 0, ul_Reserved2 = 0, ul_Reserved3 = 0):
        self.uc_SubAddress = uc_SubAddress # <class 'ctypes.c_ubyte'>
        self.uc_Padding1 = uc_Padding1 # <class 'ctypes.c_ubyte'>
        self.uw_Padding2 = uw_Padding2 # <class 'ctypes.c_ushort'>
        self.ul_Reserved1 = ul_Reserved1 # <class 'ctypes.c_ulong'>
        self.ul_Reserved2 = ul_Reserved2 # <class 'ctypes.c_ulong'>
        self.ul_Reserved3 = ul_Reserved3 # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.uc_SubAddress, struct.uc_Padding1, struct.uw_Padding2, struct.ul_Reserved1, struct.ul_Reserved2, struct.ul_Reserved3)
    
    def toStruct(self):
        struct = amb.ty_api_bc_srvw_con()
        struct.uc_SubAddress = self.uc_SubAddress
        struct.uc_Padding1 = self.uc_Padding1
        struct.uw_Padding2 = self.uw_Padding2
        struct.ul_Reserved1 = self.ul_Reserved1
        struct.ul_Reserved2 = self.ul_Reserved2
        struct.ul_Reserved3 = self.ul_Reserved3
        return struct


class PY_TY_API_BC_STATUS_DSP(object):
    def __init__(self, status = 0, padding1 = 0, hxfer = 0, glb_msg_cnt = 0, glb_err_cnt = 0, hip = 0, mfc = 0):
        self.status = status # <class 'ctypes.c_ubyte'>
        self.padding1 = padding1 # <class 'ctypes.c_ubyte'>
        self.hxfer = hxfer # <class 'ctypes.c_ushort'>
        self.glb_msg_cnt = glb_msg_cnt # <class 'ctypes.c_ulong'>
        self.glb_err_cnt = glb_err_cnt # <class 'ctypes.c_ulong'>
        self.hip = hip # <class 'ctypes.c_ulong'>
        self.mfc = mfc # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.status, struct.padding1, struct.hxfer, struct.glb_msg_cnt, struct.glb_err_cnt, struct.hip, struct.mfc)
    
    def toStruct(self):
        struct = amb.ty_api_bc_status_dsp()
        struct.status = self.status
        struct.padding1 = self.padding1
        struct.hxfer = self.hxfer
        struct.glb_msg_cnt = self.glb_msg_cnt
        struct.glb_err_cnt = self.glb_err_cnt
        struct.hip = self.hip
        struct.mfc = self.mfc
        return struct


class PY_TY_API_BC_XFER_DSP(object):
    def __init__(self, cw1 = 0, st1 = 0, cw2 = 0, st2 = 0, bid = 0, brw = 0, bufp = 0, ttag = 0, msg_cnt = 0, err_cnt = 0, lvw = 0, srvreq_cnt = 0):
        self.cw1 = cw1 # <class 'ctypes.c_ushort'>
        self.st1 = st1 # <class 'ctypes.c_ushort'>
        self.cw2 = cw2 # <class 'ctypes.c_ushort'>
        self.st2 = st2 # <class 'ctypes.c_ushort'>
        self.bid = bid # <class 'ctypes.c_ushort'>
        self.brw = brw # <class 'ctypes.c_ushort'>
        self.bufp = bufp # <class 'ctypes.c_ulong'>
        self.ttag = ttag # <class 'ctypes.c_ulong'>
        self.msg_cnt = msg_cnt # <class 'ctypes.c_ulong'>
        self.err_cnt = err_cnt # <class 'ctypes.c_ulong'>
        self.lvw = lvw # <class 'ctypes.c_ulong'>
        self.srvreq_cnt = srvreq_cnt # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.cw1, struct.st1, struct.cw2, struct.st2, struct.bid, struct.brw, struct.bufp, struct.ttag, struct.msg_cnt, struct.err_cnt, struct.lvw, struct.srvreq_cnt)
    
    def toStruct(self):
        struct = amb.ty_api_bc_xfer_dsp()
        struct.cw1 = self.cw1
        struct.st1 = self.st1
        struct.cw2 = self.cw2
        struct.st2 = self.st2
        struct.bid = self.bid
        struct.brw = self.brw
        struct.bufp = self.bufp
        struct.ttag = self.ttag
        struct.msg_cnt = self.msg_cnt
        struct.err_cnt = self.err_cnt
        struct.lvw = self.lvw
        struct.srvreq_cnt = self.srvreq_cnt
        return struct


class PY_TY_API_BC_XFER_EVENT_QUEUE(object):
    def __init__(self, ul_EqEntryWord1 = 0, ul_EqEntryWord2 = 0, ul_EqEntryWord3 = 0, ul_EqEntryWord4 = 0):
        self.ul_EqEntryWord1 = ul_EqEntryWord1 # <class 'ctypes.c_ulong'>
        self.ul_EqEntryWord2 = ul_EqEntryWord2 # <class 'ctypes.c_ulong'>
        self.ul_EqEntryWord3 = ul_EqEntryWord3 # <class 'ctypes.c_ulong'>
        self.ul_EqEntryWord4 = ul_EqEntryWord4 # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_EqEntryWord1, struct.ul_EqEntryWord2, struct.ul_EqEntryWord3, struct.ul_EqEntryWord4)
    
    def toStruct(self):
        struct = amb.ty_api_bc_xfer_event_queue()
        struct.ul_EqEntryWord1 = self.ul_EqEntryWord1
        struct.ul_EqEntryWord2 = self.ul_EqEntryWord2
        struct.ul_EqEntryWord3 = self.ul_EqEntryWord3
        struct.ul_EqEntryWord4 = self.ul_EqEntryWord4
        return struct


class PY_TY_API_BC_XFER_READ_IN(object):
    def __init__(self, ul_XferId = 0, ul_Clear = 0x7):
        self.ul_XferId = ul_XferId # <class 'ctypes.c_ulong'>
        self.ul_Clear = ul_Clear # <class 'ctypes.c_ulong'>
        self.ul_Biu = 0 # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_XferId, struct.ul_Clear)
    
    def toStruct(self):
        struct = amb.ty_api_bc_xfer_read_in()
        struct.ul_XferId = self.ul_XferId
        struct.ul_Clear = self.ul_Clear
        struct.ul_Biu = self.ul_Biu
        return struct


class PY_TY_API_BC_XFER_STATUS_INFO(object):
    def __init__(self, ul_ActBufferId = 0, ul_ActionWord = 0, ul_XferCnt = 0, ul_ErrCnt = 0, ul_LastVectorWord = 0, ul_ServiceRequestCnt = 0):
        self.ul_ActBufferId = ul_ActBufferId # <class 'ctypes.c_ulong'>
        self.ul_ActionWord = ul_ActionWord # <class 'ctypes.c_ulong'>
        self.ul_XferCnt = ul_XferCnt # <class 'ctypes.c_ulong'>
        self.ul_ErrCnt = ul_ErrCnt # <class 'ctypes.c_ulong'>
        self.ul_LastVectorWord = ul_LastVectorWord # <class 'ctypes.c_ulong'>
        self.ul_ServiceRequestCnt = ul_ServiceRequestCnt # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_ActBufferId, struct.ul_ActionWord, struct.ul_XferCnt, struct.ul_ErrCnt, struct.ul_LastVectorWord, struct.ul_ServiceRequestCnt)
    
    def toStruct(self):
        struct = amb.ty_api_bc_xfer_status_info()
        struct.ul_ActBufferId = self.ul_ActBufferId
        struct.ul_ActionWord = self.ul_ActionWord
        struct.ul_XferCnt = self.ul_XferCnt
        struct.ul_ErrCnt = self.ul_ErrCnt
        struct.ul_LastVectorWord = self.ul_LastVectorWord
        struct.ul_ServiceRequestCnt = self.ul_ServiceRequestCnt
        return struct


class PY_TY_API_BC_XFER_STATUS_QUEUE(object):
    def __init__(self, ul_SqCtrlWord = 0, ul_SqStatusWords = 0, ul_SqActBufPtr = 0, ul_SqTimeTag = 0):
        self.ul_SqCtrlWord = ul_SqCtrlWord # <class 'ctypes.c_ulong'>
        self.ul_SqStatusWords = ul_SqStatusWords # <class 'ctypes.c_ulong'>
        self.ul_SqActBufPtr = ul_SqActBufPtr # <class 'ctypes.c_ulong'>
        self.ul_SqTimeTag = ul_SqTimeTag # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_SqCtrlWord, struct.ul_SqStatusWords, struct.ul_SqActBufPtr, struct.ul_SqTimeTag)
    
    def toStruct(self):
        struct = amb.ty_api_bc_xfer_status_queue()
        struct.ul_SqCtrlWord = self.ul_SqCtrlWord
        struct.ul_SqStatusWords = self.ul_SqStatusWords
        struct.ul_SqActBufPtr = self.ul_SqActBufPtr
        struct.ul_SqTimeTag = self.ul_SqTimeTag
        return struct


class PY_TY_API_BH_MODIFY(object):
    def __init__(self, ul_BHAddr = 0, ul_DataBufferStoreMode = 0, ul_BufferSizeMode = 0xFFFFFFFF, ul_BufferSize = 0, ul_BufferQueueMode = 0, ul_BufferQueueSize = 0, ul_StatusQueueSize = 0xFFFFFFFF, ul_EventQueueSize = 0xFFFFFFFF, ul_CurrentBufferIndex = 0):
        self.ul_BHAddr = ul_BHAddr # <class 'ctypes.c_ulong'>
        self.ul_DataBufferStoreMode = ul_DataBufferStoreMode # <class 'ctypes.c_ulong'>
        self.ul_BufferSizeMode = ul_BufferSizeMode # <class 'ctypes.c_ulong'>
        self.ul_BufferSize = ul_BufferSize # <class 'ctypes.c_ulong'>
        self.ul_BufferQueueMode = ul_BufferQueueMode # <class 'ctypes.c_ulong'>
        self.ul_BufferQueueSize = ul_BufferQueueSize # <class 'ctypes.c_ulong'>
        self.ul_StatusQueueSize = ul_StatusQueueSize # <class 'ctypes.c_ulong'>
        self.ul_EventQueueSize = ul_EventQueueSize # <class 'ctypes.c_ulong'>
        self.ul_CurrentBufferIndex = ul_CurrentBufferIndex # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_BHAddr, struct.ul_DataBufferStoreMode, struct.ul_BufferSizeMode, struct.ul_BufferSize, struct.ul_BufferQueueMode, struct.ul_BufferQueueSize, struct.ul_StatusQueueSize, struct.ul_EventQueueSize, struct.ul_CurrentBufferIndex)
    
    def toStruct(self):
        struct = amb.ty_api_bh_modify()
        struct.ul_BHAddr = self.ul_BHAddr
        struct.ul_DataBufferStoreMode = self.ul_DataBufferStoreMode
        struct.ul_BufferSizeMode = self.ul_BufferSizeMode
        struct.ul_BufferSize = self.ul_BufferSize
        struct.ul_BufferQueueMode = self.ul_BufferQueueMode
        struct.ul_BufferQueueSize = self.ul_BufferQueueSize
        struct.ul_StatusQueueSize = self.ul_StatusQueueSize
        struct.ul_EventQueueSize = self.ul_EventQueueSize
        struct.ul_CurrentBufferIndex = self.ul_CurrentBufferIndex
        return struct


class PY_TY_API_BM_ACT_DSP(object):
    def __init__(self, fnd = 0, rt = 0, tr = 0, sa = 0, cc = 0, ec = 0, et = 0):
        self.fnd = fnd # <class 'ctypes.c_ubyte'>
        self.rt = rt # <class 'ctypes.c_ubyte'>
        self.tr = tr # <class 'ctypes.c_ubyte'>
        self.sa = sa # <class 'ctypes.c_ubyte'>
        self.cc = cc # <class 'ctypes.c_ulong'>
        self.ec = ec # <class 'ctypes.c_ulong'>
        self.et = et # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.fnd, struct.rt, struct.tr, struct.sa, struct.cc, struct.ec, struct.et)
    
    def toStruct(self):
        struct = amb.ty_api_bm_act_dsp()
        struct.fnd = self.fnd
        struct.rt = self.rt
        struct.tr = self.tr
        struct.sa = self.sa
        struct.cc = self.cc
        struct.ec = self.ec
        struct.et = self.et
        return struct


class PY_TY_API_BM_CAP_SETUP(object):
    def __init__(self, cap_mode = 0, cap_tat = 0, cap_mcc = 0, cap_fsize = 0):
        self.cap_mode = cap_mode # <class 'ctypes.c_ubyte'>
        self.padding1 = 0 # <class 'ctypes.c_ubyte'>
        self.padding2 = 0 # <class 'ctypes.c_ushort'>
        self.cap_tat = cap_tat # <class 'ctypes.c_ulong'>
        self.cap_mcc = cap_mcc # <class 'ctypes.c_ushort'>
        self.cap_fsize = cap_fsize # <class 'ctypes.c_ushort'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.cap_mode, struct.cap_tat, struct.cap_mcc, struct.cap_fsize)
    
    def toStruct(self):
        struct = amb.ty_api_bm_cap_setup()
        struct.cap_mode = self.cap_mode
        struct.padding1 = self.padding1
        struct.padding2 = self.padding2
        struct.cap_tat = self.cap_tat
        struct.cap_mcc = self.cap_mcc
        struct.cap_fsize = self.cap_fsize
        return struct


class PY_TY_API_BM_DYTAG_MON_ACT(object):
    def __init__(self, ul_Stale = 0, ul_Bad = 0, ul_Good = 0):
        self.ul_Stale = ul_Stale # <class 'ctypes.c_ulong'>
        self.ul_Bad = ul_Bad # <class 'ctypes.c_ulong'>
        self.ul_Good = ul_Good # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_Stale, struct.ul_Bad, struct.ul_Good)
    
    def toStruct(self):
        struct = amb.ty_api_bm_dytag_mon_act()
        struct.ul_Stale = self.ul_Stale
        struct.ul_Bad = self.ul_Bad
        struct.ul_Good = self.ul_Good
        return struct


class PY_TY_API_BM_DYTAG_MON_DEF(object):
    def __init__(self, uc_Id = 0, uc_Con = 0, uc_RtAddr = 0, uc_SubAddrMsgId = 0, uc_SubAddrMsgIdType = 0, uc_Padding1 = 0, uw_DytagType = 0, uw_DytagWPos = 0, uw_DytagBPos = 0, uw_DytagBLen = 0, uw_DytagStep = 0):
        self.uc_Id = uc_Id # <class 'ctypes.c_ubyte'>
        self.uc_Con = uc_Con # <class 'ctypes.c_ubyte'>
        self.uc_RtAddr = uc_RtAddr # <class 'ctypes.c_ubyte'>
        self.uc_SubAddrMsgId = uc_SubAddrMsgId # <class 'ctypes.c_ubyte'>
        self.uc_SubAddrMsgIdType = uc_SubAddrMsgIdType # <class 'ctypes.c_ubyte'>
        self.uc_Padding1 = uc_Padding1 # <class 'ctypes.c_ubyte'>
        self.uw_DytagType = uw_DytagType # <class 'ctypes.c_ushort'>
        self.uw_DytagWPos = uw_DytagWPos # <class 'ctypes.c_ushort'>
        self.uw_DytagBPos = uw_DytagBPos # <class 'ctypes.c_ushort'>
        self.uw_DytagBLen = uw_DytagBLen # <class 'ctypes.c_ushort'>
        self.uw_DytagStep = uw_DytagStep # <class 'ctypes.c_ushort'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.uc_Id, struct.uc_Con, struct.uc_RtAddr, struct.uc_SubAddrMsgId, struct.uc_SubAddrMsgIdType, struct.uc_Padding1, struct.uw_DytagType, struct.uw_DytagWPos, struct.uw_DytagBPos, struct.uw_DytagBLen, struct.uw_DytagStep)
    
    def toStruct(self):
        struct = amb.ty_api_bm_dytag_mon_def()
        struct.uc_Id = self.uc_Id
        struct.uc_Con = self.uc_Con
        struct.uc_RtAddr = self.uc_RtAddr
        struct.uc_SubAddrMsgId = self.uc_SubAddrMsgId
        struct.uc_SubAddrMsgIdType = self.uc_SubAddrMsgIdType
        struct.uc_Padding1 = self.uc_Padding1
        struct.uw_DytagType = self.uw_DytagType
        struct.uw_DytagWPos = self.uw_DytagWPos
        struct.uw_DytagBPos = self.uw_DytagBPos
        struct.uw_DytagBLen = self.uw_DytagBLen
        struct.uw_DytagStep = self.uw_DytagStep
        return struct


class PY_TY_API_BM_DYTAG_MON_READ_CTRL(object):
    def __init__(self, uc_Id = 0):
        self.uc_Id = uc_Id # <class 'ctypes.c_ubyte'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.uc_Id)
    
    def toStruct(self):
        struct = amb.ty_api_bm_dytag_mon_read_ctrl()
        struct.uc_Id = self.uc_Id
        return struct


class PY_TY_API_BM_INI_MSG_FLT_REC(object):
    def __init__(self, cw = 0, pos1 = 0, pos2 = 0):
        self.cw = cw # <class 'ctypes.c_ushort'>
        self.pos1 = pos1 # <class 'ctypes.c_ubyte'>
        self.pos2 = pos2 # <class 'ctypes.c_ubyte'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.cw, struct.pos1, struct.pos2)
    
    def toStruct(self):
        struct = amb.ty_api_bm_ini_msg_flt_rec()
        struct.cw = self.cw
        struct.pos1 = self.pos1
        struct.pos2 = self.pos2
        return struct


class PY_TY_API_BM_REC(object):
    def __init__(self, status = 0, padding1 = 0, padding2 = 0, hfi_cnt = 0, saddr = 0, size = 0):
        self.status = status # <class 'ctypes.c_ubyte'>
        self.padding1 = padding1 # <class 'ctypes.c_ubyte'>
        self.padding2 = padding2 # <class 'ctypes.c_ushort'>
        self.hfi_cnt = hfi_cnt # <class 'ctypes.c_ulong'>
        self.saddr = saddr # <class 'ctypes.c_ulong'>
        self.size = size # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.status, struct.padding1, struct.padding2, struct.hfi_cnt, struct.saddr, struct.size)
    
    def toStruct(self):
        struct = amb.ty_api_bm_rec()
        struct.status = self.status
        struct.padding1 = self.padding1
        struct.padding2 = self.padding2
        struct.hfi_cnt = self.hfi_cnt
        struct.saddr = self.saddr
        struct.size = self.size
        return struct


class PY_TY_API_BM_RT_ACT(object):
    def __init__(self, mc = 0, ec = 0, et = 0):
        self.mc = mc # <class 'ctypes.c_ulong'>
        self.ec = ec # <class 'ctypes.c_ulong'>
        self.et = et # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.mc, struct.ec, struct.et)
    
    def toStruct(self):
        struct = amb.ty_api_bm_rt_act()
        struct.mc = self.mc
        struct.ec = self.ec
        struct.et = self.et
        return struct


class PY_TY_API_BM_STACK_DSP(object):
    def __init__(self, entry = 0):
        self.entry = entry # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.entry)
    
    def toStruct(self):
        struct = amb.ty_api_bm_stack_dsp()
        struct.entry = self.entry
        return struct


class PY_TY_API_BM_STACK_FND(object):
    def __init__(self, efnd = 0, padding1 = 0, padding2 = 0, eptr = 0, entry = 0):
        self.efnd = efnd # <class 'ctypes.c_ubyte'>
        self.padding1 = padding1 # <class 'ctypes.c_ubyte'>
        self.padding2 = padding2 # <class 'ctypes.c_ushort'>
        self.eptr = eptr # <class 'ctypes.c_ulong'>
        self.entry = entry # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.efnd, struct.padding1, struct.padding2, struct.eptr, struct.entry)
    
    def toStruct(self):
        struct = amb.ty_api_bm_stack_fnd()
        struct.efnd = self.efnd
        struct.padding1 = self.padding1
        struct.padding2 = self.padding2
        struct.eptr = self.eptr
        struct.entry = self.entry
        return struct


class PY_TY_API_BM_STACKP_DSP(object):
    def __init__(self, status = 0, padding1 = 0, padding2 = 0, stp = 0, ctp = 0, etp = 0):
        self.status = status # <class 'ctypes.c_ubyte'>
        self.padding1 = padding1 # <class 'ctypes.c_ubyte'>
        self.padding2 = padding2 # <class 'ctypes.c_ushort'>
        self.stp = stp # <class 'ctypes.c_ulong'>
        self.ctp = ctp # <class 'ctypes.c_ulong'>
        self.etp = etp # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.status, struct.padding1, struct.padding2, struct.stp, struct.ctp, struct.etp)
    
    def toStruct(self):
        struct = amb.ty_api_bm_stackp_dsp()
        struct.status = self.status
        struct.padding1 = self.padding1
        struct.padding2 = self.padding2
        struct.stp = self.stp
        struct.ctp = self.ctp
        struct.etp = self.etp
        return struct


class PY_TY_API_BM_STATUS_DSP(object):
    def __init__(self, men = 0, msw = 0, msp = 0, padding1 = 0, glb_msg_cnt = 0, glb_err_cnt = 0, glb_word_cnt_sec = 0, glb_word_cnt_pri = 0, glb_msg_cnt_sec = 0, glb_msg_cnt_pri = 0, glb_err_cnt_sec = 0, glb_err_cnt_pri = 0, bus_load_sec = 0, bus_load_pri = 0, bus_load_sec_avg = 0, bus_load_pri_avg = 0):
        self.men = men # <class 'ctypes.c_ubyte'>
        self.msw = msw # <class 'ctypes.c_ubyte'>
        self.msp = msp # <class 'ctypes.c_ubyte'>
        self.padding1 = padding1 # <class 'ctypes.c_ubyte'>
        self.glb_msg_cnt = glb_msg_cnt # <class 'ctypes.c_ulong'>
        self.glb_err_cnt = glb_err_cnt # <class 'ctypes.c_ulong'>
        self.glb_word_cnt_sec = glb_word_cnt_sec # <class 'ctypes.c_ulong'>
        self.glb_word_cnt_pri = glb_word_cnt_pri # <class 'ctypes.c_ulong'>
        self.glb_msg_cnt_sec = glb_msg_cnt_sec # <class 'ctypes.c_ulong'>
        self.glb_msg_cnt_pri = glb_msg_cnt_pri # <class 'ctypes.c_ulong'>
        self.glb_err_cnt_sec = glb_err_cnt_sec # <class 'ctypes.c_ulong'>
        self.glb_err_cnt_pri = glb_err_cnt_pri # <class 'ctypes.c_ulong'>
        self.bus_load_sec = bus_load_sec # <class 'ctypes.c_ulong'>
        self.bus_load_pri = bus_load_pri # <class 'ctypes.c_ulong'>
        self.bus_load_sec_avg = bus_load_sec_avg # <class 'ctypes.c_ulong'>
        self.bus_load_pri_avg = bus_load_pri_avg # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.men, struct.msw, struct.msp, struct.padding1, struct.glb_msg_cnt, struct.glb_err_cnt, struct.glb_word_cnt_sec, struct.glb_word_cnt_pri, struct.glb_msg_cnt_sec, struct.glb_msg_cnt_pri, struct.glb_err_cnt_sec, struct.glb_err_cnt_pri, struct.bus_load_sec, struct.bus_load_pri, struct.bus_load_sec_avg, struct.bus_load_pri_avg)
    
    def toStruct(self):
        struct = amb.ty_api_bm_status_dsp()
        struct.men = self.men
        struct.msw = self.msw
        struct.msp = self.msp
        struct.padding1 = self.padding1
        struct.glb_msg_cnt = self.glb_msg_cnt
        struct.glb_err_cnt = self.glb_err_cnt
        struct.glb_word_cnt_sec = self.glb_word_cnt_sec
        struct.glb_word_cnt_pri = self.glb_word_cnt_pri
        struct.glb_msg_cnt_sec = self.glb_msg_cnt_sec
        struct.glb_msg_cnt_pri = self.glb_msg_cnt_pri
        struct.glb_err_cnt_sec = self.glb_err_cnt_sec
        struct.glb_err_cnt_pri = self.glb_err_cnt_pri
        struct.bus_load_sec = self.bus_load_sec
        struct.bus_load_pri = self.bus_load_pri
        struct.bus_load_sec_avg = self.bus_load_sec_avg
        struct.bus_load_pri_avg = self.bus_load_pri_avg
        return struct


class PY_TY_API_BM_TCB(object):
    def __init__(self, tt = 0, sot = 0, tri = 0, inv = 0, tres = 0, tset = 0, tsp = 0, next = 0, eom = 0, tdw = 0, tmw = 0, tuli = 0, tlli = 0):
        self.tt = tt # <class 'ctypes.c_ubyte'>
        self.sot = sot # <class 'ctypes.c_ubyte'>
        self.tri = tri # <class 'ctypes.c_ubyte'>
        self.inv = inv # <class 'ctypes.c_ubyte'>
        self.tres = tres # <class 'ctypes.c_ubyte'>
        self.tset = tset # <class 'ctypes.c_ubyte'>
        self.tsp = tsp # <class 'ctypes.c_ubyte'>
        self.next = next # <class 'ctypes.c_ubyte'>
        self.eom = eom # <class 'ctypes.c_ubyte'>
        self.padding1 = 0 # <class 'ctypes.c_ubyte'>
        self.tdw = tdw # <class 'ctypes.c_ushort'>
        self.tmw = tmw # <class 'ctypes.c_ushort'>
        self.tuli = tuli # <class 'ctypes.c_ushort'>
        self.tlli = tlli # <class 'ctypes.c_ushort'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.tt, struct.sot, struct.tri, struct.inv, struct.tres, struct.tset, struct.tsp, struct.next, struct.eom, struct.tdw, struct.tmw, struct.tuli, struct.tlli)
    
    def toStruct(self):
        struct = amb.ty_api_bm_tcb()
        struct.tt = self.tt
        struct.sot = self.sot
        struct.tri = self.tri
        struct.inv = self.inv
        struct.tres = self.tres
        struct.tset = self.tset
        struct.tsp = self.tsp
        struct.next = self.next
        struct.eom = self.eom
        struct.padding1 = self.padding1
        struct.tdw = self.tdw
        struct.tmw = self.tmw
        struct.tuli = self.tuli
        struct.tlli = self.tlli
        return struct


class PY_TY_API_BOARD_CAPABILITIES(object):
    def __init__(self, ul_CanChangeAmplitude = 0, x_CouplingCapabilities = None, x_IrigCapabilities = None):
        self.ul_CanChangeAmplitude = ul_CanChangeAmplitude # <class 'ctypes.c_ulong'>
        self.x_CouplingCapabilities = x_CouplingCapabilities # <class 'mil_bindings.ty_coupling_capabilities_union'>
        self.x_IrigCapabilities = x_IrigCapabilities # <class 'mil_bindings.ty_irig_capabilities_union'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_CanChangeAmplitude, struct.x_CouplingCapabilities, struct.x_IrigCapabilities)
    
    def toStruct(self):
        struct = amb.ty_api_board_capabilities()
        struct.ul_CanChangeAmplitude = self.ul_CanChangeAmplitude
        struct.x_CouplingCapabilities = self.x_CouplingCapabilities
        struct.x_IrigCapabilities = self.x_IrigCapabilities
        return struct


class PY_TY_API_C1760_CON(object):
    def __init__(self, mode = 0, c01 = 0, buf_id = 0, c02 = None):
        self.mode = mode # <class 'ctypes.c_ubyte'>
        self.c01 = c01 # <class 'ctypes.c_ubyte'>
        self.buf_id = buf_id # <class 'ctypes.c_ushort'>
        self.c02 = [0] * 16 if c02 == None else c02 # <class 'mil_bindings.c_ubyte_Array_16'>
    
    @classmethod
    def fromStruct(cls, struct):
        # FIXME: autogenerated code needs adaptation.
        return cls(struct.mode, struct.c01, struct.buf_id, [v for v in struct.c02] )
    
    def toStruct(self):
        # FIXME: autogenerated code needs adaptation.
        struct = amb.ty_api_c1760_con()
        struct.mode = self.mode
        struct.c01 = self.c01
        struct.buf_id = self.buf_id
        for i in range(16):
            struct.c02[i] = self.c02[i]
        return struct


class PY_TY_API_DATA_QUEUE_READ(object):
    def __init__(self, id = 0, bytes_to_read = 0, buffer = None ):
        self.id = id # <class 'ctypes.c_ulong'>
        self.bytes_to_read = bytes_to_read # <class 'ctypes.c_ulong'>
        self.buffer = buffer # <class 'ctypes.c_void_p'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.id, struct.bytes_to_read, struct.buffer)
    
    def toStruct(self):
        struct = amb.ty_api_data_queue_read()
        struct.id = self.id
        struct.bytes_to_read = self.bytes_to_read
        return struct


class PY_TY_API_DATA_QUEUE_STATUS(object):
    def __init__(self, status = 0, bytes_transfered = 0, bytes_in_queue = 0, total_bytes_transfered = 0):
        self.status = status # <class 'ctypes.c_ulong'>
        self.bytes_transfered = bytes_transfered # <class 'ctypes.c_ulong'>
        self.bytes_in_queue = bytes_in_queue # <class 'ctypes.c_ulong'>
        self.total_bytes_transfered = total_bytes_transfered # <class 'ctypes.c_ulonglong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.status, struct.bytes_transfered, struct.bytes_in_queue, struct.total_bytes_transfered)
    
    def toStruct(self):
        struct = amb.ty_api_data_queue_status()
        struct.status = self.status
        struct.bytes_transfered = self.bytes_transfered
        struct.bytes_in_queue = self.bytes_in_queue
        struct.total_bytes_transfered = self.total_bytes_transfered
        return struct


class PY_TY_API_DISCR_INFO(object):
    def __init__(self, channels = 0, canIn = 0, canOut = 0):
        self.channels = channels # <class 'ctypes.c_ulong'>
        self.canIn = canIn # <class 'ctypes.c_ulong'>
        self.canOut = canOut # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.channels, struct.canIn, struct.canOut)
    
    def toStruct(self):
        struct = amb.ty_api_discr_info()
        struct.channels = self.channels
        struct.canIn = self.canIn
        struct.canOut = self.canOut
        return struct


class PY_TY_API_GEN_IO_BOARD(object):
    def __init__(self, ul_Board = 0, ul_Type = 0, ul_StartAddress = 0):
        self.ul_Board = ul_Board # <class 'ctypes.c_ulong'>
        self.ul_Type = ul_Type # <class 'ctypes.c_ulong'>
        self.ul_StartAddress = ul_StartAddress # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_Board, struct.ul_Type, struct.ul_StartAddress)
    
    def toStruct(self):
        struct = amb.ty_api_gen_io_board()
        struct.ul_Board = self.ul_Board
        struct.ul_Type = self.ul_Type
        struct.ul_StartAddress = self.ul_StartAddress
        return struct


class PY_TY_API_GEN_IO_BOARD_TYPE(object):
    def __init__(self, ul_BoardType = 0, ul_Type = 0):
        self.ul_BoardType = ul_BoardType # <class 'ctypes.c_ulong'>
        self.ul_Type = ul_Type # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_BoardType, struct.ul_Type)
    
    def toStruct(self):
        struct = amb.ty_api_gen_io_board_type()
        struct.ul_BoardType = self.ul_BoardType
        struct.ul_Type = self.ul_Type
        return struct


class PY_TY_API_GEN_IO_BOARD_TYPE_LIST(object):
    def __init__(self, ul_Cnt = 0, px_BoardTypes = None):
        self.ul_Cnt = ul_Cnt # <class 'ctypes.c_ulong'>
        self.px_BoardTypes = px_BoardTypes # <class 'mil_bindings.LP_ty_api_gen_io_board_type'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_Cnt, struct.px_BoardTypes)
    
    def toStruct(self):
        struct = amb.ty_api_gen_io_board_type_list()
        struct.ul_Cnt = self.ul_Cnt
        struct.px_BoardTypes = self.px_BoardTypes
        return struct


class PY_TY_API_GEN_IO_DEV_VEN(object):
    def __init__(self, ul_DeviceVendor = 0, ul_SubSystemSubVendor = 0):
        self.ul_DeviceVendor = ul_DeviceVendor # <class 'ctypes.c_ulong'>
        self.ul_SubSystemSubVendor = ul_SubSystemSubVendor # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_DeviceVendor, struct.ul_SubSystemSubVendor)
    
    def toStruct(self):
        struct = amb.ty_api_gen_io_dev_ven()
        struct.ul_DeviceVendor = self.ul_DeviceVendor
        struct.ul_SubSystemSubVendor = self.ul_SubSystemSubVendor
        return struct


class PY_TY_API_GEN_IO_DEV_VEN_LIST(object):
    def __init__(self, ul_Cnt = 0, px_DevVen = None):
        self.ul_Cnt = ul_Cnt # <class 'ctypes.c_ulong'>
        self.px_DevVen = px_DevVen # <class 'mil_bindings.LP_ty_api_gen_io_dev_ven'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_Cnt, struct.px_DevVen)
    
    def toStruct(self):
        struct = amb.ty_api_gen_io_dev_ven_list()
        struct.ul_Cnt = self.ul_Cnt
        struct.px_DevVen = self.px_DevVen
        return struct


class PY_TY_API_GEN_IO_GET_BOARD_OUT(object):
    def __init__(self, ul_Cnt = 0, px_Board = None):
        self.ul_Cnt = ul_Cnt # <class 'ctypes.c_ulong'>
        self.px_Board = px_Board # <class 'mil_bindings.LP_ty_api_gen_io_board'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_Cnt, struct.px_Board)
    
    def toStruct(self):
        struct = amb.ty_api_gen_io_get_board_out()
        struct.ul_Cnt = self.ul_Cnt
        struct.px_Board = self.px_Board
        return struct


class PY_TY_API_GEN_IO_GET_BOARDS_IN(object):
    def __init__(self, px_DevVenList = None, px_BoardTypesList = None):
        self.px_DevVenList = px_DevVenList # <class 'mil_bindings.LP_ty_api_gen_io_dev_ven_list'>
        self.px_BoardTypesList = px_BoardTypesList # <class 'mil_bindings.LP_ty_api_gen_io_board_type_list'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.px_DevVenList, struct.px_BoardTypesList)
    
    def toStruct(self):
        struct = amb.ty_api_gen_io_get_boards_in()
        struct.px_DevVenList = self.px_DevVenList
        struct.px_BoardTypesList = self.px_BoardTypesList
        return struct


class PY_TY_API_GEN_IO_TEST_SEQ_ARRAY(object):
    def __init__(self, mode = 0, cond = 0, res1 = 0, res2 = 0, tm_ms = None, genio_type_op = None, chn_val = None):
        self.mode = mode # <class 'ctypes.c_ulong'>
        self.cond = cond # <class 'ctypes.c_ulong'>
        self.res1 = res1 # <class 'ctypes.c_ulong'>
        self.res2 = res2 # <class 'ctypes.c_ulong'>
        self.tm_ms = [] if tm_ms == None else tm_ms # <class 'mil_bindings.c_ulong_Array_32'>
        self.genio_type_op = [] if genio_type_op == None else genio_type_op # <class 'mil_bindings.c_ulong_Array_32'>
        self.chn_val = [] if chn_val == None else chn_val # <class 'mil_bindings.c_ulong_Array_32'>
    
    @classmethod
    def fromStruct(cls, struct):
        # FIXME: autogenerated code needs adaptation.
        return cls(struct.mode, struct.cond, struct.res1, struct.res2, struct.tm_ms, struct.genio_type_op, struct.chn_val)
    
    def toStruct(self):
        # FIXME: autogenerated code needs adaptation.
        struct = amb.ty_api_gen_io_test_seq_array()
        struct.mode = self.mode
        struct.cond = self.cond
        struct.res1 = self.res1
        struct.res2 = self.res2
        struct.tm_ms = self.tm_ms
        struct.genio_type_op = self.genio_type_op
        struct.chn_val = self.chn_val
        return struct


class PY_TY_API_GEN_IO_TEST_SEQ_TBL(object):
    def __init__(self, ax_Seq = None):
        self.ax_Seq = [] if ax_Seq == None else ax_Seq # <class 'mil_bindings.ty_api_gen_io_test_seq_array_Array_4'>
    
    @classmethod
    def fromStruct(cls, struct):
        # FIXME: autogenerated code needs adaptation.
        return cls(struct.ax_Seq)
    
    def toStruct(self):
        # FIXME: autogenerated code needs adaptation.
        struct = amb.ty_api_gen_io_test_seq_tbl()
        struct.ax_Seq = self.ax_Seq
        return struct


class PY_TY_API_GET_MEM_LAYOUT(object):
    def __init__(self, ax_BiuAddr = None, x_Sim = None, ax_BiuSize = None, ax_BiuCnt = None, x_BiuInfo = None, aul_GlobalMemSize = None):
        self.ax_BiuAddr = [] if ax_BiuAddr == None else ax_BiuAddr # <class 'mil_bindings.ty_api_mem_biu_addr_Array_8'>
        self.x_Sim = [] if x_Sim == None else x_Sim # <class 'mil_bindings.ty_api_mem_sim_buf_Array_2'>
        self.ax_BiuSize = [] if ax_BiuSize == None else ax_BiuSize # <class 'mil_bindings.ty_api_mem_biu_size_Array_8'>
        self.ax_BiuCnt = [] if ax_BiuCnt == None else ax_BiuCnt # <class 'mil_bindings.ty_api_mem_biu_count_Array_8'>
        self.x_BiuInfo = [] if x_BiuInfo == None else x_BiuInfo # <class 'mil_bindings.ty_api_mem_biu_info_Array_8'>
        self.aul_GlobalMemSize = [] if aul_GlobalMemSize == None else aul_GlobalMemSize # <class 'mil_bindings.c_ulong_Array_2'>
    
    @classmethod
    def fromStruct(cls, struct):
        # FIXME: autogenerated code needs adaptation.
        return cls(struct.ax_BiuAddr, struct.x_Sim, struct.ax_BiuSize, struct.ax_BiuCnt, struct.x_BiuInfo, struct.aul_GlobalMemSize)
    
    def toStruct(self):
        # FIXME: autogenerated code needs adaptation.
        struct = amb.ty_api_get_mem_layout()
        struct.ax_BiuAddr = self.ax_BiuAddr
        struct.x_Sim = self.x_Sim
        struct.ax_BiuSize = self.ax_BiuSize
        struct.ax_BiuCnt = self.ax_BiuCnt
        struct.x_BiuInfo = self.x_BiuInfo
        struct.aul_GlobalMemSize = self.aul_GlobalMemSize
        return struct


class PY_TY_API_HSLS_BC_XFER(object):
    def __init__(self, ul_Gap = 0, ul_Swxm = 0):
        self.ul_Gap = ul_Gap # <class 'ctypes.c_ulong'>
        self.ul_Swxm = ul_Swxm # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_Gap, struct.ul_Swxm)
    
    def toStruct(self):
        struct = amb.ty_api_hsls_bc_xfer()
        struct.ul_Gap = self.ul_Gap
        struct.ul_Swxm = self.ul_Swxm
        return struct


class PY_TY_API_INI_INFO(object):
    def __init__(self, bt = None, chns = 0, prot = 0, emod = 0, irg = 0, res1 = 0, padd1 = 0, padd2 = 0, pbi_id_biu1 = 0, asp_mon_id = 0, asp_bite_id = 0, pbi_id_biu2 = 0, board_config = 0, glb_mem_size = 0, glb_mem_addr = 0, loc_dram_size = 0, loc_dram_addr = 0, shared_dram_size = 0, shared_dram_addr = 0, flash_ram_size = 0, flash_ram_addr = 0, pci = None, board_type = 0, board_sub_type = 0, hardware_variant = 0):
        self.bt = [0] * 4 if bt == None else bt # <class 'mil_bindings.c_ubyte_Array_4'>
        self.chns = chns # <class 'ctypes.c_ubyte'>
        self.prot = prot # <class 'ctypes.c_ubyte'>
        self.emod = emod # <class 'ctypes.c_ubyte'>
        self.irg = irg # <class 'ctypes.c_ubyte'>
        self.res1 = res1 # <class 'ctypes.c_ubyte'>
        self.padd1 = padd1 # <class 'ctypes.c_ubyte'>
        self.padd2 = padd2 # <class 'ctypes.c_ushort'>
        self.pbi_id_biu1 = pbi_id_biu1 # <class 'ctypes.c_ushort'>
        self.asp_mon_id = asp_mon_id # <class 'ctypes.c_ushort'>
        self.asp_bite_id = asp_bite_id # <class 'ctypes.c_ushort'>
        self.pbi_id_biu2 = pbi_id_biu2 # <class 'ctypes.c_ushort'>
        self.board_config = board_config # <class 'ctypes.c_ulong'>
        self.glb_mem_size = glb_mem_size # <class 'ctypes.c_ulong'>
        self.glb_mem_addr = glb_mem_addr # <class 'ctypes.c_ulong'>
        self.loc_dram_size = loc_dram_size # <class 'ctypes.c_ulong'>
        self.loc_dram_addr = loc_dram_addr # <class 'ctypes.c_ulong'>
        self.shared_dram_size = shared_dram_size # <class 'ctypes.c_ulong'>
        self.shared_dram_addr = shared_dram_addr # <class 'ctypes.c_ulong'>
        self.flash_ram_size = flash_ram_size # <class 'ctypes.c_ulong'>
        self.flash_ram_addr = flash_ram_addr # <class 'ctypes.c_ulong'>
        self.pci = [0] * 16 if pci == None else pci # <class 'mil_bindings.c_ulong_Array_16'>
        self.board_type = board_type # <class 'ctypes.c_ulong'>
        self.board_sub_type = board_sub_type # <class 'ctypes.c_ulong'>
        self.hardware_variant = hardware_variant # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls( [b for b in struct.bt], struct.chns, struct.prot, struct.emod, struct.irg, struct.res1, struct.padd1, struct.padd2, struct.pbi_id_biu1, struct.asp_mon_id, struct.asp_bite_id, struct.pbi_id_biu2, struct.board_config, struct.glb_mem_size, struct.glb_mem_addr, struct.loc_dram_size, struct.loc_dram_addr, struct.shared_dram_size, struct.shared_dram_addr, struct.flash_ram_size, struct.flash_ram_addr, [b for b in struct.pci], struct.board_type, struct.board_sub_type, struct.hardware_variant)
    
    def toStruct(self):
        struct = amb.ty_api_ini_info()
        for i in range(4):
            struct.bt[i] = self.bt[i]
        struct.chns = self.chns
        struct.prot = self.prot
        struct.emod = self.emod
        struct.irg = self.irg
        struct.res1 = self.res1
        struct.padd1 = self.padd1
        struct.padd2 = self.padd2
        struct.pbi_id_biu1 = self.pbi_id_biu1
        struct.asp_mon_id = self.asp_mon_id
        struct.asp_bite_id = self.asp_bite_id
        struct.pbi_id_biu2 = self.pbi_id_biu2
        struct.board_config = self.board_config
        struct.glb_mem_size = self.glb_mem_size
        struct.glb_mem_addr = self.glb_mem_addr
        struct.loc_dram_size = self.loc_dram_size
        struct.loc_dram_addr = self.loc_dram_addr
        struct.shared_dram_size = self.shared_dram_size
        struct.shared_dram_addr = self.shared_dram_addr
        struct.flash_ram_size = self.flash_ram_size
        struct.flash_ram_addr = self.flash_ram_addr
        for i in range(16):
            struct.pci[i] = self.pci[i]
        struct.board_type = self.board_type
        struct.board_sub_type = self.board_sub_type
        struct.hardware_variant = self.hardware_variant
        return struct


class PY_TY_API_INTR_EVENT_LIST(object):
    def __init__(self, put_cnt = 0, get_cnt = 0, entry = None):
        self.put_cnt = put_cnt # <class 'ctypes.c_ulong'>
        self.get_cnt = get_cnt # <class 'ctypes.c_ulong'>
        self.entry = [] if entry == None else entry # <class 'mil_bindings.ty_api_intr_loglist_entry_Array_256'>
    
    @classmethod
    def fromStruct(cls, struct):
        # FIXME: autogenerated code needs adaptation.
        return cls(struct.put_cnt, struct.get_cnt, struct.entry)
    
    def toStruct(self):
        # FIXME: autogenerated code needs adaptation.
        struct = amb.ty_api_intr_event_list()
        struct.put_cnt = self.put_cnt
        struct.get_cnt = self.get_cnt
        struct.entry = self.entry
        return struct

class PY_TY_API_INTR_LOGLIST_ENTRY(object):
    def __init__(self, ul_Lla = 0, ul_Llb = 0, x_Llc = None, x_Lld = None):
        self.ul_Lla = ul_Lla # <class 'ctypes.c_ulong'>
        self.ul_Llb = ul_Llb # <class 'ctypes.c_ulong'>
        self.x_Llc = x_Llc # <class 'mil_bindings.ty_api_intr_loglist_llc_union'>
        self.x_Lld = x_Lld # <class 'mil_bindings.ty_api_intr_loglist_lld_union'>

    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_Lla, struct.ul_Llb, struct.x_Llc, struct.x_Lld)
    
    @classmethod
    def fromPointer(cls, buffer_pointer):
        ctypes_ll_entry = amb.TY_API_INTR_LOGLIST_ENTRY.from_buffer_copy(buffer_pointer.contents)
        return ambt.PY_TY_API_INTR_LOGLIST_ENTRY.fromStruct(ctypes_ll_entry)

class PY_TY_API_INTR_LOGLIST_LLC_B(object):
    def __init__(self, ul_Info = 0, uc_Biu1 = 0, uc_Biu2 = 0, uc_Dma = 0, uc_Target = 0, uc_Cmd = 0, uc_Biu3 = 0, uc_Biu4 = 0, res = 0):
        self.ul_Info = ul_Info # <class 'ctypes.c_ulong'>
        self.uc_Biu1 = uc_Biu1 # <class 'ctypes.c_ulong'>
        self.uc_Biu2 = uc_Biu2 # <class 'ctypes.c_ulong'>
        self.uc_Dma = uc_Dma # <class 'ctypes.c_ulong'>
        self.uc_Target = uc_Target # <class 'ctypes.c_ulong'>
        self.uc_Cmd = uc_Cmd # <class 'ctypes.c_ulong'>
        self.uc_Biu3 = uc_Biu3 # <class 'ctypes.c_ulong'>
        self.uc_Biu4 = uc_Biu4 # <class 'ctypes.c_ulong'>
        self.res = res # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_Info, struct.uc_Biu1, struct.uc_Biu2, struct.uc_Dma, struct.uc_Target, struct.uc_Cmd, struct.uc_Biu3, struct.uc_Biu4, struct.res)
    
    def toStruct(self):
        struct = amb.ty_api_intr_loglist_llc_b()
        struct.ul_Info = self.ul_Info
        struct.uc_Biu1 = self.uc_Biu1
        struct.uc_Biu2 = self.uc_Biu2
        struct.uc_Dma = self.uc_Dma
        struct.uc_Target = self.uc_Target
        struct.uc_Cmd = self.uc_Cmd
        struct.uc_Biu3 = self.uc_Biu3
        struct.uc_Biu4 = self.uc_Biu4
        struct.res = self.res
        return struct


class PY_TY_API_INTR_LOGLIST_LLC_T(object):
    def __init__(self, ul_Info = 0, uc_IntType = 0):
        self.ul_Info = ul_Info # <class 'ctypes.c_ulong'>
        self.uc_IntType = uc_IntType # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_Info, struct.uc_IntType)
    
    def toStruct(self):
        struct = amb.ty_api_intr_loglist_llc_t()
        struct.ul_Info = self.ul_Info
        struct.uc_IntType = self.uc_IntType
        return struct


class PY_TY_API_INTR_LOGLIST_LLD_UNION_T(object):
    def __init__(self, ul_Index = 0, uc_Res = 0, uc_IntSrc = 0):
        self.ul_Index = ul_Index # <class 'ctypes.c_ulong'>
        self.uc_Res = uc_Res # <class 'ctypes.c_ulong'>
        self.uc_IntSrc = uc_IntSrc # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_Index, struct.uc_Res, struct.uc_IntSrc)
    
    def toStruct(self):
        struct = amb.ty_api_intr_loglist_lld_union_t()
        struct.ul_Index = self.ul_Index
        struct.uc_Res = self.uc_Res
        struct.uc_IntSrc = self.uc_IntSrc
        return struct


class PY_TY_API_INTR_REGS(object):
    def __init__(self, lla = 0, llb = 0, llc = 0, lld = 0):
        self.lla = lla # <class 'ctypes.c_ulong'>
        self.llb = llb # <class 'ctypes.c_ulong'>
        self.llc = llc # <class 'ctypes.c_ulong'>
        self.lld = lld # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.lla, struct.llb, struct.llc, struct.lld)
    
    def toStruct(self):
        struct = amb.ty_api_intr_regs()
        struct.lla = self.lla
        struct.llb = self.llb
        struct.llc = self.llc
        struct.lld = self.lld
        return struct


class PY_TY_API_IRIG_TIME(object):
    def __init__(self, day = 0, hour = 0, minute = 0, second = 0, microsecond = 0):
        self.day = day # <class 'ctypes.c_ulong'>
        self.hour = hour # <class 'ctypes.c_ulong'>
        self.minute = minute # <class 'ctypes.c_ulong'>
        self.second = second # <class 'ctypes.c_ulong'>
        self.microsecond = microsecond # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.day, struct.hour, struct.minute, struct.second, struct.microsecond)
    
    def toStruct(self):
        struct = amb.ty_api_irig_time()
        struct.day = self.day
        struct.hour = self.hour
        struct.minute = self.minute
        struct.second = self.second
        struct.microsecond = self.microsecond
        return struct


class PY_TY_API_LIB_INFO(object):
    def __init__(self, ul_AttachedApps = 0):
        self.ul_AttachedApps = ul_AttachedApps # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_AttachedApps)
    
    def toStruct(self):
        struct = amb.ty_api_lib_info()
        struct.ul_AttachedApps = self.ul_AttachedApps
        return struct


class PY_TY_API_MEM_BIU_ADDR(object):
    def __init__(self, ul_Cb = 0, ul_IrLog = 0, ul_RtDesc = 0, ul_BmTcb = 0, ul_BmAct = 0, ul_RtSaDesc = 0, ul_RtBhArea = 0, ul_RtSqArea = 0, ul_RtEqArea = 0, ul_BcBhArea = 0, ul_BcSqArea = 0, ul_BcEqArea = 0, ul_BcXferDesc = 0, ul_BcHipInstr = 0, ul_BcLipInstr = 0, ul_BcAcycInstr = 0, ul_RepBuf = 0, ul_BmBuf = 0):
        self.ul_Cb = ul_Cb # <class 'ctypes.c_ulong'>
        self.ul_IrLog = ul_IrLog # <class 'ctypes.c_ulong'>
        self.ul_RtDesc = ul_RtDesc # <class 'ctypes.c_ulong'>
        self.ul_BmTcb = ul_BmTcb # <class 'ctypes.c_ulong'>
        self.ul_BmAct = ul_BmAct # <class 'ctypes.c_ulong'>
        self.ul_RtSaDesc = ul_RtSaDesc # <class 'ctypes.c_ulong'>
        self.ul_RtBhArea = ul_RtBhArea # <class 'ctypes.c_ulong'>
        self.ul_RtSqArea = ul_RtSqArea # <class 'ctypes.c_ulong'>
        self.ul_RtEqArea = ul_RtEqArea # <class 'ctypes.c_ulong'>
        self.ul_BcBhArea = ul_BcBhArea # <class 'ctypes.c_ulong'>
        self.ul_BcSqArea = ul_BcSqArea # <class 'ctypes.c_ulong'>
        self.ul_BcEqArea = ul_BcEqArea # <class 'ctypes.c_ulong'>
        self.ul_BcXferDesc = ul_BcXferDesc # <class 'ctypes.c_ulong'>
        self.ul_BcHipInstr = ul_BcHipInstr # <class 'ctypes.c_ulong'>
        self.ul_BcLipInstr = ul_BcLipInstr # <class 'ctypes.c_ulong'>
        self.ul_BcAcycInstr = ul_BcAcycInstr # <class 'ctypes.c_ulong'>
        self.ul_RepBuf = ul_RepBuf # <class 'ctypes.c_ulong'>
        self.ul_BmBuf = ul_BmBuf # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_Cb, struct.ul_IrLog, struct.ul_RtDesc, struct.ul_BmTcb, struct.ul_BmAct, struct.ul_RtSaDesc, struct.ul_RtBhArea, struct.ul_RtSqArea, struct.ul_RtEqArea, struct.ul_BcBhArea, struct.ul_BcSqArea, struct.ul_BcEqArea, struct.ul_BcXferDesc, struct.ul_BcHipInstr, struct.ul_BcLipInstr, struct.ul_BcAcycInstr, struct.ul_RepBuf, struct.ul_BmBuf)
    
    def toStruct(self):
        struct = amb.ty_api_mem_biu_addr()
        struct.ul_Cb = self.ul_Cb
        struct.ul_IrLog = self.ul_IrLog
        struct.ul_RtDesc = self.ul_RtDesc
        struct.ul_BmTcb = self.ul_BmTcb
        struct.ul_BmAct = self.ul_BmAct
        struct.ul_RtSaDesc = self.ul_RtSaDesc
        struct.ul_RtBhArea = self.ul_RtBhArea
        struct.ul_RtSqArea = self.ul_RtSqArea
        struct.ul_RtEqArea = self.ul_RtEqArea
        struct.ul_BcBhArea = self.ul_BcBhArea
        struct.ul_BcSqArea = self.ul_BcSqArea
        struct.ul_BcEqArea = self.ul_BcEqArea
        struct.ul_BcXferDesc = self.ul_BcXferDesc
        struct.ul_BcHipInstr = self.ul_BcHipInstr
        struct.ul_BcLipInstr = self.ul_BcLipInstr
        struct.ul_BcAcycInstr = self.ul_BcAcycInstr
        struct.ul_RepBuf = self.ul_RepBuf
        struct.ul_BmBuf = self.ul_BmBuf
        return struct


class PY_TY_API_MEM_BIU_COUNT(object):
    def __init__(self, ul_RtBhArea = 0, ul_RtSqArea = 0, ul_RtEqArea = 0, ul_BcBhArea = 0, ul_BcSqArea = 0, ul_BcEqArea = 0, ul_BcXferDesc = 0):
        self.ul_RtBhArea = ul_RtBhArea # <class 'ctypes.c_ulong'>
        self.ul_RtSqArea = ul_RtSqArea # <class 'ctypes.c_ulong'>
        self.ul_RtEqArea = ul_RtEqArea # <class 'ctypes.c_ulong'>
        self.ul_BcBhArea = ul_BcBhArea # <class 'ctypes.c_ulong'>
        self.ul_BcSqArea = ul_BcSqArea # <class 'ctypes.c_ulong'>
        self.ul_BcEqArea = ul_BcEqArea # <class 'ctypes.c_ulong'>
        self.ul_BcXferDesc = ul_BcXferDesc # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_RtBhArea, struct.ul_RtSqArea, struct.ul_RtEqArea, struct.ul_BcBhArea, struct.ul_BcSqArea, struct.ul_BcEqArea, struct.ul_BcXferDesc)
    
    def toStruct(self):
        struct = amb.ty_api_mem_biu_count()
        struct.ul_RtBhArea = self.ul_RtBhArea
        struct.ul_RtSqArea = self.ul_RtSqArea
        struct.ul_RtEqArea = self.ul_RtEqArea
        struct.ul_BcBhArea = self.ul_BcBhArea
        struct.ul_BcSqArea = self.ul_BcSqArea
        struct.ul_BcEqArea = self.ul_BcEqArea
        struct.ul_BcXferDesc = self.ul_BcXferDesc
        return struct


class PY_TY_API_MEM_BIU_INFO(object):
    def __init__(self, ul_Protocol = 0, ul_StreamNb = 0, ul_MemoryBank = 0):
        self.ul_Protocol = ul_Protocol # <class 'ctypes.c_ulong'>
        self.ul_StreamNb = ul_StreamNb # <class 'ctypes.c_ulong'>
        self.ul_MemoryBank = ul_MemoryBank # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_Protocol, struct.ul_StreamNb, struct.ul_MemoryBank)
    
    def toStruct(self):
        struct = amb.ty_api_mem_biu_info()
        struct.ul_Protocol = self.ul_Protocol
        struct.ul_StreamNb = self.ul_StreamNb
        struct.ul_MemoryBank = self.ul_MemoryBank
        return struct


class PY_TY_API_MEM_BIU_SIZE(object):
    def __init__(self, ul_BcHipInstr = 0, ul_BcLipInstr = 0, ul_BcAcycInstr = 0, ul_RepBuf = 0, ul_BmBuf = 0):
        self.ul_BcHipInstr = ul_BcHipInstr # <class 'ctypes.c_ulong'>
        self.ul_BcLipInstr = ul_BcLipInstr # <class 'ctypes.c_ulong'>
        self.ul_BcAcycInstr = ul_BcAcycInstr # <class 'ctypes.c_ulong'>
        self.ul_RepBuf = ul_RepBuf # <class 'ctypes.c_ulong'>
        self.ul_BmBuf = ul_BmBuf # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_BcHipInstr, struct.ul_BcLipInstr, struct.ul_BcAcycInstr, struct.ul_RepBuf, struct.ul_BmBuf)
    
    def toStruct(self):
        struct = amb.ty_api_mem_biu_size()
        struct.ul_BcHipInstr = self.ul_BcHipInstr
        struct.ul_BcLipInstr = self.ul_BcLipInstr
        struct.ul_BcAcycInstr = self.ul_BcAcycInstr
        struct.ul_RepBuf = self.ul_RepBuf
        struct.ul_BmBuf = self.ul_BmBuf
        return struct


class PY_TY_API_MEM_SIM_BUF(object):
    def __init__(self, ul_BufBaseAddr = 0, ul_BufSize = 0, ul_BufCount = 0, ul_HsBufBaseAddr = 0, ul_HsBufSize = 0, ul_HsRes = 0):
        self.ul_BufBaseAddr = ul_BufBaseAddr # <class 'ctypes.c_ulong'>
        self.ul_BufSize = ul_BufSize # <class 'ctypes.c_ulong'>
        self.ul_BufCount = ul_BufCount # <class 'ctypes.c_ulong'>
        self.ul_HsBufBaseAddr = ul_HsBufBaseAddr # <class 'ctypes.c_ulong'>
        self.ul_HsBufSize = ul_HsBufSize # <class 'ctypes.c_ulong'>
        self.ul_HsRes = ul_HsRes # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_BufBaseAddr, struct.ul_BufSize, struct.ul_BufCount, struct.ul_HsBufBaseAddr, struct.ul_HsBufSize, struct.ul_HsRes)
    
    def toStruct(self):
        struct = amb.ty_api_mem_sim_buf()
        struct.ul_BufBaseAddr = self.ul_BufBaseAddr
        struct.ul_BufSize = self.ul_BufSize
        struct.ul_BufCount = self.ul_BufCount
        struct.ul_HsBufBaseAddr = self.ul_HsBufBaseAddr
        struct.ul_HsBufSize = self.ul_HsBufSize
        struct.ul_HsRes = self.ul_HsRes
        return struct


class PY_TY_API_OPEN(object):
    def __init__(self, ul_Module = 0, ul_Stream = 1, ac_SrvName = None):
        self.ul_Module = ul_Module # <class 'ctypes.c_ulong'>
        self.ul_Stream = ul_Stream # <class 'ctypes.c_ulong'>
        self.ac_SrvName = 'local' if ac_SrvName == None else ac_SrvName # <class 'mil_bindings.c_char_Array_28'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_Module, struct.ul_Stream, struct.ac_SrvName.decode("utf-8") )
    
    def toStruct(self):
        struct = amb.ty_api_open()
        struct.ul_Module = self.ul_Module
        struct.ul_Stream = self.ul_Stream
        struct.ac_SrvName = self.ac_SrvName.encode("utf-8")
        return struct


class PY_TY_API_PXI_CON(object):
    def __init__(self, ul_Mode = 0, ul_TrgSource = 0, ul_TrgDest = 0, ul_TTClear = 0):
        self.ul_Mode = ul_Mode # <class 'ctypes.c_ulong'>
        self.ul_TrgSource = ul_TrgSource # <class 'ctypes.c_ulong'>
        self.ul_TrgDest = ul_TrgDest # <class 'ctypes.c_ulong'>
        self.ul_TTClear = ul_TTClear # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_Mode, struct.ul_TrgSource, struct.ul_TrgDest, struct.ul_TTClear)
    
    def toStruct(self):
        struct = amb.ty_api_pxi_con()
        struct.ul_Mode = self.ul_Mode
        struct.ul_TrgSource = self.ul_TrgSource
        struct.ul_TrgDest = self.ul_TrgDest
        struct.ul_TTClear = self.ul_TTClear
        return struct


class PY_TY_API_QUEUE_BUF(object):
    def __init__(self, rt_addr = 0, sa_mc = 0, sa_type = 0, rt_addr2 = 0, sa_mc2 = 0, sa_type2 = 0, word_cnt = 0, rbf_trw = 0, msg_trw = 0, status_word1 = 0, status_word2 = 0, buffer = None, ttag = 0):
        self.rt_addr = rt_addr # <class 'ctypes.c_ubyte'>
        self.sa_mc = sa_mc # <class 'ctypes.c_ubyte'>
        self.sa_type = sa_type # <class 'ctypes.c_ubyte'>
        self.rt_addr2 = rt_addr2 # <class 'ctypes.c_ubyte'>
        self.sa_mc2 = sa_mc2 # <class 'ctypes.c_ubyte'>
        self.sa_type2 = sa_type2 # <class 'ctypes.c_ubyte'>
        self.word_cnt = word_cnt # <class 'ctypes.c_ubyte'>
        self.rbf_trw = rbf_trw # <class 'ctypes.c_ubyte'>
        self.msg_trw = msg_trw # <class 'ctypes.c_ushort'>
        self.status_word1 = status_word1 # <class 'ctypes.c_ushort'>
        self.status_word2 = status_word2 # <class 'ctypes.c_ushort'>
        self.buffer = [] if buffer == None else buffer # <class 'mil_bindings.c_ushort_Array_32'>
        self.ttag = ttag # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.rt_addr, struct.sa_mc, struct.sa_type, struct.rt_addr2, struct.sa_mc2, struct.sa_type2, struct.word_cnt, struct.rbf_trw, struct.msg_trw, struct.status_word1, struct.status_word2, [v for v in struct.buffer], struct.ttag)
    
    @classmethod
    def fromBytes(cls, data, offset):
        if (len(data) - offset) < 3*4:
            raise Exception("Not enough data for LS monitor structure header (TTH,TTHL, CW or Error)")

        Interpreted = None
        ulIndex = 0

        while True:
            # Interpret BM entry 
            ulCurrentEntry = ((data[offset+3]<<24) + 
                            (data[offset+2]<<16) + 
                            (data[offset+1]<<8) + 
                            (data[offset+0]<<0))    
            ucBMEntryType = (ulCurrentEntry >> 28) & 0xF # Bits 28 .. 31 
            ulBMEntryData = (ulCurrentEntry & 0x3ffffff) # Bits  0 .. 26 

            # -- Message detection logic ---
            if (ulIndex == 0) and (ucBMEntryType != 0x3):
                # First entry is supposed to be a TTHigh 
                raise Exception("Error: No time tag high")

            if (ulIndex == 1) and (ucBMEntryType != 0x2):
                # Second entry is supposed to be a TTLow 
                raise Exception("Error: No time tag low")

            if (ulIndex > 0) and (ucBMEntryType == 0x3):
                # We found the TTHigh of the next message.
                # return interpreted object
                return Interpreted, offset
            
            # -- Message data interpretation ---
            if (ucBMEntryType == 1):
                # Error Word 
                if (ulBMEntryData & ambd.API_BM_ET_NRESP_MASK): Interpreted.msg_trw |= ambd.API_BM_MSG_ERR_NO_RESP    << 12
                elif (ulBMEntryData & ambd.API_BM_ET_MANCH_MASK):  Interpreted.msg_trw |= ambd.API_BM_MSG_ERR_MANCH      << 12
                elif (ulBMEntryData & ambd.API_BM_ET_HBIT_MASK):   Interpreted.msg_trw |= ambd.API_BM_MSG_ERR_HBIT       << 12
                elif (ulBMEntryData & ambd.API_BM_ET_LBIT_MASK):   Interpreted.msg_trw |= ambd.API_BM_MSG_ERR_LBIT       << 12
                elif (ulBMEntryData & ambd.API_BM_ET_PAR_MASK):    Interpreted.msg_trw |= ambd.API_BM_MSG_ERR_PARITY     << 12
                elif (ulBMEntryData & ambd.API_BM_ET_ISYNC_MASK):  Interpreted.msg_trw |= ambd.API_BM_MSG_ERR_ISYNC      << 12
                elif (ulBMEntryData & ambd.API_BM_ET_IWGAP_MASK):  Interpreted.msg_trw |= ambd.API_BM_MSG_ERR_GAP        << 12
                elif (ulBMEntryData & ambd.API_BM_ET_TX_MASK):     Interpreted.msg_trw |= ambd.API_BM_MSG_ERR_BOTH_CHN   << 12
                elif (ulBMEntryData & ambd.API_BM_ET_ILLEGL_MASK): Interpreted.msg_trw |= ambd.API_BM_MSG_ERR_MODECODE   << 12
                elif (ulBMEntryData & ambd.API_BM_ET_GAP_MASK):    Interpreted.msg_trw |= ambd.API_BM_MSG_ERR_EARLY_RESP << 12
                elif (ulBMEntryData & ambd.API_BM_ET_TADDR_MASK):  Interpreted.msg_trw |= ambd.API_BM_MSG_ERR_BIT_SET    << 12
                elif (ulBMEntryData & ambd.API_BM_ET_STAT_MASK):   Interpreted.msg_trw |= ambd.API_BM_MSG_ERR_SW_EXCEPT  << 12
                elif (ulBMEntryData & ambd.API_BM_ET_HCNT_MASK):   Interpreted.msg_trw |= ambd.API_BM_MSG_ERR_HCNT       << 12
                elif (ulBMEntryData & ambd.API_BM_ET_LCNT_MASK):   Interpreted.msg_trw |= ambd.API_BM_MSG_ERR_LCNT       << 12
                elif (ulBMEntryData & ambd.API_BM_ET_ALTER_MASK):  Interpreted.msg_trw |= ambd.API_BM_MSG_ERR_ILLEGL     << 12
            elif (ucBMEntryType == 2):
                # Time Tag Low
                Interpreted.ttag = ulBMEntryData
            elif (ucBMEntryType == 3):
                # Time Tag High 
                # not returned but marks the start of the message
                Interpreted = cls()
            elif (ucBMEntryType == 8):
                # Command Word   (Pri)
                Interpreted.rt_addr  = (ulBMEntryData>>11) & 0x1F
                Interpreted.sa_type  = (ulBMEntryData>>10) & 0x1
                Interpreted.sa_mc    = (ulBMEntryData>>5) & 0x1F
                Interpreted.word_cnt = (ulBMEntryData)& 0x1F
                Interpreted.rbf_trw = 1; # Primary 
            elif (ucBMEntryType == 9):
                # Command Word 2 (Pri) 
                Interpreted.rt_addr2 = (ulBMEntryData>>11) & 0x1F
                Interpreted.sa_type2 = (ulBMEntryData>>10) & 0x1
                Interpreted.sa_mc2   = (ulBMEntryData>>5) & 0x1F
            elif (ucBMEntryType == 0xa):
                # Data Word      (Pri) 
                Interpreted.buffer.append(ulBMEntryData & 0xFFFF)
            elif (ucBMEntryType == 0xb):
                # Status Word    (Pri) 
                Interpreted.msg_trw |= (1<<11)                  # Bus Primary            
                Interpreted.msg_trw |= (ulBMEntryData & 0x3FF) # Status Word (Bit 0..10)
            elif (ucBMEntryType == 0xc):
                # Command Word   (Sec) 
                Interpreted.rt_addr  = (ulBMEntryData>>11) & 0x1F
                Interpreted.sa_type  = (ulBMEntryData>>10) & 0x1
                Interpreted.sa_mc    = (ulBMEntryData>>5) & 0x1F
                Interpreted.word_cnt = (ulBMEntryData)& 0x1F
                Interpreted.rbf_trw  = 0  # Secondary
            elif (ucBMEntryType == 0xd):
                # Command Word 2 (Sec)
                Interpreted.rt_addr2 = (ulBMEntryData>>11) & 0x1F
                Interpreted.sa_type2 = (ulBMEntryData>>10) & 0x1
                Interpreted.sa_mc2   = (ulBMEntryData>>5) & 0x1F
            elif (ucBMEntryType == 0xe):
                # Data Word      (Sec) 
                Interpreted.buffer.append(ulBMEntryData & 0xFFFF)
            elif (ucBMEntryType == 0xf):
                # Status Word    (Sec) 
                Interpreted.msg_trw &= ~(1<<11)                 # Bus Secondary          
                Interpreted.msg_trw |= ulBMEntryData & 0x3FF  # Status Word (Bit 0..10)
            elif (ucBMEntryType == 0x0):
                # Entry not updated  
                pass
            else:
                # Reserved 4..7        
                # Ignored 
                pass

            offset  += 4
            ulIndex += 1

            if offset >= len(data):
                # The message is returned when the next timetag is found. 
                # For the last message we have no timetag so we return it here
                return Interpreted, offset


    def toStruct(self):
        struct = amb.ty_api_queue_buf()
        struct.rt_addr = self.rt_addr
        struct.sa_mc = self.sa_mc
        struct.sa_type = self.sa_type
        struct.rt_addr2 = self.rt_addr2
        struct.sa_mc2 = self.sa_mc2
        struct.sa_type2 = self.sa_type2
        struct.word_cnt = self.word_cnt
        struct.rbf_trw = self.rbf_trw
        struct.msg_trw = self.msg_trw
        struct.status_word1 = self.status_word1
        struct.status_word2 = self.status_word2
        for i in range(len(self.buffer)):
            struct.buffer[i] = self.buffer[i]
        struct.ttag = self.ttag
        return struct


class PY_TY_API_REP_STATUS(object):
    def __init__(self, status = 0, padding1 = 0, padding2 = 0, rpi_cnt = 0, saddr = 0, size = 0, entry_cnt = 0):
        self.status = status # <class 'ctypes.c_ubyte'>
        self.padding1 = padding1 # <class 'ctypes.c_ubyte'>
        self.padding2 = padding2 # <class 'ctypes.c_ushort'>
        self.rpi_cnt = rpi_cnt # <class 'ctypes.c_ulong'>
        self.saddr = saddr # <class 'ctypes.c_ulong'>
        self.size = size # <class 'ctypes.c_ulong'>
        self.entry_cnt = entry_cnt # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.status, struct.padding1, struct.padding2, struct.rpi_cnt, struct.saddr, struct.size, struct.entry_cnt)
    
    def toStruct(self):
        struct = amb.ty_api_rep_status()
        struct.status = self.status
        struct.padding1 = self.padding1
        struct.padding2 = self.padding2
        struct.rpi_cnt = self.rpi_cnt
        struct.saddr = self.saddr
        struct.size = self.size
        struct.entry_cnt = self.entry_cnt
        return struct


class PY_TY_API_RESET_INFO(object):
    def __init__(self, mbufs = 0, sbufs = 0, padding1 = 0, mon_addr = 0, sim_addr = 0):
        self.mbufs = mbufs # <class 'ctypes.c_ubyte'>
        self.sbufs = sbufs # <class 'ctypes.c_ubyte'>
        self.padding1 = padding1 # <class 'ctypes.c_ushort'>
        self.mon_addr = mon_addr # <class 'ctypes.c_ulong'>
        self.sim_addr = sim_addr # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.mbufs, struct.sbufs, struct.padding1, struct.mon_addr, struct.sim_addr)
    
    def toStruct(self):
        struct = amb.ty_api_reset_info()
        struct.mbufs = self.mbufs
        struct.sbufs = self.sbufs
        struct.padding1 = self.padding1
        struct.mon_addr = self.mon_addr
        struct.sim_addr = self.sim_addr
        return struct


class PY_TY_API_RT_BH_INFO(object):
    def __init__(self, bid = 0, sid = 0, eid = 0, nbufs = 0, hid_addr = 0, bq_addr = 0, sq_addr = 0, eq_addr = 0):
        self.bid = bid # <class 'ctypes.c_ushort'>
        self.sid = sid # <class 'ctypes.c_ushort'>
        self.eid = eid # <class 'ctypes.c_ushort'>
        self.nbufs = nbufs # <class 'ctypes.c_ushort'>
        self.hid_addr = hid_addr # <class 'ctypes.c_ulong'>
        self.bq_addr = bq_addr # <class 'ctypes.c_ulong'>
        self.sq_addr = sq_addr # <class 'ctypes.c_ulong'>
        self.eq_addr = eq_addr # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.bid, struct.sid, struct.eid, struct.nbufs, struct.hid_addr, struct.bq_addr, struct.sq_addr, struct.eq_addr)
    
    def toStruct(self):
        struct = amb.ty_api_rt_bh_info()
        struct.bid = self.bid
        struct.sid = self.sid
        struct.eid = self.eid
        struct.nbufs = self.nbufs
        struct.hid_addr = self.hid_addr
        struct.bq_addr = self.bq_addr
        struct.sq_addr = self.sq_addr
        struct.eq_addr = self.eq_addr
        return struct


class PY_TY_API_RT_DYTAG(object):
    def __init__(self, tag_fct = 0, min = 0, max = 0, step = 0, wpos = 0):
        self.tag_fct = tag_fct # <class 'ctypes.c_ushort'>
        self.min = min # <class 'ctypes.c_ushort'>
        self.max = max # <class 'ctypes.c_ushort'>
        self.step = step # <class 'ctypes.c_ushort'>
        self.wpos = wpos # <class 'ctypes.c_ushort'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.tag_fct, struct.min, struct.max, struct.step, struct.wpos)
    
    def toStruct(self):
        struct = amb.ty_api_rt_dytag()
        struct.tag_fct = self.tag_fct
        struct.min = self.min
        struct.max = self.max
        struct.step = self.step
        struct.wpos = self.wpos
        return struct


class PY_TY_API_RT_ERR(object):
    def __init__(self, type = 0, sync = 0, contig = 0, err_spec = 0):
        self.type = type # <class 'ctypes.c_ubyte'>
        self.sync = sync # <class 'ctypes.c_ubyte'>
        self.contig = contig # <class 'ctypes.c_ubyte'>
        self.padding1 = 0 # <class 'ctypes.c_ubyte'>
        self.err_spec = err_spec # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.type, struct.sync, struct.contig, struct.err_spec)
    
    def toStruct(self):
        struct = amb.ty_api_rt_err()
        struct.type = self.type
        struct.sync = self.sync
        struct.contig = self.contig
        struct.padding1 = self.padding1
        struct.err_spec = self.err_spec
        return struct


class PY_TY_API_RT_MODE_CTRL(object):
    def __init__(self, ul_RtMode = 0, ul_Ctrl = 0, ul_Param1 = 0, ul_Param2 = 0, ul_Param3 = 0):
        self.ul_RtMode = ul_RtMode # <class 'ctypes.c_ulong'>
        self.ul_Ctrl = ul_Ctrl # <class 'ctypes.c_ulong'>
        self.ul_Param1 = ul_Param1 # <class 'ctypes.c_ulong'>
        self.ul_Param2 = ul_Param2 # <class 'ctypes.c_ulong'>
        self.ul_Param3 = ul_Param3 # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_RtMode, struct.ul_Ctrl, struct.ul_Param1, struct.ul_Param2, struct.ul_Param3)
    
    def toStruct(self):
        struct = amb.ty_api_rt_mode_ctrl()
        struct.ul_RtMode = self.ul_RtMode
        struct.ul_Ctrl = self.ul_Ctrl
        struct.ul_Param1 = self.ul_Param1
        struct.ul_Param2 = self.ul_Param2
        struct.ul_Param3 = self.ul_Param3
        return struct


class PY_TY_API_RT_MSG_ALL_DSP_RT(object):
    def __init__(self, rt_msg = 0, rt_err = 0):
        self.rt_msg = rt_msg # <class 'ctypes.c_ulong'>
        self.rt_err = rt_err # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.rt_msg, struct.rt_err)
    
    def toStruct(self):
        struct = amb.ty_api_rt_msg_all_dsp_rt()
        struct.rt_msg = self.rt_msg
        struct.rt_err = self.rt_err
        return struct


class PY_TY_API_RT_MSG_ALL_DSP(object):
    def __init__(self, rt = None):
        self.rt = [ambt.PY_TY_API_RT_MSG_ALL_DSP_RT() for _ in range(32)] if rt == None else rt # <class 'mil_bindings.ty_api_rt_msg_all_dsp_rt_Array_32'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls([ambt.PY_TY_API_RT_MSG_ALL_DSP_RT.fromStruct(rt) for rt in struct.rt])
    
    def toStruct(self):
        struct = amb.ty_api_rt_msg_all_dsp()
        for i in range(32):
            struct.rt[i] = self.rt[i].toStruct()
        return struct


class PY_TY_API_RT_MSG_DSP(object):
    def __init__(self, nxw = 0, lsw = 0, lcw = 0, padding1 = 0, msg_cnt = 0, err_cnt = 0):
        self.nxw = nxw # <class 'ctypes.c_ushort'>
        self.lsw = lsw # <class 'ctypes.c_ushort'>
        self.lcw = lcw # <class 'ctypes.c_ushort'>
        self.padding1 = padding1 # <class 'ctypes.c_ushort'>
        self.msg_cnt = msg_cnt # <class 'ctypes.c_ulong'>
        self.err_cnt = err_cnt # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.nxw, struct.lsw, struct.lcw, struct.padding1, struct.msg_cnt, struct.err_cnt)
    
    def toStruct(self):
        struct = amb.ty_api_rt_msg_dsp()
        struct.nxw = self.nxw
        struct.lsw = self.lsw
        struct.lcw = self.lcw
        struct.padding1 = self.padding1
        struct.msg_cnt = self.msg_cnt
        struct.err_cnt = self.err_cnt
        return struct

class PY_TY_API_RT_INFO(object):
    def __init__(self, uc_Mode = 0, padding1 = 0, padding2 = 0, padding3 = 0, ul_RxSa = 0, ul_TxSa = 0, ul_RxMC = 0, ul_TxMC = 0, ul_HSRxMID = None, ul_HSTxMID = None, ul_HSMC = 0):
        self.uc_Mode = uc_Mode # <class 'ctypes.c_ushort'>
        self.padding1 = padding1 # <class 'ctypes.c_ushort'>
        self.padding2 = padding2 # <class 'ctypes.c_ushort'>
        self.padding3 = padding3 # <class 'ctypes.c_ushort'>
        self.ul_RxSa = ul_RxSa # <class 'ctypes.c_ulong'>
        self.ul_TxSa = ul_TxSa # <class 'ctypes.c_ulong'>
        self.ul_RxMC = ul_RxMC # <class 'ctypes.c_ulong'>
        self.ul_TxMC = ul_TxMC # <class 'ctypes.c_ulong'>
        self.ul_HSRxMID = [] if ul_HSRxMID == None else ul_HSRxMID # <class 'mil_bindings.c_ushort_Array_32'>
        self.ul_HSTxMID = [] if ul_HSTxMID == None else ul_HSTxMID # <class 'mil_bindings.c_ushort_Array_32'>
        self.ul_HSMC = ul_HSMC # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.uc_Mode, struct.padding1, struct.padding2, struct.padding3, struct.ul_RxSa, struct.ul_TxSa, struct.ul_RxMC, struct.ul_TxMC, [x for x in struct.ul_HSRxMID], [x for x in struct.ul_HSTxMID], struct.ul_HSMC)
    
    def toStruct(self):
        struct = amb.ty_api_rt_info()
        struct.uc_Mode = self.uc_Mode
        struct.padding1 = self.padding1
        struct.padding2 = self.padding2
        struct.padding3 = self.padding3
        struct.ul_RxSa = self.ul_RxSa
        struct.ul_TxSa = self.ul_TxSa
        struct.ul_RxMC = self.ul_RxMC
        struct.ul_TxMC = self.ul_TxMC
        for i in range(len(self.ul_HSRxMID)):
            struct.ul_HSRxMID[i] = self.ul_HSRxMID[i]
        for i in range(len(self.ul_HSTxMID)):
            struct.ul_HSTxMID[i] = self.ul_HSTxMID[i]
        struct.ul_HSMC = self.ul_HSMC

        return struct

class PY_TY_API_RT_SA(object):
    def __init__(self, buffer = None, mode = 0, rt = 0, rt_con = 0, sa_mc = 0, sa_type = 0, sa_con = 0, resp_time = 0, smod = 0, nxw = 0, swm = 0, hid = 0, bid = 0):
        self.buffer = [] if buffer == None else buffer # <class 'mil_bindings.c_ushort_Array_32'>
        self.mode = mode # <class 'ctypes.c_ubyte'>
        self.rt = rt # <class 'ctypes.c_ubyte'>
        self.rt_con = rt_con # <class 'ctypes.c_ubyte'>
        self.sa_mc = sa_mc # <class 'ctypes.c_ubyte'>
        self.sa_type = sa_type # <class 'ctypes.c_ubyte'>
        self.sa_con = sa_con # <class 'ctypes.c_ubyte'>
        self.resp_time = resp_time # <class 'ctypes.c_ubyte'>
        self.smod = smod # <class 'ctypes.c_ubyte'>
        self.nxw = nxw # <class 'ctypes.c_ushort'>
        self.swm = swm # <class 'ctypes.c_ushort'>
        self.hid = hid # <class 'ctypes.c_ushort'>
        self.bid = bid # <class 'ctypes.c_ushort'>
    
    @classmethod
    def fromStruct(cls, struct):
        # FIXME: autogenerated code needs adaptation.
        return cls(struct.buffer, struct.mode, struct.rt, struct.rt_con, struct.sa_mc, struct.sa_type, struct.sa_con, struct.resp_time, struct.smod, struct.nxw, struct.swm, struct.hid, struct.bid)
    
    def toStruct(self):
        # FIXME: autogenerated code needs adaptation.
        struct = amb.ty_api_rt_sa()
        struct.buffer = self.buffer
        struct.mode = self.mode
        struct.rt = self.rt
        struct.rt_con = self.rt_con
        struct.sa_mc = self.sa_mc
        struct.sa_type = self.sa_type
        struct.sa_con = self.sa_con
        struct.resp_time = self.resp_time
        struct.smod = self.smod
        struct.nxw = self.nxw
        struct.swm = self.swm
        struct.hid = self.hid
        struct.bid = self.bid
        return struct


class PY_TY_API_RT_SA_EVENT_QUEUE(object):
    def __init__(self, ul_EqEntryWord1 = 0, ul_EqEntryWord2 = 0, ul_EqEntryWord3 = 0, ul_EqEntryWord4 = 0):
        self.ul_EqEntryWord1 = ul_EqEntryWord1 # <class 'ctypes.c_ulong'>
        self.ul_EqEntryWord2 = ul_EqEntryWord2 # <class 'ctypes.c_ulong'>
        self.ul_EqEntryWord3 = ul_EqEntryWord3 # <class 'ctypes.c_ulong'>
        self.ul_EqEntryWord4 = ul_EqEntryWord4 # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_EqEntryWord1, struct.ul_EqEntryWord2, struct.ul_EqEntryWord3, struct.ul_EqEntryWord4)
    
    def toStruct(self):
        struct = amb.ty_api_rt_sa_event_queue()
        struct.ul_EqEntryWord1 = self.ul_EqEntryWord1
        struct.ul_EqEntryWord2 = self.ul_EqEntryWord2
        struct.ul_EqEntryWord3 = self.ul_EqEntryWord3
        struct.ul_EqEntryWord4 = self.ul_EqEntryWord4
        return struct


class PY_TY_API_RT_SA_MSG_DSP(object):
    def __init__(self, bid = 0, trw = 0, lcw = 0, lsw = 0, bufp = 0, ttag = 0):
        self.bid = bid # <class 'ctypes.c_ushort'>
        self.trw = trw # <class 'ctypes.c_ushort'>
        self.lcw = lcw # <class 'ctypes.c_ushort'>
        self.lsw = lsw # <class 'ctypes.c_ushort'>
        self.bufp = bufp # <class 'ctypes.c_ulong'>
        self.ttag = ttag # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.bid, struct.trw, struct.lcw, struct.lsw, struct.bufp, struct.ttag)
    
    def toStruct(self):
        struct = amb.ty_api_rt_sa_msg_dsp()
        struct.bid = self.bid
        struct.trw = self.trw
        struct.lcw = self.lcw
        struct.lsw = self.lsw
        struct.bufp = self.bufp
        struct.ttag = self.ttag
        return struct


class PY_TY_API_RT_SA_MSG_READ_IN(object):
    def __init__(self, ul_RtAddr = 0, ul_SA = 0, ul_SaType = 0, ul_Biu = 0):
        self.ul_RtAddr = ul_RtAddr # <class 'ctypes.c_ulong'>
        self.ul_SA = ul_SA # <class 'ctypes.c_ulong'>
        self.ul_SaType = ul_SaType # <class 'ctypes.c_ulong'>
        self.ul_Biu = ul_Biu # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_RtAddr, struct.ul_SA, struct.ul_SaType, struct.ul_Biu)
    
    def toStruct(self):
        struct = amb.ty_api_rt_sa_msg_read_in()
        struct.ul_RtAddr = self.ul_RtAddr
        struct.ul_SA = self.ul_SA
        struct.ul_SaType = self.ul_SaType
        struct.ul_Biu = self.ul_Biu
        return struct


class PY_TY_API_RT_SA_STATUS_INFO(object):
    def __init__(self, ul_ActBufferId = 0, ul_ActionWord = 0, ul_XferCnt = 0, ul_ErrCnt = 0):
        self.ul_ActBufferId = ul_ActBufferId # <class 'ctypes.c_ulong'>
        self.ul_ActionWord = ul_ActionWord # <class 'ctypes.c_ulong'>
        self.ul_XferCnt = ul_XferCnt # <class 'ctypes.c_ulong'>
        self.ul_ErrCnt = ul_ErrCnt # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_ActBufferId, struct.ul_ActionWord, struct.ul_XferCnt, struct.ul_ErrCnt)
    
    def toStruct(self):
        struct = amb.ty_api_rt_sa_status_info()
        struct.ul_ActBufferId = self.ul_ActBufferId
        struct.ul_ActionWord = self.ul_ActionWord
        struct.ul_XferCnt = self.ul_XferCnt
        struct.ul_ErrCnt = self.ul_ErrCnt
        return struct


class PY_TY_API_RT_SA_STATUS_QUEUE(object):
    def __init__(self, ul_SqCtrlWord = 0, ul_SqStatusWords = 0, ul_SqActBufPtr = 0, ul_SqTimeTag = 0):
        self.ul_SqCtrlWord = ul_SqCtrlWord # <class 'ctypes.c_ulong'>
        self.ul_SqStatusWords = ul_SqStatusWords # <class 'ctypes.c_ulong'>
        self.ul_SqActBufPtr = ul_SqActBufPtr # <class 'ctypes.c_ulong'>
        self.ul_SqTimeTag = ul_SqTimeTag # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_SqCtrlWord, struct.ul_SqStatusWords, struct.ul_SqActBufPtr, struct.ul_SqTimeTag)
    
    def toStruct(self):
        struct = amb.ty_api_rt_sa_status_queue()
        struct.ul_SqCtrlWord = self.ul_SqCtrlWord
        struct.ul_SqStatusWords = self.ul_SqStatusWords
        struct.ul_SqActBufPtr = self.ul_SqActBufPtr
        struct.ul_SqTimeTag = self.ul_SqTimeTag
        return struct


class PY_TY_API_RT_STATUS_DSP(object):
    def __init__(self, status = 0, padding1 = 0, padding2 = 0, glb_msg_cnt = 0, glb_err_cnt = 0):
        self.status = status # <class 'ctypes.c_ubyte'>
        self.padding1 = padding1 # <class 'ctypes.c_ubyte'>
        self.padding2 = padding2 # <class 'ctypes.c_ushort'>
        self.glb_msg_cnt = glb_msg_cnt # <class 'ctypes.c_ulong'>
        self.glb_err_cnt = glb_err_cnt # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.status, struct.padding1, struct.padding2, struct.glb_msg_cnt, struct.glb_err_cnt)
    
    def toStruct(self):
        struct = amb.ty_api_rt_status_dsp()
        struct.status = self.status
        struct.padding1 = self.padding1
        struct.padding2 = self.padding2
        struct.glb_msg_cnt = self.glb_msg_cnt
        struct.glb_err_cnt = self.glb_err_cnt
        return struct


class PY_TY_API_SCOPE_CALIBRATION_INFO(object):
    def __init__(self, lOffsetA = 0, lOffsetB = 0, lOffsetA100 = 0, lOffsetB100 = 0, lOffsetA100Sec = 0, lOffsetB100Sec = 0):
        self.lOffsetA = lOffsetA # <class 'ctypes.c_ulong'>
        self.lOffsetB = lOffsetB # <class 'ctypes.c_ulong'>
        self.lOffsetA100 = lOffsetA100 # <class 'ctypes.c_ulong'>
        self.lOffsetB100 = lOffsetB100 # <class 'ctypes.c_ulong'>
        self.lOffsetA100Sec = lOffsetA100Sec # <class 'ctypes.c_ulong'>
        self.lOffsetB100Sec = lOffsetB100Sec # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.lOffsetA, struct.lOffsetB, struct.lOffsetA100, struct.lOffsetB100, struct.lOffsetA100Sec, struct.lOffsetB100Sec)
    
    def toStruct(self):
        struct = amb.ty_api_scope_calibration_info()
        struct.lOffsetA = self.lOffsetA
        struct.lOffsetB = self.lOffsetB
        struct.lOffsetA100 = self.lOffsetA100
        struct.lOffsetB100 = self.lOffsetB100
        struct.lOffsetA100Sec = self.lOffsetA100Sec
        struct.lOffsetB100Sec = self.lOffsetB100Sec
        return struct


class PY_TY_API_SCOPE_SETUP(object):
    def __init__(self, ul_CouplingPri = 0, ul_CouplingSec = 0, ul_SamplingRate = 0, ul_CaptureMode = 0, ul_OperationMode = 0, ul_SingleShotBuf = 0):
        self.ul_CouplingPri = ul_CouplingPri # <class 'ctypes.c_ulong'>
        self.ul_CouplingSec = ul_CouplingSec # <class 'ctypes.c_ulong'>
        self.ul_SamplingRate = ul_SamplingRate # <class 'ctypes.c_ulong'>
        self.ul_CaptureMode = ul_CaptureMode # <class 'ctypes.c_ulong'>
        self.ul_OperationMode = ul_OperationMode # <class 'ctypes.c_ulong'>
        self.ul_SingleShotBuf = ul_SingleShotBuf # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_CouplingPri, struct.ul_CouplingSec, struct.ul_SamplingRate, struct.ul_CaptureMode, struct.ul_OperationMode, struct.ul_SingleShotBuf)
    
    def toStruct(self):
        struct = amb.ty_api_scope_setup()
        struct.ul_CouplingPri = self.ul_CouplingPri
        struct.ul_CouplingSec = self.ul_CouplingSec
        struct.ul_SamplingRate = self.ul_SamplingRate
        struct.ul_CaptureMode = self.ul_CaptureMode
        struct.ul_OperationMode = self.ul_OperationMode
        struct.ul_SingleShotBuf = self.ul_SingleShotBuf
        return struct


class PY_TY_API_SCOPE_TRG(object):
    def __init__(self, ul_TrgMode = 0, ul_TrgSrc = 0, ul_TrgValue = 0, ul_TrgNbSamples = 0, ul_TrgFlags = 0, ul_TrgDelay = 0, ul_TrgTbt = 0):
        self.ul_TrgMode = ul_TrgMode # <class 'ctypes.c_ulong'>
        self.ul_TrgSrc = ul_TrgSrc # <class 'ctypes.c_ulong'>
        self.ul_TrgValue = ul_TrgValue # <class 'ctypes.c_ulong'>
        self.ul_TrgNbSamples = ul_TrgNbSamples # <class 'ctypes.c_ulong'>
        self.ul_TrgFlags = ul_TrgFlags # <class 'ctypes.c_ulong'>
        self.ul_TrgDelay = ul_TrgDelay # <class 'ctypes.c_ulong'>
        self.ul_TrgTbt = ul_TrgTbt # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_TrgMode, struct.ul_TrgSrc, struct.ul_TrgValue, struct.ul_TrgNbSamples, struct.ul_TrgFlags, struct.ul_TrgDelay, struct.ul_TrgTbt)
    
    def toStruct(self):
        struct = amb.ty_api_scope_trg()
        struct.ul_TrgMode = self.ul_TrgMode
        struct.ul_TrgSrc = self.ul_TrgSrc
        struct.ul_TrgValue = self.ul_TrgValue
        struct.ul_TrgNbSamples = self.ul_TrgNbSamples
        struct.ul_TrgFlags = self.ul_TrgFlags
        struct.ul_TrgDelay = self.ul_TrgDelay
        struct.ul_TrgTbt = self.ul_TrgTbt
        return struct


class PY_TY_API_SET_MEM_LAYOUT(object):
    def __init__(self, aul_SimBufSize = None, ax_BiuSize = None, ax_BiuCnt = None):
        self.aul_SimBufSize = [] if aul_SimBufSize == None else aul_SimBufSize # <class 'mil_bindings.c_ulong_Array_2'>
        self.ax_BiuSize = [] if ax_BiuSize == None else ax_BiuSize # <class 'mil_bindings.ty_api_mem_biu_size_Array_8'>
        self.ax_BiuCnt = [] if ax_BiuCnt == None else ax_BiuCnt # <class 'mil_bindings.ty_api_mem_biu_count_Array_8'>
    
    @classmethod
    def fromStruct(cls, struct):
        # FIXME: autogenerated code needs adaptation.
        return cls(struct.aul_SimBufSize, struct.ax_BiuSize, struct.ax_BiuCnt)
    
    def toStruct(self):
        # FIXME: autogenerated code needs adaptation.
        struct = amb.ty_api_set_mem_layout()
        struct.aul_SimBufSize = self.aul_SimBufSize
        struct.ax_BiuSize = self.ax_BiuSize
        struct.ax_BiuCnt = self.ax_BiuCnt
        return struct


class PY_TY_API_SYNC_CNT_GET(object):
    def __init__(self, ul_SyncCntVal = 0, ul_SyncCntInit = 0, ul_SyncCntInitLow = 0, ul_SyncCntInitHigh = 0):
        self.ul_SyncCntVal = ul_SyncCntVal # <class 'ctypes.c_ulong'>
        self.ul_SyncCntInit = ul_SyncCntInit # <class 'ctypes.c_ulong'>
        self.ul_SyncCntInitLow = ul_SyncCntInitLow # <class 'ctypes.c_ulong'>
        self.ul_SyncCntInitHigh = ul_SyncCntInitHigh # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_SyncCntVal, struct.ul_SyncCntInit, struct.ul_SyncCntInitLow, struct.ul_SyncCntInitHigh)
    
    def toStruct(self):
        struct = amb.ty_api_sync_cnt_get()
        struct.ul_SyncCntVal = self.ul_SyncCntVal
        struct.ul_SyncCntInit = self.ul_SyncCntInit
        struct.ul_SyncCntInitLow = self.ul_SyncCntInitLow
        struct.ul_SyncCntInitHigh = self.ul_SyncCntInitHigh
        return struct


class PY_TY_API_SYNC_CNT_SET(object):
    def __init__(self, ul_SyncCntVal = 0):
        self.ul_SyncCntVal = ul_SyncCntVal # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_SyncCntVal)
    
    def toStruct(self):
        struct = amb.ty_api_sync_cnt_set()
        struct.ul_SyncCntVal = self.ul_SyncCntVal
        return struct


class PY_TY_API_SYSTAG(object):
    def __init__(self, xid_rtsa = 0, fct = 0, min = 0, max = 0, step = 0, wpos = 0, bpos = 0):
        self.xid_rtsa = xid_rtsa # <class 'ctypes.c_ushort'>
        self.fct = fct # <class 'ctypes.c_ushort'>
        self.min = min # <class 'ctypes.c_ushort'>
        self.max = max # <class 'ctypes.c_ushort'>
        self.step = step # <class 'ctypes.c_ushort'>
        self.wpos = wpos # <class 'ctypes.c_ushort'>
        self.bpos = bpos # <class 'ctypes.c_ushort'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.xid_rtsa, struct.fct, struct.min, struct.max, struct.step, struct.wpos, struct.bpos)
    
    def toStruct(self):
        struct = amb.ty_api_systag()
        struct.xid_rtsa = self.xid_rtsa
        struct.fct = self.fct
        struct.min = self.min
        struct.max = self.max
        struct.step = self.step
        struct.wpos = self.wpos
        struct.bpos = self.bpos
        return struct


class PY_TY_API_TRACK_DEF_IN(object):
    def __init__(self, ul_TrackId = 0, ul_BT = 0, ul_XidRtSa = 0, ul_Mode = 0, ul_TrackStartPos = 0, ul_TrackBPos = 0, ul_TrackBLen = 0, ul_TrackLen = 0, ul_MultiplexedTrackNb = 0, ul_ContinousTrackNb = 0, l_Offset = 0):
        self.ul_TrackId = ul_TrackId # <class 'ctypes.c_ulong'>
        self.ul_BT = ul_BT # <class 'ctypes.c_ulong'>
        self.ul_XidRtSa = ul_XidRtSa # <class 'ctypes.c_ulong'>
        self.ul_Mode = ul_Mode # <class 'ctypes.c_ulong'>
        self.ul_TrackStartPos = ul_TrackStartPos # <class 'ctypes.c_ulong'>
        self.ul_TrackBPos = ul_TrackBPos # <class 'ctypes.c_ulong'>
        self.ul_TrackBLen = ul_TrackBLen # <class 'ctypes.c_ulong'>
        self.ul_TrackLen = ul_TrackLen # <class 'ctypes.c_ulong'>
        self.ul_MultiplexedTrackNb = ul_MultiplexedTrackNb # <class 'ctypes.c_ulong'>
        self.ul_ContinousTrackNb = ul_ContinousTrackNb # <class 'ctypes.c_ulong'>
        self.l_Offset = l_Offset # <class 'ctypes.c_long'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_TrackId, struct.ul_BT, struct.ul_XidRtSa, struct.ul_Mode, struct.ul_TrackStartPos, struct.ul_TrackBPos, struct.ul_TrackBLen, struct.ul_TrackLen, struct.ul_MultiplexedTrackNb, struct.ul_ContinousTrackNb, struct.l_Offset)
    
    def toStruct(self):
        struct = amb.ty_api_track_def_in()
        struct.ul_TrackId = self.ul_TrackId
        struct.ul_BT = self.ul_BT
        struct.ul_XidRtSa = self.ul_XidRtSa
        struct.ul_Mode = self.ul_Mode
        struct.ul_TrackStartPos = self.ul_TrackStartPos
        struct.ul_TrackBPos = self.ul_TrackBPos
        struct.ul_TrackBLen = self.ul_TrackBLen
        struct.ul_TrackLen = self.ul_TrackLen
        struct.ul_MultiplexedTrackNb = self.ul_MultiplexedTrackNb
        struct.ul_ContinousTrackNb = self.ul_ContinousTrackNb
        struct.l_Offset = self.l_Offset
        return struct


class PY_TY_API_TRACK_DEF_OUT(object):
    def __init__(self, ul_TrackBufferStartAddr = 0):
        self.ul_TrackBufferStartAddr = ul_TrackBufferStartAddr # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_TrackBufferStartAddr)
    
    def toStruct(self):
        struct = amb.ty_api_track_def_out()
        struct.ul_TrackBufferStartAddr = self.ul_TrackBufferStartAddr
        return struct


class PY_TY_API_TRACK_PREALLOC_IN(object):
    def __init__(self, ul_TrackId = 0, ul_PreAllocNb = 0, pul_MuxStates = None):
        self.ul_TrackId = ul_TrackId # <class 'ctypes.c_ulong'>
        self.ul_PreAllocNb = ul_PreAllocNb # <class 'ctypes.c_ulong'>
        self.pul_MuxStates = pul_MuxStates # <class 'mil_bindings.LP_c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_TrackId, struct.ul_PreAllocNb, struct.pul_MuxStates)
    
    def toStruct(self):
        struct = amb.ty_api_track_prealloc_in()
        struct.ul_TrackId = self.ul_TrackId
        struct.ul_PreAllocNb = self.ul_PreAllocNb
        struct.pul_MuxStates = self.pul_MuxStates
        return struct


class PY_TY_API_TRACK_PREALLOC_OUT(object):
    def __init__(self, pul_TrackBufferStartAddr = None):
        self.pul_TrackBufferStartAddr = pul_TrackBufferStartAddr # <class 'mil_bindings.LP_c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.pul_TrackBufferStartAddr)
    
    def toStruct(self):
        struct = amb.ty_api_track_prealloc_out()
        struct.pul_TrackBufferStartAddr = self.pul_TrackBufferStartAddr
        return struct


class PY_TY_API_TRACK_READ_IN(object):
    def __init__(self, ul_TrackId = 0, ul_MultiplexedTrackIndex = 0, ul_ReadMode = 0):
        self.ul_TrackId = ul_TrackId # <class 'ctypes.c_ulong'>
        self.ul_MultiplexedTrackIndex = ul_MultiplexedTrackIndex # <class 'ctypes.c_ulong'>
        self.ul_ReadMode = ul_ReadMode # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_TrackId, struct.ul_MultiplexedTrackIndex, struct.ul_ReadMode)
    
    def toStruct(self):
        struct = amb.ty_api_track_read_in()
        struct.ul_TrackId = self.ul_TrackId
        struct.ul_MultiplexedTrackIndex = self.ul_MultiplexedTrackIndex
        struct.ul_ReadMode = self.ul_ReadMode
        return struct


class PY_TY_API_TRACK_READ_OUT(object):
    def __init__(self, ul_DataValid = 0, ul_LastTT = 0, puw_TrackDataWords = None):
        self.ul_DataValid = ul_DataValid # <class 'ctypes.c_ulong'>
        self.ul_LastTT = ul_LastTT # <class 'ctypes.c_ulong'>
        self.puw_TrackDataWords = puw_TrackDataWords # <class 'mil_bindings.LP_c_ushort'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_DataValid, struct.ul_LastTT, struct.puw_TrackDataWords)
    
    def toStruct(self):
        struct = amb.ty_api_track_read_out()
        struct.ul_DataValid = self.ul_DataValid
        struct.ul_LastTT = self.ul_LastTT
        struct.puw_TrackDataWords = self.puw_TrackDataWords
        return struct


class PY_TY_API_TRACK_SCAN_IN(object):
    def __init__(self, ul_TrackId = 0, ul_ChunkNb = 0, ul_ChunkSize = 0):
        self.ul_TrackId = ul_TrackId # <class 'ctypes.c_ulong'>
        self.ul_ChunkNb = ul_ChunkNb # <class 'ctypes.c_ulong'>
        self.ul_ChunkSize = ul_ChunkSize # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_TrackId, struct.ul_ChunkNb, struct.ul_ChunkSize)
    
    def toStruct(self):
        struct = amb.ty_api_track_scan_in()
        struct.ul_TrackId = self.ul_TrackId
        struct.ul_ChunkNb = self.ul_ChunkNb
        struct.ul_ChunkSize = self.ul_ChunkSize
        return struct


class PY_TY_API_TRACK_SCAN_OUT(object):
    def __init__(self, ul_NumberOfReturnedStates = 0, ul_MoreData = 0, pul_ReturnedStates = None):
        self.ul_NumberOfReturnedStates = ul_NumberOfReturnedStates # <class 'ctypes.c_ulong'>
        self.ul_MoreData = ul_MoreData # <class 'ctypes.c_ulong'>
        self.pul_ReturnedStates = pul_ReturnedStates # <class 'mil_bindings.LP_c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_NumberOfReturnedStates, struct.ul_MoreData, struct.pul_ReturnedStates)
    
    def toStruct(self):
        struct = amb.ty_api_track_scan_out()
        struct.ul_NumberOfReturnedStates = self.ul_NumberOfReturnedStates
        struct.ul_MoreData = self.ul_MoreData
        struct.pul_ReturnedStates = self.pul_ReturnedStates
        return struct


class PY_TY_API_VER_INFO_STRINGS(object):
    def __init__(self, ac_Description = None, ac_FullVersion = None):
        self.ac_Description = '' if ac_Description == None else ac_Description # <class 'mil_bindings.c_char_Array_256'>
        self.ac_FullVersion = '' if ac_FullVersion == None else ac_FullVersion # <class 'mil_bindings.c_char_Array_256'>
    
    @classmethod
    def fromStruct(cls, struct):
        # FIXME: autogenerated code needs adaptation.
        return cls(struct.ac_Description, struct.ac_FullVersion)
    
    def toStruct(self):
        # FIXME: autogenerated code needs adaptation.
        struct = amb.ty_api_ver_info_strings()
        struct.ac_Description = self.ac_Description
        struct.ac_FullVersion = self.ac_FullVersion
        return struct


class PY_TY_API_VER_INFO_VALUES(object):
    def __init__(self, ul_VersionType = 0, ul_MajorVer = 0, ul_MinorVer = 0, ul_PatchVersion = 0, ul_BuildNr = 0):
        self.ul_VersionType = ul_VersionType # <class 'ctypes.c_ulong'>
        self.ul_MajorVer = ul_MajorVer # <class 'ctypes.c_ulong'>
        self.ul_MinorVer = ul_MinorVer # <class 'ctypes.c_ulong'>
        self.ul_PatchVersion = ul_PatchVersion # <class 'ctypes.c_ulong'>
        self.ul_BuildNr = ul_BuildNr # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_VersionType, struct.ul_MajorVer, struct.ul_MinorVer, struct.ul_PatchVersion, struct.ul_BuildNr)
    
    def toStruct(self):
        struct = amb.ty_api_ver_info_values()
        struct.ul_VersionType = self.ul_VersionType
        struct.ul_MajorVer = self.ul_MajorVer
        struct.ul_MinorVer = self.ul_MinorVer
        struct.ul_PatchVersion = self.ul_PatchVersion
        struct.ul_BuildNr = self.ul_BuildNr
        return struct


class PY_TY_API_VERSION(object):
    def __init__(self, ul_MajorVer = 0, ul_MinorVer = 0, ul_BuildNo = 0, ul_MajorSpecialVer = 0, ul_MinorSpecialVer = 0):
        self.ul_MajorVer = ul_MajorVer # <class 'ctypes.c_ulong'>
        self.ul_MinorVer = ul_MinorVer # <class 'ctypes.c_ulong'>
        self.ul_BuildNo = ul_BuildNo # <class 'ctypes.c_ulong'>
        self.ul_MajorSpecialVer = ul_MajorSpecialVer # <class 'ctypes.c_ulong'>
        self.ul_MinorSpecialVer = ul_MinorSpecialVer # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_MajorVer, struct.ul_MinorVer, struct.ul_BuildNo, struct.ul_MajorSpecialVer, struct.ul_MinorSpecialVer)
    
    def toStruct(self):
        struct = amb.ty_api_version()
        struct.ul_MajorVer = self.ul_MajorVer
        struct.ul_MinorVer = self.ul_MinorVer
        struct.ul_BuildNo = self.ul_BuildNo
        struct.ul_MajorSpecialVer = self.ul_MajorSpecialVer
        struct.ul_MinorSpecialVer = self.ul_MinorSpecialVer
        return struct

class PY_TY_COUPLING_CAPABILITIES(object):
    def __init__(self, b_DigitalWrap = 0, b_Packed = 0, b_Network = 0, b_Transformer = 0, b_Direct = 0, b_Isolated = 0):
        self.b_DigitalWrap = b_DigitalWrap # <class 'ctypes.c_ulong'>
        self.b_Packed = b_Packed # <class 'ctypes.c_ulong'>
        self.b_Network = b_Network # <class 'ctypes.c_ulong'>
        self.b_Transformer = b_Transformer # <class 'ctypes.c_ulong'>
        self.b_Direct = b_Direct # <class 'ctypes.c_ulong'>
        self.b_Isolated = b_Isolated # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromUnion(cls, union):
        return cls(union.b.b_DigitalWrap, union.b.b_Packed, union.b.b_Network, union.b.b_Transformer, union.b.b_Direct, union.b.b_Isolated)
    
    @classmethod
    def fromBitfield(cls, value):
        union = amb.ty_coupling_capabilities_union()
        union.ul_All = value
        return cls(union.b.b_DigitalWrap, union.b.b_Packed, union.b.b_Network, union.b.b_Transformer, union.b.b_Direct, union.b.b_Isolated)
    
    def toUnion(self):
        union = amb.ty_coupling_capabilities_union()
        union.b.ul_Res = 0
        union.b.b_DigitalWrap = self.b.b_DigitalWrap
        union.b.b_Packed = self.b.b_Packed
        union.b.b_Network = self.b.b_Network
        union.b.b_Transformer = self.b.b_Transformer
        union.b.b_Direct = self.b.b_Direct
        union.b.b_Isolated = self.b.b_Isolated
        return union

class PY_TY_DRIVER_INFO(object):
    def __init__(self, uc_DeviceGroup = 0, uc_ReservedB2 = 0, uc_ReservedB3 = 0, uc_ReservedB4 = 0, uw_ReservedW1 = 0, uw_ReservedW2 = 0, ul_DriverFlags = 0, ul_SN = 0, ul_BoardConfig = 0, ul_BoardType = 0, ul_OpenConnections = 0, ul_ReservedLW6 = 0, ul_ReservedLW7 = 0, ul_ReservedLW8 = 0):
        self.uc_DeviceGroup = uc_DeviceGroup # <class 'ctypes.c_ubyte'>
        self.uc_ReservedB2 = uc_ReservedB2 # <class 'ctypes.c_ubyte'>
        self.uc_ReservedB3 = uc_ReservedB3 # <class 'ctypes.c_ubyte'>
        self.uc_ReservedB4 = uc_ReservedB4 # <class 'ctypes.c_ubyte'>
        self.uw_ReservedW1 = uw_ReservedW1 # <class 'ctypes.c_ushort'>
        self.uw_ReservedW2 = uw_ReservedW2 # <class 'ctypes.c_ushort'>
        self.ul_DriverFlags = ul_DriverFlags # <class 'ctypes.c_ulong'>
        self.ul_SN = ul_SN # <class 'ctypes.c_ulong'>
        self.ul_BoardConfig = ul_BoardConfig # <class 'ctypes.c_ulong'>
        self.ul_BoardType = ul_BoardType # <class 'ctypes.c_ulong'>
        self.ul_OpenConnections = ul_OpenConnections # <class 'ctypes.c_ulong'>
        self.ul_ReservedLW6 = ul_ReservedLW6 # <class 'ctypes.c_ulong'>
        self.ul_ReservedLW7 = ul_ReservedLW7 # <class 'ctypes.c_ulong'>
        self.ul_ReservedLW8 = ul_ReservedLW8 # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.uc_DeviceGroup, struct.uc_ReservedB2, struct.uc_ReservedB3, struct.uc_ReservedB4, struct.uw_ReservedW1, struct.uw_ReservedW2, struct.ul_DriverFlags, struct.ul_SN, struct.ul_BoardConfig, struct.ul_BoardType, struct.ul_OpenConnections, struct.ul_ReservedLW6, struct.ul_ReservedLW7, struct.ul_ReservedLW8)
    
    def toStruct(self):
        struct = amb.ty_driver_info()
        struct.uc_DeviceGroup = self.uc_DeviceGroup
        struct.uc_ReservedB2 = self.uc_ReservedB2
        struct.uc_ReservedB3 = self.uc_ReservedB3
        struct.uc_ReservedB4 = self.uc_ReservedB4
        struct.uw_ReservedW1 = self.uw_ReservedW1
        struct.uw_ReservedW2 = self.uw_ReservedW2
        struct.ul_DriverFlags = self.ul_DriverFlags
        struct.ul_SN = self.ul_SN
        struct.ul_BoardConfig = self.ul_BoardConfig
        struct.ul_BoardType = self.ul_BoardType
        struct.ul_OpenConnections = self.ul_OpenConnections
        struct.ul_ReservedLW6 = self.ul_ReservedLW6
        struct.ul_ReservedLW7 = self.ul_ReservedLW7
        struct.ul_ReservedLW8 = self.ul_ReservedLW8
        return struct


class PY_TY_IR_CAPABILITIES_B(object):
    def __init__(self, ul_Res = 0, b_IrOnDiscretes = 0):
        self.ul_Res = ul_Res # <class 'ctypes.c_ulong'>
        self.b_IrOnDiscretes = b_IrOnDiscretes # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_Res, struct.b_IrOnDiscretes)
    
    def toStruct(self):
        struct = amb.ty_ir_capabilities_b()
        struct.ul_Res = self.ul_Res
        struct.b_IrOnDiscretes = self.b_IrOnDiscretes
        return struct


class PY_TY_IRIG_CAPABILITIES(object):
    def __init__(self, ul_Res = 0, b_Sinusoidal = 0, b_FreeWheeling = 0, b_IrigSwitch = 0, b_InstantIrigSetOnInternalMode = 0, b_NoExternalSignalOnInternalMode = 0):
        self.ul_Res = ul_Res # <class 'ctypes.c_ulong'>
        self.b_NoExternalSignalOnInternalMode = b_NoExternalSignalOnInternalMode # <class 'ctypes.c_ulong'>
        self.b_InstantIrigSetOnInternalMode = b_InstantIrigSetOnInternalMode # <class 'ctypes.c_ulong'>
        self.b_Sinusoidal = b_Sinusoidal # <class 'ctypes.c_ulong'>
        self.b_FreeWheeling = b_FreeWheeling # <class 'ctypes.c_ulong'>
        self.b_IrigSwitch = b_IrigSwitch # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromUnion(cls, union):
        return cls(union.b.ul_Res, union.b.b_Sinusoidal, union.b.b_FreeWheeling, union.b.b_IrigSwitch, union.b.b_InstantIrigSetOnInternalMode, union.b.b_NoExternalSignalOnInternalMode)

    @classmethod
    def fromBitfield(cls, value):
        union = amb.ty_irig_capabilities_union()
        union.ul_All = value
        return cls(union.b.ul_Res, union.b.b_Sinusoidal, union.b.b_FreeWheeling, union.b.b_IrigSwitch, union.b.b_InstantIrigSetOnInternalMode, union.b.b_NoExternalSignalOnInternalMode)
    
    def toUnion(self):
        union = amb.ty_irig_capabilities_b()
        union.b.ul_Res = self.ul_Res
        union.b.b_NoExternalSignalOnInternalMode = self.b_NoExternalSignalOnInternalMode
        union.b.b_InstantIrigSetOnInternalMode = self.b_InstantIrigSetOnInternalMode
        union.b.b_Sinusoidal = self.b_Sinusoidal
        union.b.b_FreeWheeling = self.b_FreeWheeling
        union.b.b_IrigSwitch = self.b_IrigSwitch
        return union


class PY_TY_MIL_COM(object):
    def __init__(self, ulMagic = 0, ulStream = 0, ulCommand = 0, ulSize = 0, ulExpectedAckSize = 0, ulSwapControl = 0, ulReserved_3 = 0, ulReserved_4 = 0):
        self.ulMagic = ulMagic # <class 'ctypes.c_ulong'>
        self.ulStream = ulStream # <class 'ctypes.c_ulong'>
        self.ulCommand = ulCommand # <class 'ctypes.c_ulong'>
        self.ulSize = ulSize # <class 'ctypes.c_ulong'>
        self.ulExpectedAckSize = ulExpectedAckSize # <class 'ctypes.c_ulong'>
        self.ulSwapControl = ulSwapControl # <class 'ctypes.c_ulong'>
        self.ulReserved_3 = ulReserved_3 # <class 'ctypes.c_ulong'>
        self.ulReserved_4 = ulReserved_4 # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ulMagic, struct.ulStream, struct.ulCommand, struct.ulSize, struct.ulExpectedAckSize, struct.ulSwapControl, struct.ulReserved_3, struct.ulReserved_4)
    
    def toStruct(self):
        struct = amb.ty_mil_com()
        struct.ulMagic = self.ulMagic
        struct.ulStream = self.ulStream
        struct.ulCommand = self.ulCommand
        struct.ulSize = self.ulSize
        struct.ulExpectedAckSize = self.ulExpectedAckSize
        struct.ulSwapControl = self.ulSwapControl
        struct.ulReserved_3 = self.ulReserved_3
        struct.ulReserved_4 = self.ulReserved_4
        return struct


class PY_TY_MIL_COM_ACK(object):
    def __init__(self, ulMagic = 0, ulCommand = 0, ulError = 0, ulSize = 0, ulSwapControl = 0, ulReserved_2 = 0, ulReserved_3 = 0, ulReserved_4 = 0):
        self.ulMagic = ulMagic # <class 'ctypes.c_ulong'>
        self.ulCommand = ulCommand # <class 'ctypes.c_ulong'>
        self.ulError = ulError # <class 'ctypes.c_ulong'>
        self.ulSize = ulSize # <class 'ctypes.c_ulong'>
        self.ulSwapControl = ulSwapControl # <class 'ctypes.c_ulong'>
        self.ulReserved_2 = ulReserved_2 # <class 'ctypes.c_ulong'>
        self.ulReserved_3 = ulReserved_3 # <class 'ctypes.c_ulong'>
        self.ulReserved_4 = ulReserved_4 # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ulMagic, struct.ulCommand, struct.ulError, struct.ulSize, struct.ulSwapControl, struct.ulReserved_2, struct.ulReserved_3, struct.ulReserved_4)
    
    def toStruct(self):
        struct = amb.ty_mil_com_ack()
        struct.ulMagic = self.ulMagic
        struct.ulCommand = self.ulCommand
        struct.ulError = self.ulError
        struct.ulSize = self.ulSize
        struct.ulSwapControl = self.ulSwapControl
        struct.ulReserved_2 = self.ulReserved_2
        struct.ulReserved_3 = self.ulReserved_3
        struct.ulReserved_4 = self.ulReserved_4
        return struct


class PY_TY_VER_INFO(object):
    def __init__(self, ul_VersionType = 0, ac_Description = None, ul_MajorVer = 0, ul_MinorVer = 0, ul_PatchVersion = 0, ul_BuildNr = 0, ac_FullVersion = None):
        self.ul_VersionType = ul_VersionType # <class 'ctypes.c_ulong'>
        self.ac_Description = '' if ac_Description == None else ac_Description # <class 'mil_bindings.c_char_Array_256'>
        self.ul_MajorVer = ul_MajorVer # <class 'ctypes.c_ulong'>
        self.ul_MinorVer = ul_MinorVer # <class 'ctypes.c_ulong'>
        self.ul_PatchVersion = ul_PatchVersion # <class 'ctypes.c_ulong'>
        self.ul_BuildNr = ul_BuildNr # <class 'ctypes.c_ulong'>
        self.ac_FullVersion = '' if ac_FullVersion == None else ac_FullVersion # <class 'mil_bindings.c_char_Array_256'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_VersionType, struct.ac_Description.decode("utf-8"), struct.ul_MajorVer, struct.ul_MinorVer, struct.ul_PatchVersion, struct.ul_BuildNr, struct.ac_FullVersion.decode("utf-8"))
    
    def toStruct(self):
        struct = amb.ty_ver_info()
        struct.ul_VersionType = self.ul_VersionType
        struct.ac_Description = self.ac_Description.encode("utf-8")
        struct.ul_MajorVer = self.ul_MajorVer
        struct.ul_MinorVer = self.ul_MinorVer
        struct.ul_PatchVersion = self.ul_PatchVersion
        struct.ul_BuildNr = self.ul_BuildNr
        struct.ac_FullVersion = self.ac_FullVersion.encode("utf-8")
        return struct


class PY_TY_VER_NO(object):
    def __init__(self, ul_MajorVer = 0, ul_MinorVer = 0, ul_BuildNr = 0, ul_MajorSpecialVer = 0, ul_MinorSpecialVer = 0):
        self.ul_MajorVer = ul_MajorVer # <class 'ctypes.c_ulong'>
        self.ul_MinorVer = ul_MinorVer # <class 'ctypes.c_ulong'>
        self.ul_BuildNr = ul_BuildNr # <class 'ctypes.c_ulong'>
        self.ul_MajorSpecialVer = ul_MajorSpecialVer # <class 'ctypes.c_ulong'>
        self.ul_MinorSpecialVer = ul_MinorSpecialVer # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_MajorVer, struct.ul_MinorVer, struct.ul_BuildNr, struct.ul_MajorSpecialVer, struct.ul_MinorSpecialVer)
    
    def toStruct(self):
        struct = amb.ty_ver_no()
        struct.ul_MajorVer = self.ul_MajorVer
        struct.ul_MinorVer = self.ul_MinorVer
        struct.ul_BuildNr = self.ul_BuildNr
        struct.ul_MajorSpecialVer = self.ul_MajorSpecialVer
        struct.ul_MinorSpecialVer = self.ul_MinorSpecialVer
        return struct


class PY_TY_VERSION_OUT(object):
    def __init__(self, ul_Count = 0, ul_MaxCount = 0):
        self.ul_Count = ul_Count # <class 'ctypes.c_ulong'>
        self.ul_MaxCount = ul_MaxCount # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_Count, struct.ul_MaxCount)
    
    def toStruct(self):
        struct = amb.ty_version_out()
        struct.ul_Count = self.ul_Count
        struct.ul_MaxCount = self.ul_MaxCount
        return struct


class PY_TY_API_BC_XFER(object):
    def __init__(self, xid = 0, hid = 0, type = 0, chn = 0, xmt_rt = 0, rcv_rt = 0, xmt_sa = 0, rcv_sa = 0, wcnt = 0, tic = 0, hlt = 0, rte = 0, res = 0, sxh = 0, rsp = 0, gap_mode = 0, swxm = 0, err = None, gap = 0):
        self.xid = xid # <class 'ctypes.c_ushort'>
        self.hid = hid # <class 'ctypes.c_ushort'>
        self.type = type # <class 'ctypes.c_ubyte'>
        self.chn = chn # <class 'ctypes.c_ubyte'>
        self.xmt_rt = xmt_rt # <class 'ctypes.c_ubyte'>
        self.rcv_rt = rcv_rt # <class 'ctypes.c_ubyte'>
        self.xmt_sa = xmt_sa # <class 'ctypes.c_ubyte'>
        self.rcv_sa = rcv_sa # <class 'ctypes.c_ubyte'>
        self.wcnt = wcnt # <class 'ctypes.c_ubyte'>
        self.tic = tic # <class 'ctypes.c_ubyte'>
        self.hlt = hlt # <class 'ctypes.c_ubyte'>
        self.rte = rte # <class 'ctypes.c_ubyte'>
        self.res = res # <class 'ctypes.c_ubyte'>
        self.sxh = sxh # <class 'ctypes.c_ubyte'>
        self.rsp = rsp # <class 'ctypes.c_ubyte'>
        self.gap_mode = gap_mode # <class 'ctypes.c_ubyte'>
        self.swxm = swxm # <class 'ctypes.c_ushort'>
        self.err = ambt.PY_TY_API_BC_ERR() if  err == None else err # <class 'mil_bindings.ty_api_bc_err'>
        self.gap = gap # <class 'ctypes.c_ushort'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.xid, struct.hid, struct.type, struct.chn, struct.xmt_rt, struct.rcv_rt, struct.xmt_sa, struct.rcv_sa, struct.wcnt, struct.tic, struct.hlt, struct.rte, struct.res, struct.sxh, struct.rsp, struct.gap_mode, struct.swxm, ambt.PY_TY_API_BC_ERR.fromStruct(struct.err), struct.gap)
    
    def toStruct(self):
        struct = amb.ty_api_bc_xfer()
        struct.xid = self.xid
        struct.hid = self.hid
        struct.type = self.type
        struct.chn = self.chn
        struct.xmt_rt = self.xmt_rt
        struct.rcv_rt = self.rcv_rt
        struct.xmt_sa = self.xmt_sa
        struct.rcv_sa = self.rcv_sa
        struct.wcnt = self.wcnt
        struct.tic = self.tic
        struct.hlt = self.hlt
        struct.rte = self.rte
        struct.res = self.res
        struct.sxh = self.sxh
        struct.rsp = self.rsp
        struct.gap_mode = self.gap_mode
        struct.swxm = self.swxm
        struct.err = self.err.toStruct()
        struct.gap = self.gap
        return struct


class PY_TY_API_BC_XFER_STATUS_EX(object):
    def __init__(self, x_XferSQueue = None, x_XferEQueue = None, x_XferInfo = None, ul_BufferQueueSize = 0):
        self.x_XferSQueue = [ambt.PY_TY_API_BC_XFER_STATUS_QUEUE() for _ in range(256)] if x_XferSQueue == None else x_XferSQueue # <class 'mil_bindings.ty_api_bc_xfer_status_queue_Array_256'>
        self.x_XferEQueue = [ambt.PY_TY_API_BC_XFER_EVENT_QUEUE()] if x_XferEQueue == None else x_XferEQueue # <class 'mil_bindings.ty_api_bc_xfer_event_queue_Array_1'>
        self.x_XferInfo = ambt.PY_TY_API_BC_XFER_STATUS_INFO() if x_XferInfo == None else x_XferInfo # <class 'mil_bindings.ty_api_bc_xfer_status_info'>
        self.ul_BufferQueueSize = ul_BufferQueueSize # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls([ambt.PY_TY_API_BC_XFER_STATUS_QUEUE.fromStruct(sq) for sq in struct.x_XferSQueue], 
                   [ambt.PY_TY_API_BC_XFER_EVENT_QUEUE.fromStruct(struct.x_XferEQueue[0])], 
                   ambt.PY_TY_API_BC_XFER_STATUS_INFO.fromStruct(struct.x_XferInfo), 
                   struct.ul_BufferQueueSize)
    
    def toStruct(self):
        struct = amb.ty_api_bc_xfer_status_ex()
        for i in range(256):
            struct.x_XferSQueue[i] = self.x_XferSQueue[i].toStruct()
        struct.x_XferEQueue[0] = self.x_XferEQueue[0].toStruct() # Array size 1
        struct.x_XferInfo = self.x_XferInfo.toStruct()
        struct.ul_BufferQueueSize = self.ul_BufferQueueSize
        return struct


class PY_TY_API_BOARD_INFO(object):
    def __init__(self, ul_DeviceType = 0, ul_NumberOfChannels = 0, ul_NumberOfBiu = 0, ul_NovRamBoardType = 0, ul_NovRamBoardConfig = 0, ul_SerialNumber = 0, ul_PartNumber = 0, ul_GlobalRamSize = 0, ul_SharedRamSize = 0, ul_GlobalRamStartOffset = None, x_BoardCapabilities = None, ul_Reserved = 0):
        self.ul_DeviceType = ul_DeviceType # <class 'ctypes.c_ulong'>
        self.ul_NumberOfChannels = ul_NumberOfChannels # <class 'ctypes.c_ulong'>
        self.ul_NumberOfBiu = ul_NumberOfBiu # <class 'ctypes.c_ulong'>
        self.ul_NovRamBoardType = ul_NovRamBoardType # <class 'ctypes.c_ulong'>
        self.ul_NovRamBoardConfig = ul_NovRamBoardConfig # <class 'ctypes.c_ulong'>
        self.ul_SerialNumber = ul_SerialNumber # <class 'ctypes.c_ulong'>
        self.ul_PartNumber = ul_PartNumber # <class 'ctypes.c_ulong'>
        self.ul_GlobalRamSize = ul_GlobalRamSize # <class 'ctypes.c_ulong'>
        self.ul_SharedRamSize = ul_SharedRamSize # <class 'ctypes.c_ulong'>
        self.ul_GlobalRamStartOffset = [0] * 4 if ul_GlobalRamStartOffset == None else ul_GlobalRamStartOffset # <class 'mil_bindings.c_ulong_Array_4'>
        self.x_BoardCapabilities = ambt.PY_TY_API_BOARD_CAPABILITIES() if x_BoardCapabilities == None else x_BoardCapabilities # <class 'mil_bindings.ty_api_board_capabilities'>
        self.ul_Reserved = ul_Reserved # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_DeviceType, struct.ul_NumberOfChannels, struct.ul_NumberOfBiu, struct.ul_NovRamBoardType, struct.ul_NovRamBoardConfig, struct.ul_SerialNumber, struct.ul_PartNumber, struct.ul_GlobalRamSize, struct.ul_SharedRamSize, [x for x in struct.ul_GlobalRamStartOffset], ambt.PY_TY_API_BOARD_CAPABILITIES.fromStruct(struct.x_BoardCapabilities), struct.ul_Reserved)
    
    def toStruct(self):
        struct = amb.ty_api_board_info()
        struct.ul_DeviceType = self.ul_DeviceType
        struct.ul_NumberOfChannels = self.ul_NumberOfChannels
        struct.ul_NumberOfBiu = self.ul_NumberOfBiu
        struct.ul_NovRamBoardType = self.ul_NovRamBoardType
        struct.ul_NovRamBoardConfig = self.ul_NovRamBoardConfig
        struct.ul_SerialNumber = self.ul_SerialNumber
        struct.ul_PartNumber = self.ul_PartNumber
        struct.ul_GlobalRamSize = self.ul_GlobalRamSize
        struct.ul_SharedRamSize = self.ul_SharedRamSize
        for i in range(4):
            struct.ul_GlobalRamStartOffset[i] = self.ul_GlobalRamStartOffset[i]
        struct.x_BoardCapabilities = self.x_BoardCapabilities.toStruct()
        struct.ul_Reserved = self.ul_Reserved
        return struct


class PY_TY_API_DEVICE_CONFIG(object):
    def __init__(self, uc_DmaEnabled = 0, uc_DataQueueMemoryType = 0, uc_DataQueueMode = 0, uc_ReservedB4 = 0, uw_ReservedW1 = 0, uw_ReservedW2 = 0, ul_DmaMinimumSize = 0, ul_IntRequestCount = 0, ul_DriverFlags = 0, ul_ReservedLW4 = 0, ul_ReservedLW5 = 0, ul_ReservedLW6 = 0, ul_ReservedLW7 = 0, ul_ReservedLW8 = 0):
        self.uc_DmaEnabled = uc_DmaEnabled # AiUInt8
        self.uc_DataQueueMemoryType = uc_DataQueueMemoryType # AiUInt8
        self.uc_DataQueueMode = uc_DataQueueMode # AiUInt8
        self.uc_ReservedB4 = uc_ReservedB4 # AiUInt8
        self.uw_ReservedW1 = uw_ReservedW1 # AiUInt16
        self.uw_ReservedW2 = uw_ReservedW2 # AiUInt16
        self.ul_DmaMinimumSize = ul_DmaMinimumSize # AiUInt32
        self.ul_IntRequestCount = ul_IntRequestCount # AiUInt32
        self.ul_DriverFlags = ul_DriverFlags # AiUInt32
        self.ul_ReservedLW4 = ul_ReservedLW4 # AiUInt32
        self.ul_ReservedLW5 = ul_ReservedLW5 # AiUInt32
        self.ul_ReservedLW6 = ul_ReservedLW6 # AiUInt32
        self.ul_ReservedLW7 = ul_ReservedLW7 # AiUInt32
        self.ul_ReservedLW8 = ul_ReservedLW8 # AiUInt32
    
    @classmethod
    def fromStruct(cls, struct):
        return cls( struct.uc_DmaEnabled, struct.uc_DataQueueMemoryType, struct.uc_DataQueueMode, struct.uc_ReservedB4, struct.uw_ReservedW1, struct.uw_ReservedW2, struct.ul_DmaMinimumSize, struct.ul_IntRequestCount, struct.ul_DriverFlags, struct.ul_ReservedLW4, struct.ul_ReservedLW5, struct.ul_ReservedLW6, struct.ul_ReservedLW7, struct.ul_ReservedLW8)
    
    def toStruct(self):
        struct = amb.TY_API_DEVICE_CONFIG()
        struct.uc_DmaEnabled = self.uc_DmaEnabled # AiUInt8
        struct.uc_DataQueueMemoryType = self.uc_DataQueueMemoryType # AiUInt8
        struct.uc_DataQueueMode = self.uc_DataQueueMode # AiUInt8
        struct.uc_ReservedB4 = self.uc_ReservedB4 # AiUInt8
        struct.uw_ReservedW1 = self.uw_ReservedW1 # AiUInt16
        struct.uw_ReservedW2 = self.uw_ReservedW2 # AiUInt16
        struct.ul_DmaMinimumSize = self.ul_DmaMinimumSize # AiUInt32
        struct.ul_IntRequestCount = self.ul_IntRequestCount # AiUInt32
        struct.ul_DriverFlags = self.ul_DriverFlags # AiUInt32
        struct.ul_ReservedLW4 = self.ul_ReservedLW4 # AiUInt32
        struct.ul_ReservedLW5 = self.ul_ReservedLW5 # AiUInt32
        struct.ul_ReservedLW6 = self.ul_ReservedLW6 # AiUInt32
        struct.ul_ReservedLW7 = self.ul_ReservedLW7 # AiUInt32
        struct.ul_ReservedLW8 = self.ul_ReservedLW8 # AiUInt32

        return struct


class PY_TY_API_DATA_QUEUE_WRITE(object):
    def __init__(self, uc_Id = 0, uc_Padding1 = 0, uw_Padding2 = 0, pv_MemBuf = None, ul_BytesToWrite = 0, x_Info = None):
        self.uc_Id = uc_Id # <class 'ctypes.c_ubyte'>
        self.uc_Padding1 = uc_Padding1 # <class 'ctypes.c_ubyte'>
        self.uw_Padding2 = uw_Padding2 # <class 'ctypes.c_ushort'>
        self.pv_MemBuf = pv_MemBuf # <class 'ctypes.c_void_p'>
        self.ul_BytesToWrite = ul_BytesToWrite # <class 'ctypes.c_ulong'>
        self.x_Info = ambt.PY_TY_API_DATA_QUEUE_STATUS() if x_Info == None else x_Info # <class 'mil_bindings.ty_api_data_queue_status'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.uc_Id, struct.uc_Padding1, struct.uw_Padding2, struct.pv_MemBuf, struct.ul_BytesToWrite, ambt.PY_TY_API_DATA_QUEUE_STATUS.fromStruct(struct.x_Info))
    
    def toStruct(self):
        struct = amb.ty_api_data_queue_write()
        struct.uc_Id = self.uc_Id
        struct.uc_Padding1 = self.uc_Padding1
        struct.uw_Padding2 = self.uw_Padding2
        struct.pv_MemBuf = self.pv_MemBuf
        struct.ul_BytesToWrite = self.ul_BytesToWrite
        struct.x_Info = self.x_Info.toStruct()
        return struct


class PY_TY_API_QUEUE_TABLE(object):
    def __init__(self, uc_QueueFlag = 0, ul_QueueStart = 0, x_QueueStatus = None):
        self.uc_QueueFlag = uc_QueueFlag # <class 'ctypes.c_ubyte'>
        self.ul_QueueStart = ul_QueueStart # <class 'ctypes.c_ulong'>
        self.x_QueueStatus = ambt.PY_TY_API_DATA_QUEUE_STATUS() if x_QueueStatus == None else x_QueueStatus # <class 'mil_bindings.ty_api_data_queue_status'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.uc_QueueFlag, struct.ul_QueueStart, ambt.PY_TY_API_DATA_QUEUE_STATUS.fromStruct(struct.x_QueueStatus))
    
    def toStruct(self):
        struct = amb.ty_api_queue_table()
        struct.uc_QueueFlag = self.uc_QueueFlag
        struct.ul_QueueStart = self.ul_QueueStart
        struct.x_QueueStatus = self.x_QueueStatus.toStruct()
        return struct


class PY_TY_API_RT_SA_STATUS_EX(object):
    def __init__(self, x_XferSQueue = None,
                       x_XferEQueue = None, 
                       x_XferInfo   = None, 
                       ul_BufferQueueSize = 0):
        self.x_XferSQueue = [ambt.PY_TY_API_RT_SA_STATUS_QUEUE() for _ in range(256)] if x_XferSQueue == None else x_XferSQueue # <class 'mil_bindings.ty_api_rt_sa_status_queue_Array_256'>
        self.x_XferEQueue = [ambt.PY_TY_API_RT_SA_EVENT_QUEUE()] if x_XferEQueue == None else x_XferEQueue # <class 'mil_bindings.ty_api_rt_sa_event_queue_Array_1'>
        self.x_XferInfo = ambt.PY_TY_API_RT_SA_STATUS_INFO() if x_XferInfo == None else x_XferInfo # <class 'mil_bindings.ty_api_rt_sa_status_info'>
        self.ul_BufferQueueSize = ul_BufferQueueSize # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls([ambt.PY_TY_API_RT_SA_STATUS_QUEUE.fromStruct(sq) for sq in struct.x_XferSQueue], 
                   [ambt.PY_TY_API_RT_SA_EVENT_QUEUE.fromStruct(struct.x_XferEQueue[0])], 
                   ambt.PY_TY_API_RT_SA_STATUS_INFO.fromStruct(struct.x_XferInfo), 
                   struct.ul_BufferQueueSize)
    
    def toStruct(self):
        struct = amb.ty_api_rt_sa_status_ex()
        for i in range(256):
            struct.x_XferSQueue[i] = self.x_XferSQueue[i].toStruct()
        struct.x_XferEQueue[0] = self.x_XferEQueue[0].toStruct() # Array size 1
        struct.x_XferInfo = self.x_XferInfo.toStruct()
        struct.ul_BufferQueueSize = self.ul_BufferQueueSize
        return struct


class PY_TY_MIL_COM_ACK_WITH_VALUE(object):
    def __init__(self, xAck = None, value = 0):
        self.xAck = ambt.PY_TY_MIL_COM_ACK() if xAck == None else xAck # <class 'mil_bindings.ty_mil_com_ack'>
        self.value = value # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(ambt.PY_TY_MIL_COM_ACK.fromStruct(struct.xAck), struct.value)
    
    def toStruct(self):
        struct = amb.ty_mil_com_ack_with_value()
        struct.xAck = self.xAck.toStruct()
        struct.value = self.value
        return struct


class PY_TY_MIL_COM_WITH_VALUE(object):
    def __init__(self, cmd = None, value = 0):
        self.cmd = ambt.PY_TY_MIL_COM() if cmd == None else cmd # <class 'mil_bindings.ty_mil_com'>
        self.value = value # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(ambt.PY_TY_MIL_COM.fromStruct(struct.cmd), struct.value)
    
    def toStruct(self):
        struct = amb.ty_mil_com_with_value()
        struct.cmd = self.cmd.toStruct()
        struct.value = self.value
        return struct


class PY_TY_TAGSERVERINFO(object):
    def __init__(self, server_version = None, protocol_major = 0, protocol_minor = 0, application_name = None, description = None, host_name = None, os_info = None):
        self.server_version = ambt.PY_TY_VER_INFO() if server_version == None else server_version # <class 'mil_bindings.ty_ver_info'>
        self.protocol_major = protocol_major # <class 'ctypes.c_ulong'>
        self.protocol_minor = protocol_minor # <class 'ctypes.c_ulong'>
        self.application_name = '' if application_name == None else application_name # <class 'mil_bindings.c_char_Array_128'>
        self.description = '' if description == None else description # <class 'mil_bindings.c_char_Array_128'>
        self.host_name = '' if host_name == None else host_name # <class 'mil_bindings.c_char_Array_128'>
        self.os_info = '' if os_info == None else os_info # <class 'mil_bindings.c_char_Array_128'>
    
    @classmethod
    def fromStruct(cls, struct):
        # FIXME: autogenerated code needs adaptation.
        return cls(ambt.PY_TY_VER_INFO.fromStruct(struct.server_version), struct.protocol_major, struct.protocol_minor, struct.application_name, struct.description, struct.host_name, struct.os_info)
    
    def toStruct(self):
        # FIXME: autogenerated code needs adaptation.
        struct = amb.ty_tagserverinfo()
        struct.server_version = self.server_version.toStruct()
        struct.protocol_major = self.protocol_major
        struct.protocol_minor = self.protocol_minor
        struct.application_name = self.application_name
        struct.description = self.description
        struct.host_name = self.host_name
        struct.os_info = self.os_info
        return struct


class PY_TY_API_BC_FW_RSRC(object):
    def __init__(self, xfer = None, modif = None, instr = None):
        self.xfer = ambt.PY_TY_API_BC_FW_RSRC_DESC() if xfer == None else xfer # <class 'mil_bindings.ty_api_bc_fw_rsrc_desc'>
        self.modif = ambt.PY_TY_API_BC_FW_RSRC_DESC() if modif == None else modif # <class 'mil_bindings.ty_api_bc_fw_rsrc_desc'>
        self.instr = ambt.PY_TY_API_BC_FW_RSRC_DESC() if instr == None else instr # <class 'mil_bindings.ty_api_bc_fw_rsrc_desc'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(ambt.PY_TY_API_BC_FW_RSRC_DESC.fromStruct(struct.xfer), 
                   ambt.PY_TY_API_BC_FW_RSRC_DESC.fromStruct(struct.modif),
                   ambt.PY_TY_API_BC_FW_RSRC_DESC.fromStruct(struct.instr))
    
    def toStruct(self):
        struct = amb.ty_api_bc_fw_rsrc()
        struct.xfer = self.xfer.toStruct()
        struct.modif = self.modif.toStruct()
        struct.instr = self.instr.toStruct()
        return struct


class PY_TY_API_VERSION_INFO(object):
    def __init__(self, x_TcpVer = None, x_AslLcaVer = None, x_PciLcaVer = None, x_IoLcaBiu1Ver = None, x_CoreLcaBiu1Ver = None, x_IoLcaBiu2Ver = None, x_EndDecLcaBiu2Ver = None, x_IoLcaBiu3Ver = None, x_CoreLcaBiu3Ver = None, x_IoLcaBiu4Ver = None, x_EndDecLcaBiu4Ver = None, x_FirmwareBiu1Ver = None, x_FirmwareBiu2Ver = None, x_FirmwareBiu3Ver = None, x_FirmwareBiu4Ver = None, x_TargetSWVer = None, x_SysDrvVer = None, x_DllVer = None, x_MonitorVer = None, ul_BoardSerialNo = 0):
        self.x_TcpVer           = ambt.PY_TY_API_VERSION() if x_TcpVer            == None else x_TcpVer # <class 'mil_bindings.ty_api_version'>
        self.x_AslLcaVer        = ambt.PY_TY_API_VERSION() if x_AslLcaVer         == None else x_AslLcaVer # <class 'mil_bindings.ty_api_version'>
        self.x_PciLcaVer        = ambt.PY_TY_API_VERSION() if x_PciLcaVer         == None else x_PciLcaVer # <class 'mil_bindings.ty_api_version'>
        self.x_IoLcaBiu1Ver     = ambt.PY_TY_API_VERSION() if x_IoLcaBiu1Ver      == None else x_IoLcaBiu1Ver # <class 'mil_bindings.ty_api_version'>
        self.x_CoreLcaBiu1Ver   = ambt.PY_TY_API_VERSION() if x_CoreLcaBiu1Ver    == None else x_CoreLcaBiu1Ver # <class 'mil_bindings.ty_api_version'>
        self.x_IoLcaBiu2Ver     = ambt.PY_TY_API_VERSION() if x_IoLcaBiu2Ver      == None else x_IoLcaBiu2Ver# <class 'mil_bindings.ty_api_version'>
        self.x_EndDecLcaBiu2Ver = ambt.PY_TY_API_VERSION() if x_EndDecLcaBiu2Ver  == None else x_EndDecLcaBiu2Ver# <class 'mil_bindings.ty_api_version'>
        self.x_IoLcaBiu3Ver     = ambt.PY_TY_API_VERSION() if x_IoLcaBiu3Ver      == None else x_IoLcaBiu3Ver# <class 'mil_bindings.ty_api_version'>
        self.x_CoreLcaBiu3Ver   = ambt.PY_TY_API_VERSION() if x_CoreLcaBiu3Ver    == None else x_CoreLcaBiu3Ver# <class 'mil_bindings.ty_api_version'>
        self.x_IoLcaBiu4Ver     = ambt.PY_TY_API_VERSION() if x_IoLcaBiu4Ver      == None else x_IoLcaBiu4Ver# <class 'mil_bindings.ty_api_version'>
        self.x_EndDecLcaBiu4Ver = ambt.PY_TY_API_VERSION() if x_EndDecLcaBiu4Ver  == None else x_EndDecLcaBiu4Ver# <class 'mil_bindings.ty_api_version'>
        self.x_FirmwareBiu1Ver  = ambt.PY_TY_API_VERSION() if x_FirmwareBiu1Ver   == None else x_FirmwareBiu1Ver# <class 'mil_bindings.ty_api_version'>
        self.x_FirmwareBiu2Ver  = ambt.PY_TY_API_VERSION() if x_FirmwareBiu2Ver   == None else x_FirmwareBiu2Ver# <class 'mil_bindings.ty_api_version'>
        self.x_FirmwareBiu3Ver  = ambt.PY_TY_API_VERSION() if x_FirmwareBiu3Ver   == None else x_FirmwareBiu3Ver# <class 'mil_bindings.ty_api_version'>
        self.x_FirmwareBiu4Ver  = ambt.PY_TY_API_VERSION() if x_FirmwareBiu4Ver   == None else x_FirmwareBiu4Ver# <class 'mil_bindings.ty_api_version'>
        self.x_TargetSWVer      = ambt.PY_TY_API_VERSION() if x_TargetSWVer       == None else x_TargetSWVer# <class 'mil_bindings.ty_api_version'>
        self.x_SysDrvVer        = ambt.PY_TY_API_VERSION() if x_SysDrvVer         == None else x_SysDrvVer# <class 'mil_bindings.ty_api_version'>
        self.x_DllVer           = ambt.PY_TY_API_VERSION() if x_DllVer            == None else x_DllVer# <class 'mil_bindings.ty_api_version'>
        self.x_MonitorVer       = ambt.PY_TY_API_VERSION() if x_MonitorVer        == None else x_MonitorVer# <class 'mil_bindings.ty_api_version'>
        self.ul_BoardSerialNo   = ul_BoardSerialNo # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls( ambt.PY_TY_API_VERSION.fromStruct(struct.x_TcpVer), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_AslLcaVer), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_PciLcaVer), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_IoLcaBiu1Ver), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_CoreLcaBiu1Ver), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_IoLcaBiu2Ver), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_EndDecLcaBiu2Ver), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_IoLcaBiu3Ver), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_CoreLcaBiu3Ver), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_IoLcaBiu4Ver), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_EndDecLcaBiu4Ver), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_FirmwareBiu1Ver), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_FirmwareBiu2Ver), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_FirmwareBiu3Ver), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_FirmwareBiu4Ver), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_TargetSWVer), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_SysDrvVer), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_DllVer), 
                    ambt.PY_TY_API_VERSION.fromStruct(struct.x_MonitorVer), 
                    [x for x in struct.ul_BoardSerialNo] )
    
    def toStruct(self):
        struct = amb.ty_api_version_info()
        struct.x_TcpVer = self.x_TcpVer.toStruct()
        struct.x_AslLcaVer = self.x_AslLcaVer.toStruct()
        struct.x_PciLcaVer = self.x_PciLcaVer.toStruct()
        struct.x_IoLcaBiu1Ver = self.x_IoLcaBiu1Ver.toStruct()
        struct.x_CoreLcaBiu1Ver = self.x_CoreLcaBiu1Ver.toStruct()
        struct.x_IoLcaBiu2Ver = self.x_IoLcaBiu2Ver.toStruct()
        struct.x_EndDecLcaBiu2Ver = self.x_EndDecLcaBiu2Ver.toStruct()
        struct.x_IoLcaBiu3Ver = self.x_IoLcaBiu3Ver.toStruct()
        struct.x_CoreLcaBiu3Ver = self.x_CoreLcaBiu3Ver.toStruct()
        struct.x_IoLcaBiu4Ver = self.x_IoLcaBiu4Ver.toStruct()
        struct.x_EndDecLcaBiu4Ver = self.x_EndDecLcaBiu4Ver.toStruct()
        struct.x_FirmwareBiu1Ver = self.x_FirmwareBiu1Ver.toStruct()
        struct.x_FirmwareBiu2Ver = self.x_FirmwareBiu2Ver.toStruct()
        struct.x_FirmwareBiu3Ver = self.x_FirmwareBiu3Ver.toStruct()
        struct.x_FirmwareBiu4Ver = self.x_FirmwareBiu4Ver.toStruct()
        struct.x_TargetSWVer = self.x_TargetSWVer.toStruct()
        struct.x_SysDrvVer = self.x_SysDrvVer.toStruct()
        struct.x_DllVer = self.x_DllVer.toStruct()
        struct.x_MonitorVer = self.x_MonitorVer.toStruct()
        struct.ul_BoardSerialNo = self.ul_BoardSerialNo
        return struct


class PY_TY_API_DRIVER_INFO(object):
    def __init__(self, uc_DeviceGroup = 0, uc_ReservedB2 = 0, uc_ReservedB3 = 0, uc_ReservedB4 = 0, uw_ReservedW1 = 0, uw_ReservedW2 = 0, ul_DriverFlags = 0, ul_SN = 0, ul_BoardConfig = 0, ul_BoardType = 0, ul_OpenConnections = 0, ul_ReservedLW6 = 0, ul_ReservedLW7 = 0, ul_ReservedLW8 = 0):
        self.uc_DeviceGroup = uc_DeviceGroup # AiUInt8
        self.uc_ReservedB2 = uc_ReservedB2 # AiUInt8
        self.uc_ReservedB3 = uc_ReservedB3 # AiUInt8
        self.uc_ReservedB4 = uc_ReservedB4 # AiUInt8
        self.uw_ReservedW1 = uw_ReservedW1 # AiUInt16
        self.uw_ReservedW2 = uw_ReservedW2 # AiUInt16
        self.ul_DriverFlags = ul_DriverFlags # AiUInt32
        self.ul_SN = ul_SN # AiUInt32
        self.ul_DriverFlags = ul_DriverFlags # AiUInt32
        self.ul_BoardConfig = ul_BoardConfig # AiUInt32
        self.ul_BoardType = ul_BoardType # AiUInt32
        self.ul_OpenConnections = ul_OpenConnections # AiUInt32
        self.ul_ReservedLW6 = ul_ReservedLW6
        self.ul_ReservedLW7 = ul_ReservedLW7 # AiUInt32
        self.ul_ReservedLW8 = ul_ReservedLW8 # AiUInt32
    
    @classmethod
    def fromStruct(cls, struct):
        return cls( struct.uc_DeviceGroup, struct.uc_ReservedB2, struct.uc_ReservedB3, struct.uc_ReservedB4, struct.uw_ReservedW1, struct.uw_ReservedW2, struct.ul_DriverFlags, struct.ul_SN, struct.ul_BoardConfig, struct.ul_BoardType, struct.ul_OpenConnections, struct.ul_ReservedLW6, struct.ul_ReservedLW7, struct.ul_ReservedLW8 )
    
    def toStruct(self):
        struct = amb.TY_API_DRIVER_INFO()
        struct.uc_DeviceGroup = self.uc_DeviceGroup # AiUInt8
        struct.uc_ReservedB2 = self.uc_ReservedB2 # AiUInt8
        struct.uc_ReservedB3 = self.uc_ReservedB3 # AiUInt8
        struct.uc_ReservedB4 = self.uc_ReservedB4 # AiUInt8
        struct.uw_ReservedW1 = self.uw_ReservedW1 # AiUInt16
        struct.uw_ReservedW2 = self.uw_ReservedW2 # AiUInt16
        struct.ul_DriverFlags = self.ul_DriverFlags # AiUInt32
        struct.ul_SN = self.ul_SN # AiUInt32
        struct.ul_DriverFlags = self.ul_DriverFlags # AiUInt32
        struct.ul_BoardConfig = self.ul_BoardConfig # AiUInt32
        struct.ul_BoardType = self.ul_BoardType # AiUInt32
        struct.ul_OpenConnections = self.ul_OpenConnections # AiUInt32
        struct.ul_ReservedLW6 = self.ul_ReservedLW6
        struct.ul_ReservedLW7 = self.ul_ReservedLW7 # AiUInt32
        struct.ul_ReservedLW8 = self.ul_ReservedLW8 # AiUInt32

        return struct


class PY_TY_API_GET_MEM_INFO(object):
    def __init__(self, ax_BiuAddr = None, x_Sim = None, ax_BiuSize = None, ax_BiuCnt = None, x_BiuInfo = None, aul_GlobalMemSize = None):
        self.ax_BiuAddr = [ambt.PY_TY_API_MEM_BIU_ADDR()  for i in range(8)] if ax_BiuAddr == None else ax_BiuAddr # PY_TY_API_MEM_BIU_ADDR  * 8
        self.x_Sim      = [ambt.PY_TY_API_MEM_SIM_BUF()   for i in range(2)] if x_Sim      == None else x_Sim      # PY_TY_API_MEM_SIM_BUF   * 2
        self.ax_BiuSize = [ambt.PY_TY_API_MEM_BIU_SIZE()  for i in range(8)] if ax_BiuSize == None else ax_BiuSize # PY_TY_API_MEM_BIU_SIZE  * 8
        self.ax_BiuCnt  = [ambt.PY_TY_API_MEM_BIU_COUNT() for i in range(8)] if ax_BiuCnt  == None else ax_BiuCnt  # PY_TY_API_MEM_BIU_COUNT * 8
        self.x_BiuInfo  = [ambt.PY_TY_API_MEM_BIU_INFO()  for i in range(8)] if x_BiuInfo  == None else x_BiuInfo  # PY_TY_API_MEM_BIU_INFO  * 8

        self.aul_GlobalMemSize = [0, 0] if aul_GlobalMemSize == None else aul_GlobalMemSize # AiUInt32 * 2
    
    @classmethod
    def fromStruct(cls, struct):
        return cls( [ambt.PY_TY_API_MEM_BIU_ADDR.fromStruct(s)  for s in struct.ax_BiuAddr], 
                    [ambt.PY_TY_API_MEM_SIM_BUF.fromStruct(s)   for s in struct.x_Sim], 
                    [ambt.PY_TY_API_MEM_BIU_SIZE.fromStruct(s)  for s in struct.ax_BiuSize], 
                    [ambt.PY_TY_API_MEM_BIU_COUNT.fromStruct(s) for s in struct.ax_BiuCnt], 
                    [ambt.PY_TY_API_MEM_BIU_INFO.fromStruct(s)  for s in struct.x_BiuInfo], 
                    [b for b in struct.aul_GlobalMemSize] )
    
    def toStruct(self):
        struct = amb.TY_API_GET_MEM_INFO()
        for i in range(8):
            struct.ax_BiuAddr[i] = self.ax_BiuAddr[i].toStruct()
        for i in range(2):
            struct.x_Sim[i] = self.x_Sim[i].toStruct()
        for i in range(8):
            struct.ax_BiuSize[i] = self.ax_BiuSize[i].toStruct()
        for i in range(8):
            struct.ax_BiuCnt[i] = self.ax_BiuCnt[i].toStruct()
        for i in range(8):
            struct.x_BiuInfo[i] = self.x_BiuInfo[i].toStruct()
        for i in range(2):
            struct.aul_GlobalMemSize[i] = self.aul_GlobalMemSize[i]

        return struct


class PY_TY_API_SET_MEM_INFO(object):
    def __init__(self, aul_SimBufSize = None, ax_BiuSize = None, ax_BiuCnt   = None):
        self.aul_SimBufSize = [0, 0] if aul_SimBufSize == None else aul_SimBufSize # AiUInt32 * 2
        self.ax_BiuSize = [ambt.PY_TY_API_MEM_BIU_SIZE()  for i in range(8)] if ax_BiuSize == None else ax_BiuSize # PY_TY_API_MEM_BIU_SIZE  * 8
        self.ax_BiuCnt  = [ambt.PY_TY_API_MEM_BIU_COUNT() for i in range(8)] if ax_BiuCnt  == None else ax_BiuCnt  # PY_TY_API_MEM_BIU_COUNT * 8
    
    @classmethod
    def fromStruct(cls, struct):
        return cls( [b for b in struct.aul_SimBufSize],
                    [ambt.PY_TY_API_MEM_BIU_SIZE.fromStruct(s)  for s in struct.ax_BiuSize], 
                    [ambt.PY_TY_API_MEM_BIU_COUNT.fromStruct(s) for s in struct.ax_BiuCnt] )

    @classmethod
    def fromGetMemInfo(cls, info, is_hs ):
        object = cls()
        object.ax_BiuCnt  = copy.deepcopy(info.ax_BiuCnt)
        object.ax_BiuSize = copy.deepcopy(info.ax_BiuSize)

        object.aul_SimBufSize[0] = info.x_Sim[0].ul_BufSize
        if is_hs:
            # On HS boards the second PBI value is used as HS simbuf size
            # @AIMFIXME: This will not work with EFA-2 combined boards
            object.aul_SimBufSize[1] = info.x_Sim[0].ul_HsBufSize
        else:
            object.aul_SimBufSize[1] = info.x_Sim[1].ul_BufSize

        return object

    def toStruct(self):
        struct = amb.TY_API_SET_MEM_INFO()
        for i in range(2):
            struct.aul_SimBufSize[i] = self.aul_SimBufSize[i]
        for i in range(8):
            struct.ax_BiuSize[i] = self.ax_BiuSize[i].toStruct()
        for i in range(8):
            struct.ax_BiuCnt[i] = self.ax_BiuCnt[i].toStruct()

        return struct


class PY_TY_API_SCOPE_OFFSETS(object):
    def __init__(self, lOffsetA_3V_stub = 0, lOffsetB_3V_stub = 0, lOffsetA_30V_stub = 0, lOffsetB_30V_stub = 0, lOffsetA_3V_ext = 0, lOffsetB_3V_ext = 0, lOffsetA_30V_ext = 0, lOffsetB_30V_ext = 0):
        self.lOffsetA_3V_stub = lOffsetA_3V_stub # <class 'ctypes.c_long'>
        self.lOffsetB_3V_stub = lOffsetB_3V_stub # <class 'ctypes.c_long'>
        self.lOffsetA_30V_stub = lOffsetA_30V_stub # <class 'ctypes.c_long'>
        self.lOffsetB_30V_stub = lOffsetB_30V_stub # <class 'ctypes.c_long'>
        self.lOffsetA_3V_ext = lOffsetA_3V_ext # <class 'ctypes.c_long'>
        self.lOffsetB_3V_ext = lOffsetB_3V_ext # <class 'ctypes.c_long'>
        self.lOffsetA_30V_ext = lOffsetA_30V_ext # <class 'ctypes.c_long'>
        self.lOffsetB_30V_ext = lOffsetB_30V_ext # <class 'ctypes.c_long'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.lOffsetA_3V_stub, struct.lOffsetB_3V_stub, struct.lOffsetA_30V_stub, struct.lOffsetB_30V_stub, struct.lOffsetA_3V_ext, struct.lOffsetB_3V_ext, struct.lOffsetA_30V_ext, struct.lOffsetB_30V_ext)
    
    def toStruct(self):
        struct = amb.ty_api_scope_calibration_info()
        struct.lOffsetA_3V_stub = self.lOffsetA_3V_stub
        struct.lOffsetB_3V_stub = self.lOffsetB_3V_stub
        struct.lOffsetA_30V_stub = self.lOffsetA_30V_stub
        struct.lOffsetB_30V_stub = self.lOffsetB_30V_stub
        struct.lOffsetA_3V_ext = self.lOffsetA_3V_ext
        struct.lOffsetB_3V_ext = self.lOffsetB_3V_ext
        struct.lOffsetA_30V_ext = self.lOffsetA_30V_ext
        struct.lOffsetB_30V_ext = self.lOffsetB_30V_ext
        return struct

class PY_TY_API_SCOPE_TRG_EX(object):
    def __init__(self, ul_TrgMode = 0, ul_TrgSrc = 0, ul_TrgValue = 0, ul_TrgValue2 = 0, ul_TrgNbSamples = 0, ul_TrgNbSamples2 = 0, ul_TrgFlags = 0, ul_TrgDelay = 0, ul_TrgTbt = 0, ul_TrgDiscrete = 0):
        self.ul_TrgMode = ul_TrgMode # <class 'ctypes.c_ulong'>
        self.ul_TrgSrc = ul_TrgSrc # <class 'ctypes.c_ulong'>
        self.ul_TrgValue = ul_TrgValue # <class 'ctypes.c_ulong'>
        self.ul_TrgValue2 = ul_TrgValue2 # <class 'ctypes.c_ulong'>
        self.ul_TrgNbSamples = ul_TrgNbSamples # <class 'ctypes.c_ulong'>
        self.ul_TrgNbSamples2 = ul_TrgNbSamples2 # <class 'ctypes.c_ulong'>
        self.ul_TrgFlags = ul_TrgFlags # <class 'ctypes.c_ulong'>
        self.ul_TrgDelay = ul_TrgDelay # <class 'ctypes.c_ulong'>
        self.ul_TrgTbt = ul_TrgTbt # <class 'ctypes.c_ulong'>
        self.ul_TrgDiscrete = ul_TrgDiscrete # <class 'ctypes.c_ulong'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ul_TrgMode, struct.ul_TrgSrc, struct.ul_TrgValue, struct.ul_TrgValue2, struct.ul_TrgNbSamples, struct.ul_TrgNbSamples2, struct.ul_TrgFlags, struct.ul_TrgDelay, struct.ul_TrgTbt, struct.ul_TrgDiscrete)
    
    def toStruct(self):
        struct = amb.api_scope_trg_ex()
        struct.ul_TrgMode = self.ul_TrgMode
        struct.ul_TrgSrc = self.ul_TrgSrc
        struct.ul_TrgValue = self.ul_TrgValue
        struct.ul_TrgValue2 = self.ul_TrgValue2
        struct.ul_TrgNbSamples = self.ul_TrgNbSamples
        struct.ul_TrgNbSamples2 = self.ul_TrgNbSamples2
        struct.ul_TrgFlags = self.ul_TrgFlags
        struct.ul_TrgDelay = self.ul_TrgDelay
        struct.ul_TrgTbt = self.ul_TrgTbt
        struct.ul_TrgDiscrete = self.ul_TrgDiscrete
        return struct
    
class PY_TY_API_SCOPE_BUFFER(object):
    def __init__(self, ulID = 0, eBufferType = 0, pvBuffer = 0, ulBufferSize = 0, ulFlags = 0, ulDataSize = 0, ulTriggerId = 0, BufferHandler = 0, pvUserData = 0):
        self.ulID = ulID # <class 'ctypes.c_ulong'>
        self.eBufferType = eBufferType # <class 'ctypes.c_ulong'>
        self.pvBuffer = pvBuffer # <class 'ctypes.c_void_p'>
        self.ulBufferSize = ulBufferSize # <class 'ctypes.c_ulong'>
        self.ulFlags = ulFlags # <class 'ctypes.c_ulong'>
        self.ulDataSize = ulDataSize # <class 'ctypes.c_ulong'>
        self.ulTriggerId = ulTriggerId # <class 'ctypes.c_ulong'>
        self.BufferHandler = BufferHandler # <class 'TY_API_SCOPE_BUFFER_HANDLER'>
        self.pvUserData = pvUserData # <class 'ctypes.c_void_p'>
    
    @classmethod
    def fromStruct(cls, struct):
        return cls(struct.ulID, struct.eBufferType, struct.pvBuffer, struct.ulBufferSize, struct.ulFlags, struct.ulDataSize, struct.ulTriggerId, struct.BufferHandler, struct.pvUserData)
    
    @classmethod
    def fromPointer(cls, buffer_pointer):
        ctypes_p_ScopeBuffer = amb.TY_API_SCOPE_BUFFER.from_buffer_copy(buffer_pointer.contents)
        return ambt.PY_TY_API_SCOPE_BUFFER.fromStruct(ctypes_p_ScopeBuffer)

    @property
    def samples_count(self):
        return ambd.NUM_SCOPE_SAMPLES(self.ulDataSize)

    @property
    def samples(self):
        raw_data = ctypes.cast(self.pvBuffer, ctypes.POINTER(ctypes.c_uint32 * self.samples_count)).contents
        return [ambd.SCOPE_SAMPLE_BY_SAMPLE_ID(raw_data,i) for i in range(self.samples_count)]
