# SPDX-FileCopyrightText: 2022-2024 AIM GmbH <info@aim-online.com>
# SPDX-License-Identifier: MIT

"""Module for handling MIL API library functionality.

This module is used for handling AIM MIL C API library
specific functions via python's ctypes module.

note: this file is currently under refactoring and 
      will be chanced without notice in future BSPs
"""

import sys
import ctypes
import array

from . import mil_bindings as amb # Aim Mil Binding
from . import mil_bindings_types as ambt      # Aim Mil Bindings Types 
from . import mil_bindings_defines as ambd

class MilApiException(Exception):
    """
    This class is used for handling MIL-API function call error
    return value.
    """
    def __init__(self, error_code, message):

        # Call the base class constructor with the parameters it needs
        super(Exception, self).__init__(message)

        # Now for your custom code...
        self._error_code = error_code
        self._error_message = message

    @property
    def error_code(self):
        return self._error_code

    @property
    def error_message(self):
        return self._error_message


class MilApi():
    """
    This class is used for handling access to the MIL-API
     C API library. 
    """
    def __init__(self):
        """Loads the API MIL C library via ctypes"""
        if sys.platform.startswith("linux"):
            self._lib = ctypes.cdll.LoadLibrary("libaim_mil.so")
        else:
            self._lib = ctypes.cdll.LoadLibrary("api_mil.24.dll")

    @property
    def lib(self):
        """
        Returns ctypes API library object
        :return : returns the ctypes dll object that wraps the AIM MIL API library
        """
        return self._lib

    def error(self, error_code):
        """
        Converts the API error codes to human readable descriptions
        :param error_code: the error code to return
        :return: returns the error description string
        """
        return '%s (%s)' % (self.PyApiGetErrorMessage(error_code), hex(error_code))

    ###########################################################################
    #                                                                         #
    #                           Library Functions                             #
    #                                                                         #
    ###########################################################################

    def PyApiClose(self, handle ):
        """ApiClose Closes AIM module interface - called last"""
        ret = self.lib.ApiClose(handle)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiClose failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiConnectToServer(self, pszNetworkAdress):
        """ApiConnectToServer Establishes a network connection to a specified PC server where AIM Network Server (ANS) software is running."""
        num_devices = amb.AiUInt16(0)
        curl = pszNetworkAdress.encode(encoding="utf-8")
        ret = self.lib.ApiConnectToServer(curl, ctypes.byref(num_devices))
        if ret != amb.API_OK:
            print("Failed to connect to %s" % (pszNetworkAdress))
            raise MilApiException(ret, "Error: ApiConnectToServer failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        return num_devices.value

    def PyApiDelIntHandler(self, handle, biu, uc_Type ):
        """ApiDelIntHandler Removes the pointer interface to the interrupt handler function"""
        ret = self.lib.ApiDelIntHandler(handle, biu, uc_Type)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiDelIntHandler failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiDisconnectFromServer(self, pszNetworkAdress):
        """ApiDisconnectFromServer Disconnects the network connection"""
        curl = pszNetworkAdress.encode(encoding="utf-8")
        ret = self.lib.ApiDisconnectFromServer(curl)
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiDisconnectFromServer failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiExit( self ):
        """ApiExit This function cleans up the library resources so it is safe to unload"""
        ret = self.lib.ApiExit()
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiExit failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiGetDeviceConfig(self,handle):
        """ApiGetDeviceConfig Get the device config"""
        config = amb.TY_API_DEVICE_CONFIG()
        ret = self.lib.ApiGetDeviceConfig(handle, ctypes.byref(config))
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiGetDeviceConfig: %s." %  self.PyApiGetErrorMessage(ret))
        
        return ambt.PY_TY_API_DEVICE_CONFIG.fromStruct(config)
    
    def PyApiGetErrorMessage(self, error_code):
        """ApiGetErrorMessage Get a error message for a given error code"""
        self.lib.ApiGetErrorMessage.restype = ctypes.c_char_p
        return self.lib.ApiGetErrorMessage(error_code).decode("utf-8")

    def PyApiInit( self ):
        """ApiInit Initializes the API S/W Library Application Interface - performed first"""
        num_devices = self.lib.ApiInit()
        if num_devices == 0:
            raise Exception("Error: ApiInit no module found.")
        return num_devices

    def PyApiInstIntHandler(self, handle, biu, uc_Type, pf_IntFunc ):
        """ApiInstIntHandler Provides a pointer to the interrupt handler function"""
        ret = self.lib.ApiInstIntHandler(handle, biu, uc_Type, pf_IntFunc )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiInstIntHandler failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiOpenEx( self, px_ApiOpen = ambt.PY_TY_API_OPEN() ):
        """ApiOpenEx Initializes the AIM module & stream & provides the handle for future board commands"""
        assert isinstance(px_ApiOpen, ambt.PY_TY_API_OPEN)
        ctypes_parameters = px_ApiOpen.toStruct()

        handle = amb.AiUInt32(-1)

        ret = self.lib.ApiOpenEx(ctypes.byref(ctypes_parameters), ctypes.byref(handle))

        if ret != 0:
            raise MilApiException(ret, "Error: ApiOpenEx failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return handle.value

    def PyApiSetDeviceConfig(self, handle, px_Config = ambt.PY_TY_API_DEVICE_CONFIG()):
        """ApiSetDeviceConfig Sets the device config"""
        assert isinstance(px_Config, ambt.PY_TY_API_DEVICE_CONFIG)
        config = px_Config.toStruct()

        ret = self.lib.ApiSetDeviceConfig(handle, ctypes.byref(config))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiSetDeviceConfig: %s." %  self.PyApiGetErrorMessage(ret))

    def PyApiSetDllDbgLevel(self, ul_DllDbgLevel):
        """ApiSetDllDbgLevel Sets the debug output level"""
        ret = self.lib.ApiSetDllDbgLevel(ul_DllDbgLevel)
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiSetDllDbgLevel failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiGetDriverInfo(self, handle):
        """ApiGetDriverInfo Returns information from the system driver"""
        info = amb.TY_API_DRIVER_INFO()
        ret = self.lib.ApiGetDriverInfo(handle, ctypes.byref(info))
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiGetDriverInfo failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return ambt.PY_TY_API_DRIVER_INFO.fromStruct(info)

    def PyApiCmdUtility(self, handle, in_values ):
        """ApiCmdUtility internal function"""
        c_int_count  = amb.AiUInt8(len(in_values))
        c_out_count  = amb.AiUInt8(64)
        c_in_values  = (amb.AiUInt32 * len(in_values))()
        c_out_values = (amb.AiUInt32 * 64)()

        for i, value in enumerate(in_values):
            c_in_values[i] = value

        ret = self.lib.ApiCmdUtility(handle, c_int_count, ctypes.byref(c_out_count), ctypes.byref(c_in_values), ctypes.byref(c_out_values))
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdUtility failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        if c_out_count.value <= 1:
            return c_out_values[0]
        else:
            return [c_out_values[i] for i in range(c_out_count.value) ]

    '''
    DONE ApiClose  Closes AIM module interface - called last
    DONE ApiConnectToServer Establishes a network connection to a specified PC server where AIM Network Server (ANS) software is running.
    DONE ApiDelIntHandler Removes the pointer interface to the interrupt handler function
    DONE ApiDisconnectFromServer Disconnects the network connection
    DONE ApiExit This function cleans up the library resources so it is safe to unload
    SKIP ApiGetBoardInfo Get information about the assigned hardware
    DONE ApiGetDeviceConfig Get the device config
    DONE ApiGetErrorDescription Get a error message for a given error code
    DONE ApiGetErrorMessage Get a error message for a given error code
    SKIP ApiGetLibraryInfo Reads extended information about the current library settings
    SKIP ApiGetServerInfo Retrieves information about AIM boards installed on the ANS PC
    DONE ApiInit Initializes the API S/W Library Application Interface - performed first
    DONE ApiInstIntHandler Provides a pointer to the interrupt handler function
    DONE ApiOpenEx Initializes the AIM module & stream & provides the handle for future board commands
    DONE ApiSetDeviceConfig Sets the device config
    DONE ApiSetDllDbgLevel Sets the debug output level
    DONE ApiGetDriverInfo Returns information from the system driver
    '''

    ###########################################################################
    #                                                                         #
    #                           System Functions                              #
    #                                                                         #
    ###########################################################################
    
    def PyApiCmdIni(self, handle ):
        """ApiCmdIni	Initializes AIM board and returns board configuration"""
        ini_info     = amb.TY_API_INI_INFO()

        ret = self.lib.ApiCmdIni(handle, amb.API_INIT_MODE_READ, ctypes.byref(ini_info))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdIni failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ambt.PY_TY_API_INI_INFO.fromStruct(ini_info)

    def PyApiCmdReset(self, handle, rc = amb.API_RESET_ALL):
        """ApiCmdReset	Resets the AIM board and ASP driver software data to initial state"""
        pres = amb.TY_API_RESET_INFO()
        ret = self.lib.ApiCmdReset(handle, 0, rc, ctypes.byref(pres))

        if ret != 0:
            raise MilApiException(ret, "Error: ApiCmdReset failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return ambt.PY_TY_API_RESET_INFO.fromStruct(pres)

    def PyApiCmdBite(self, handle, sc = amb.API_BITE_ALL ):
        """ApiCmdBite	Performs a selftest on the AIM board"""
        bite_status = (amb.AiUInt8 * 2)()
        ret = self.lib.ApiCmdBite(handle, 0, sc, ctypes.byref(bite_status))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBite failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return [x for x in bite_status]

    def PyApiCmdDefRespTout(self, handle, resp_tout = 14.0 ):
        """ApiCmdDefRespTout	Defines the response timeout value (default is 14 µsec)"""
        ctime = amb.AiFloat(resp_tout)
        ret = self.lib.ApiCmdDefRespTout(handle, 0, ctime)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdDefRespTout failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiReadAllVersions(self, handle, count = amb.AI_MAX_VERSIONS ):
        """ApiReadAllVersions	Reads all versions applicable for this board"""
        versions     = (amb.TY_VER_INFO * count)()
        info         = amb.TY_VERSION_OUT()

        ret = self.lib.ApiReadAllVersions(handle, amb.AI_MAX_VERSIONS, versions, ctypes.byref(info))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiReadAllVersions failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return [ambt.PY_TY_VER_INFO.fromStruct(versions[i]) for i in range(info.ul_Count)]


    def PyApiReadVersion(self, handle, eId ):
        """ApiReadVersion	This function returns the version number of a software package component for the AIM board."""
        pxVerion = amb.TY_VER_INFO()

        ret = self.lib.ApiReadVersion(handle, eId, ctypes.byref(pxVerion))

        if ret == ambd.API_ERR_INVALID_MODE:
            return None

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiReadVersion failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ambt.PY_TY_VER_INFO.fromStruct(pxVerion)

    def PyApiCmdSetIrigTime(self, handle, time = ambt.PY_TY_API_IRIG_TIME()):
        """ApiCmdSetIrigTime	Sets the time of the on-board IRIG timecode encoder"""
        assert isinstance(time, ambt.PY_TY_API_IRIG_TIME)
        ctypes_time = time.toStruct()
        ret = self.lib.ApiCmdSetIrigTime(handle, ctypes.byref(ctypes_time))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdSetIrigTime failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
    def PyApiCmdGetIrigTime(self, handle):
        """ApiCmdGetIrigTime	Reads the time on the on-board IRIG timecode encoder"""
        time = amb.TY_API_IRIG_TIME()

        ret = self.lib.ApiCmdGetIrigTime(handle, ctypes.byref(time))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdGetIrigTime failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return ambt.PY_TY_API_IRIG_TIME.fromStruct(time)

    #set PBA variable for 1553A ("TRUE") or 1553B mode ("FALSE")
    def PyApiCmdDefMilbusProtocol(self, handle, mil_prot, mode, rt ):
        """ApiCmdDefMilbusProtocol	Defines MILbus Protocol type (A or B) for individual or single RTs"""
        ret = self.lib.ApiCmdDefMilbusProtocol(handle, 0, mil_prot, mode, rt)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdDefMilbusProtocol failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdSysPingVariable(self, handle, ulInput):
        """ApiCmdSysPingVariable can be used to test the host to target communication with variable output sizes"""
        ulInputCount = len(ulInput)
        data_in_p   = (amb.AiUInt32 * ulInputCount)()
        data_out_p  = (amb.AiUInt32 * ulInputCount)()

        for i in range(ulInputCount):
            data_in_p[i] = ulInput[i]

        ret = self.lib.ApiCmdSysPingVariable( handle, 
                                             ulInputCount, 
                                             ctypes.byref(data_in_p), 
                                             ctypes.byref(data_out_p) )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdSysPingVariable failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return [x for x in data_out_p]

    def PyApiCmdSystagDef(self, handle, id, con, mode, psystag = ambt.PY_TY_API_SYSTAG()):
        """ApiCmdSystagDef	Defines the generation of dynamic data words or datasets in BC and RT mode"""
        assert isinstance(psystag, ambt.PY_TY_API_SYSTAG)
        ctypes_psystag = psystag.toStruct()
        ret = self.lib.ApiCmdSystagDef(handle, 0, id, con, mode, ctypes.byref(ctypes_psystag))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdSystagDef failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdSystagCon(self, handle, id, con):
        """ApiCmdSystagCon	Suspends or resumes the generation of dynamic data words or datasets in BC and RT mode."""
        ret = self.lib.ApiCmdSystagCon(handle, 0, id, con)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdSystagCon failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
    def PyApiCmdSysTriggerEdgeInputSet(self, handle, edge_flags):
        """ApiCmdSysTriggerEdgeInputSet	Configure edge sensitivity of the input triggers"""
        ret = self.lib.ApiCmdSysTriggerEdgeInputSet(handle, 0, edge_flags)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdSysTriggerEdgeInputSet failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdSysTriggerEdgeInputGet(self, handle):
        """ApiCmdSysTriggerEdgeInputGet	Get edge sensitivity of the input triggers"""
        edge_flags = amb.AiUInt32()
        ret = self.lib.ApiCmdSysTriggerEdgeInputGet(handle, 0, ctypes.byref(edge_flags))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdSysTriggerEdgeInputGet failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return edge_flags.value

    def PyApiCmdSysTriggerDigitalLoopCon( self, handle, config ):
        """ApiCmdSysTriggerDigitalLoopCon	Write the FPGA digital trigger loop register"""
        ret = self.lib.ApiCmdSysTriggerDigitalLoopCon(handle, 0, config)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdSysTriggerDigitalLoopCon failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
    def PyApiCmdSysTriggerDigitalLoopGet( self, handle ):
        """ApiCmdSysTriggerDigitalLoopGet   Read the FPGA digital trigger loop register."""
        config= amb.AiUInt32(0)

        ret = self.lib.ApiCmdSysTriggerDigitalLoopGet(handle, 0, ctypes.byref(config))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdSysTriggerDigitalLoopGet failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return config.value

    def PyApiCmdSysSetMemPartition(self, handle, uc_Mode = 0, px_MemInfo = ambt.PY_TY_API_SET_MEM_INFO() ):
        """ApiCmdSysSetMemPartition	Configures the Global RAM of the board"""
        assert isinstance(px_MemInfo, ambt.PY_TY_API_SET_MEM_INFO)

        pul_Status  = amb.AiUInt32()
        aul_MemUsed = (amb.AiUInt32 * 2)()
        ctypes_px_MemInfo = px_MemInfo.toStruct()

        ret = self.lib.ApiCmdSysSetMemPartition(handle, uc_Mode, ctypes.byref(ctypes_px_MemInfo), ctypes.byref(pul_Status), ctypes.byref(aul_MemUsed) )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdSysSetMemPartition failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        if pul_Status.value != amb.API_MEM_PART_OK:
            raise MilApiException(pul_Status.value, "Error: ApiCmdSysSetMemPartition: status = %d." % (pul_Status.value))

        return [v for v in aul_MemUsed]

    def PyApiCmdSysGetBoardInfo( self, handle, ulDataStart, ulDataCount=1 ):
        """ApiCmdSysGetBoardInfo	Read board information from the target software"""
        ulOutCount = amb.AiUInt32()
        ulOutput = array.array('I', [0] * ulDataCount)

        ret = self.lib.ApiCmdSysGetBoardInfo(handle, ulDataStart, ulDataCount, ctypes.cast(ulOutput.buffer_info()[0], ctypes.POINTER(amb.AiUInt32)), ctypes.byref(ulOutCount))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdSysGetBoardInfo failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        if ulDataCount != ulOutCount.value:
            ulOutput = ulOutput[:ulOutCount.value]

        if ulDataCount==1:
            # Return single value
            if len(ulOutput) < 1:
                return None
            else:
                return ulOutput[0]
        else:
            # Return list of values
            return ulOutput.tolist()

    def PyApiCmdReadDiscretes(self, handle ):
        """ApiCmdReadDiscretes	Reads from the onboard discrete register"""
        pul_Value =  amb.AiUInt32()
        ret = self.lib.ApiCmdReadDiscretes(handle, ctypes.byref(pul_Value) )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdReadDiscretes failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return pul_Value.value

    def PyApiCmdReadDiscretesConfig(self, handle ):
        """ApiCmdReadDiscretesConfig Reads from the onboard discrete config register"""
        ul_DiscreteSetup =  amb.AiUInt32()
        ret = self.lib.ApiCmdReadDiscretesConfig(handle, ctypes.byref(ul_DiscreteSetup) )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdReadDiscretesConfig failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return ul_DiscreteSetup.value

    def PyApiCmdWriteDiscretes(self, handle, ul_Mask, ul_Value ):
        """ApiCmdWriteDiscretes	Writes to the onboard discrete register"""
        ret = self.lib.ApiCmdWriteDiscretes(handle, ul_Mask, ul_Value)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdWriteDiscretes failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdInitDiscretes(self, handle, ul_DiscreteSetup ):
        """ApiCmdInitDiscretes	Initializes the onboard discrete behaviour"""
        ret = self.lib.ApiCmdInitDiscretes(handle, ul_DiscreteSetup)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdInitDiscretes failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdSysGetMemPartition(self, handle ):
        """ApiCmdSysGetMemPartition	Reads the configuration of the Global RAM of the board"""
        uc_Mode = 0
        px_MemInfo = amb.TY_API_GET_MEM_INFO()

        ret = self.lib.ApiCmdSysGetMemPartition(handle, uc_Mode, ctypes.byref(px_MemInfo))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdSysGetMemPartition failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ambt.PY_TY_API_GET_MEM_INFO.fromStruct(px_MemInfo)

    def PyApiCmdReadDiscretesInfo(self, handle ):
        """ApiCmdReadDiscretesInfo	Reads the configuration of the discrete channels."""
        px_DiscrInfo = amb.TY_API_DISCR_INFO()

        ret = self.lib.ApiCmdReadDiscretesInfo(handle, ctypes.byref(px_DiscrInfo))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdReadDiscretesInfo failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ambt.PY_TY_API_DISCR_INFO.fromStruct(px_DiscrInfo)

    def PyApiGetBoardName(self, handle ):
        """ApiGetBoardName Read the descriptive board name"""
        self.lib.ApiGetBoardName.restype = ctypes.c_char_p
        return self.lib.ApiGetBoardName(handle).decode("utf-8")

    def PyApiCmdSetIrigStatus(self, handle, new_source = amb.API_IRIG_INTERN ):
        """ApiCmdSetIrigStatus This function is used to set the on-board IRIG timecode encoder status."""
        ret = self.lib.ApiCmdSetIrigStatus(handle, new_source )
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdSetIrigStatus failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdGetIrigStatus(self, handle):
        """ApiCmdGetIrigStatus This function is used to read the on-board IRIG timecode encoder status."""
        source  = amb.TY_API_IRIG_SOURCE()
        in_sync = amb.AiBoolean()
        
        ret = self.lib.ApiCmdGetIrigStatus(handle, ctypes.byref(source), ctypes.byref(in_sync))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdGetIrigStatus failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return source.value, in_sync.value

    '''
    DONE ApiCmdIni	Initializes AIM board and returns board configuration
    DONE ApiCmdReset	Resets the AIM board and ASP driver software data to initial state
    DONE ApiCmdBite	Performs a selftest on the AIM board
    DONE ApiCmdDefRespTout	Defines the response timeout value (default is 14 µsec)
    DONE ApiReadAllVersions	Reads all versions applicable for this board
    DONE ApiReadVersion	This function returns the version number of a software package component for the AIM board.
    SKIP ApiCmdExecSys	Executes a system-related function on the AIM board
    DONE ApiCmdSetIrigTime	Sets the time of the on-board IRIG timecode encoder
    DONE ApiCmdGetIrigTime	Reads the time on the on-board IRIG timecode encoder
    DONE ApiCmdDefMilbusProtocol	Defines MILbus Protocol type (A or B) for individual or single RTs
    DONE ApiCmdSystagDef	Defines the generation of dynamic data words or datasets in BC and RT mode
    DONE ApiCmdSystagCon	Suspends or resumes the generation of dynamic data words or datasets in BC and RT mode.
    DONE ApiCmdSysTriggerEdgeInputSet	Configure edge sensitivity of the input triggers
    DONE ApiCmdSysTriggerEdgeInputGet	Get edge sensitivity of the input triggers
    SKIP ApiCmdTrackDef	Defines an area (track) in the 1553 Data Buffer to be copied and stored in a Shared memory area and multiplexed with tracks from subsequent buffers transmitted/received with the same XID/RT SA 
    SKIP ApiCmdTrackRead	Reads the multiplexed 1553 message data defined as a track with ApiCmdTrackDef
    DONE ApiCmdSysSetMemPartition	Configures the Global RAM of the board
    SKIP ApiCmdSysFree	Free a allocate a target software memory block
    DONE ApiCmdSysGetBoardInfo	Read board information from the target software
    DONE ApiCmdSysGetMemPartition	Reads the configuration of the Global RAM of the board
    SKIP ApiCmdSysMalloc	Allocate a target software memory block
    DONE ApiCmdReadDiscretes	Reads from the onboard discrete register
    DONE ApiCmdReadDiscretesConfig Reads from the onboard discrete config register
    DONE ApiCmdWriteDiscretes	Writes to the onboard discrete register
    DONE ApiCmdInitDiscretes	Initializes the onboard discrete behaviour
    DONE ApiCmdReadDiscretesInfo	Reads the configuration of the discrete channels
    SKIP ApiCmdSysPXICon	Combine PXI specific trigger lines with the trigger lines of AIM boards
    SKIP ApiCmdSysPXIGeographicalAddressGet	Get the geographical address of the PXI slot
    DONE ApiGetBoardName	Read the descriptive board name
    DONE ApiCmdSetIrigStatus This function is used to set the on-board IRIG timecode encoder status.
    DONE ApiCmdGetIrigStatus This function is used to read the on-board IRIG timecode encoder status.
    '''
    ###########################################################################
    #                                                                         #
    #                           Calibration Functions                         #
    #                                                                         #
    ###########################################################################
    def PyApiCmdCalCplCon(self, handle, bus, cpl ):
        """ApiCmdCalCplCon	Sets up the physical MILbus coupling mode"""
        ret = self.lib.ApiCmdCalCplCon(handle, 0, bus, cpl)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdCalCplCon failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdCalSigCon(self, handle, bus, con ):
        """ApiCmdCalSigCon	Enables/disables 1 Mhz square wave calibration test signal"""
        ret = self.lib.ApiCmdCalSigCon(handle, 0, bus, con)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdCalSigCon failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdCalTransCon(self, handle, trans_mode ):
        """ApiCmdCalTransCon	Controls the data rate of MILbus (500 kbps or 1 Mbps)"""
        ret = self.lib.ApiCmdCalTransCon(handle, 0, trans_mode)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdCalTransCon failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdCalXmtCon(self, handle, bus, amp ):
        """ApiCmdCalXmtCon	Modifies the output amplitude of the MILbus/test signal"""
        ret = self.lib.ApiCmdCalXmtCon(handle, 0, bus, amp)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdCalXmtCon failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
    '''
    DONE ApiCmdCalCplCon	Sets up the physical MILbus coupling mode
    DONE ApiCmdCalSigCon	Enables/disables 1 Mhz square wave calibration test signal
    DONE ApiCmdCalTransCon	Controls the data rate of MILbus (500 kbps or 1 Mbps)
    DONE ApiCmdCalXmtCon	Modifies the output amplitude of the MILbus/test signal
    '''

    ###########################################################################
    #                                                                         #
    #                              Buffer Functions                           #
    #                                                                         #
    ###########################################################################
    def PyApiCmdBufDef(self, handle, bt, hid, bid, data ):
        """ApiCmdBufDef	Defines the contents of the BC/RT transmit/receive message buffer"""
        rid = amb.AiUInt16()
        raddr = amb.AiUInt32()
        raw_data = array.array('H', data)

        ret = self.lib.ApiCmdBufDef(handle, 0, bt, hid, bid, 
                                    len(data), 
                                    ctypes.cast(raw_data.buffer_info()[0], ctypes.POINTER(amb.AiUInt16)),
                                    ctypes.byref(rid), 
                                    ctypes.byref(raddr))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBufDef failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return rid.value, raddr.value

    def PyApiCmdBufHostControl(self, handle, bt, hid, con ):
        """ApiCmdBufHostControl	update the current buffer index in host controlled buffer queue mode"""
        ret = self.lib.ApiCmdBufHostControl(handle, 0, bt, hid, con)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBufHostControl failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBufRead(self, handle, bt, hid, bid, len = 32 ):
        """ApiCmdBufRead	Reads the contents of the BC/RT transmit/receive message buffer"""
        data = array.array('H', [0] * len)
        rid = amb.AiUInt16()
        raddr = amb.AiUInt32()
        ret = self.lib.ApiCmdBufRead(handle, 0, bt, hid, bid, 
                                                    len, ctypes.cast(data.buffer_info()[0], ctypes.POINTER(amb.AiUInt16)),
                                                    ctypes.byref(rid), 
                                                    ctypes.byref(raddr))
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBufRead failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return data.tolist(), rid.value, raddr.value
    
    def PyApiCmdBufWrite(self, handle, bt, hid, bid, data_pos, bit_pos, bit_len, data):
        """ApiCmdBufWrite	Writes a data word/bits to variable positions of the BC/RT transmit/receive message buffer"""
        ret = self.lib.ApiCmdBufWrite(handle, 0, bt, hid, bid, data_pos, bit_pos, bit_len, data)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBufWrite failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBufWriteBlock(self, handle, bt, hid, bid, offset, data ):
        """ApiCmdBufWriteBlock	Update the contents of the BC/RT transmit/receive message buffer"""
        raw_data = array.array('H', data)

        ret = self.lib.ApiCmdBufWriteBlock(handle, 0, bt, hid, bid, 
                                    offset, len(data), 
                                    ctypes.cast(raw_data.buffer_info()[0], ctypes.POINTER(amb.AiUInt16)))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBufWriteBlock failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdRamWriteDataset(self, handle, dsid, data ):
        """ApiCmdRamWriteDataset	Writes 32-word dataset to ASP Local RAM when in Dynamic Dataset mode"""
        raw_data = array.array('H', data)
        for i in range(32):
            raw_data[i] = data[i]

        ret = self.lib.ApiCmdRamWriteDataset(handle, 
                                             dsid, 
                                             ctypes.cast(raw_data.buffer_info()[0], ctypes.POINTER(amb.AiUInt16)) )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRamWriteDataset failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdRamReadDataset(self, handle, dsid ):
        """ApiCmdRamReadDataset	Reads 32-word dataset from ASP Local RAM when in Dynamic Dataset mode"""
        data = array.array('H', [0] * 32)

        ret = self.lib.ApiCmdRamReadDataset(handle, 
                                             dsid, 
                                             ctypes.cast(data.buffer_info()[0], ctypes.POINTER(amb.AiUInt16)) )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRamReadDataset failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return data.tolist()

    def PyApiReadMemData(self, handle, memtype, offset, width):
        """ApiReadMemData	Reads a byte/word/longword from AIM board memory bypassing AIM board cmd/ack interface"""

        if width == 4:
            data_read  = (amb.AiUInt32 * 1)()
        elif width == 2:
            data_read  = (amb.AiUInt16 * 1)()
        elif width == 1:
            data_read  = (amb.AiUInt8 * 1)()
        else:
            raise Exception("Invalid type")

        ret = self.lib.ApiReadMemData( handle,
                                            memtype,
                                            offset,
                                            width,
                                            ctypes.byref(data_read))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiReadMemData failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return data_read[0]

    def PyApiWriteMemData(self, handle, memtype, offset, width, value):
        """ApiWriteMemData	Writes a byte/word/longword to AIM board memory bypassing AIM board cmd/ack interface"""

        if width == 4:
            data_write  = (amb.AiUInt32 * 1)()
        elif width == 2:
            data_write  = (amb.AiUInt16 * 1)()
        elif width == 1:
            data_write  = (amb.AiUInt8 * 1)()
        else:
            raise Exception("Invalid type")

        data_write[0] = value

        ret = self.lib.ApiWriteMemData( handle,
                                            memtype,
                                            offset,
                                            width,
                                            ctypes.byref(data_write))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiWriteMemData failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiReadBlockMemData(self, handle, memtype, offset, width, size):
        """ApiReadBlockMemData	Reads a datablock from AIM board memory bypassing AIM board cmd/ack interface"""
        pul_BytesRead = amb.AiUInt32(0)

        if width == 4:
            data_p  = (amb.AiUInt32 * size)()
        elif width == 2:
            data_p  = (amb.AiUInt16 * size)()
        elif width == 1:
            data_p  = (amb.AiUInt8 * size)()
        else:
            raise Exception("Invalid type")

        ret = self.lib.ApiReadBlockMemData( handle,
                                            memtype,
                                            offset,
                                            width,
                                            ctypes.byref(data_p),
                                            size,
                                            ctypes.byref(pul_BytesRead) )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiReadBlockMemData failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        if (size * width) != pul_BytesRead.value: 
            raise MilApiException(ret, "Error: ApiReadBlockMemData did not return enough data %d != %d." % ((size * width), pul_BytesRead.value))

        return [x for x in data_p]

    def PyApiWriteBlockMemData(self, handle, memtype, offset, width, data_p, size):
        """ApiWriteBlockMemData	Writes a datablock to AIM board memory bypassing AIM board cmd/ack interface"""
        pul_BytesWritten = amb.AiUInt32(0)

        if width == 4:
            data_write  = (amb.AiUInt32 * size)()
        elif width == 2:
            data_write  = (amb.AiUInt16 * size)()
        elif width == 1:
            data_write  = (amb.AiUInt8 * size)()
        else:
            raise Exception("Invalid type")

        for i in range(size):
            data_write[i] = data_p[i]

        ret = self.lib.ApiWriteBlockMemData( handle,
                                            memtype,
                                            offset,
                                            width,
                                            ctypes.byref(data_write),
                                            size,
                                            ctypes.byref(pul_BytesWritten) )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiWriteBlockMemData failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        if (size * width) != pul_BytesWritten.value: 
            raise MilApiException(ret, "Error: ApiWriteBlockMemData did not write enough data %d != %d." % ((size * width), pul_BytesWritten.value))

    def PyApiCmdBufC1760Con(self, handle, pc1760 = ambt.PY_TY_API_C1760_CON() ):
        """ApiCmdBufC1760Con	Enables/Disables the generation of MIL-STD-1760 checksum"""
        assert isinstance(pc1760, ambt.PY_TY_API_C1760_CON)
        ctypes_pc1760 = pc1760.toStruct()

        ret = self.lib.ApiCmdBufC1760Con( handle, 0, ctypes.byref(ctypes_pc1760) )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBufC1760Con failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiBHModify(self, handle, px_BHInfo = ambt.PY_TY_API_BH_MODIFY() ):
        """ApiBHModify	Modifies the BC/RT buffer header on-the-fly"""
        assert isinstance(px_BHInfo, ambt.PY_TY_API_BH_MODIFY)
        ctypes_px_BHInfo = px_BHInfo.toStruct()

        ret = self.lib.ApiBHModify( handle, ctypes.byref(ctypes_px_BHInfo) )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiBHModify failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    '''
    DONE ApiCmdBufDef	Defines the contents of the BC/RT transmit/receive message buffer 
    DONE ApiCmdBufRead	Reads the contents of the BC/RT transmit/receive message buffer
    DONE ApiCmdBufWrite	Writes a data word/bits to variable positions of the BC/RT transmit/receive message buffer
    DONE ApiCmdRamWriteDataset	Writes 32-word dataset to ASP Local RAM when in Dynamic Dataset mode
    DONE ApiCmdRamReadDataset	Reads 32-word dataset from ASP Local RAM when in Dynamic Dataset mode
    DONE ApiReadMemData	Reads a byte/word/longword from AIM board memory bypassing AIM board cmd/ack interface
    DONE ApiWriteMemData	Writes a byte/word/longword to AIM board memory bypassing AIM board cmd/ack interface
    DONE ApiReadBlockMemData	Reads a datablock from AIM board memory bypassing AIM board cmd/ack interface
    DONE ApiWriteBlockMemData	Writes a datablock to AIM board memory bypassing AIM board cmd/ack interface
    DONE ApiCmdBufC1760Con	Enables/Disables the generation of MIL-STD-1760 checksum
    DONE ApiBHModify	Modifies the BC/RT buffer header on-the-fly
    '''
    
    ###########################################################################
    #                                                                         #
    #                                FIFO Functions                           #
    #                                                                         #
    ###########################################################################   
    def PyApiCmdFifoIni(self, handle, fifo_nbr, buf_nbr ):
        """ApiCmdFifoIni	Initializes up to 32 FIFOs, each with up to 128 32-word buffers, in shared ASP Local RAM for 1553 transfers"""
        ret = self.lib.ApiCmdFifoIni( handle, 0, fifo_nbr, buf_nbr )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdFifoIni failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdFifoWrite(self, handle, f_id, size, data ):
        """ApiCmdFifoWrite	Loads/reloads buffers of a FIFO with data """
        raw_data = array.array('H', data)

        for i in range(len(data)):
            raw_data[i] = data[i]

        ret = self.lib.ApiCmdFifoWrite(handle, 0, f_id, size,
                                       ctypes.cast(raw_data.buffer_info()[0], ctypes.POINTER(amb.AiUInt16)))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdFifoWrite failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
    
    def PyApiCmdFifoReadStatus(self, handle, f_id ):
        """ApiCmdFifoReadStatus	Reads the status of the number of 16-bit words in FIFO to reload"""
        status = amb.AiUInt16()

        ret = self.lib.ApiCmdFifoReadStatus(handle, 0, f_id, ctypes.byref(status))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdFifoReadStatus failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return status.value

    def PyApiCmdBCAssignFifo(self, handle, con, f_id, xid ):
        """ApiCmdBCAssignFifo	Links a BC transfer to a FIFO.  The FIFO becomes the source of the BC message buffer data transmitted."""
        ret = self.lib.ApiCmdBCAssignFifo(handle, 0, con, f_id, xid)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCAssignFifo failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdRTSAAssignFifo(self, handle, con, f_id, rt, sa ):
        """ApiCmdRTSAAssignFifo	Links an RT data transmission to a FIFO.  The FIFO becomes the source of the RT message buffer data transmitted."""
        ret = self.lib.ApiCmdRTSAAssignFifo(handle, 0, con, f_id, rt, sa)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTSAAssignFifo failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    '''
    DONE ApiCmdFifoIni	Initializes up to 32 FIFOs, each with up to 128 32-word buffers, in shared ASP Local RAM for 1553 transfers
    DONE ApiCmdFifoWrite	Loads/reloads buffers of a FIFO with data 
    DONE ApiCmdFifoReadStatus	Reads the status of the number of 16-bit words in FIFO to reload
    DONE ApiCmdBCAssignFifo	Links a BC transfer to a FIFO.  The FIFO becomes the source of the BC message buffer data transmitted.
    DONE ApiCmdRTSAAssignFifo	Links an RT data transmission to a FIFO.  The FIFO becomes the source of the RT message buffer data transmitted.
    '''

    ###########################################################################
    #                                                                         #
    #                                BC Functions                             #
    #                                                                         #
    ###########################################################################
    def PyApiCmdBCAcycPrep(self, handle, pacyc = ambt.PY_TY_API_BC_ACYC()):
        """ApiCmdBCAcycPrep	Defines the properties of the acyclic “on-the-fly” BC transfers to be inserted into the BC framing sequence"""
        assert isinstance(pacyc, ambt.PY_TY_API_BC_ACYC)
        ctypes_pacyc = pacyc.toStruct()

        ret = self.lib.ApiCmdBCAcycPrep(handle, 0, ctypes.byref(ctypes_pacyc))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCAcycPrep failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBCAcycPrepAndSendTransferBlocking(self, handle, xfer = ambt.PY_TY_API_BC_XFER(), data = []):
        """ApiCmdBCAcycPrepAndSendTransferBlocking	Defines a single transfer, sends it as acyclic, blocks until the transfer status is updated and returns the data buffer."""
        assert isinstance(xfer, ambt.PY_TY_API_BC_XFER)
        ctypes_xfer = xfer.toStruct()
        transfer_status = amb.TY_API_BC_XFER_DSP()

        raw_data = array.array('H', [0] * 32)

        for i in range(len(data)):
            raw_data[i] = data[i]

        ret = self.lib.ApiCmdBCAcycPrepAndSendTransferBlocking(handle, 0, 
                                                               ctypes.byref(ctypes_xfer), 
                                                               ctypes.cast(raw_data.buffer_info()[0], ctypes.POINTER(amb.AiUInt16)), 
                                                               ctypes.byref(transfer_status))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCAcycPrepAndSendTransferBlocking failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return raw_data.tolist(), ambt.PY_TY_API_BC_XFER_DSP.fromStruct(transfer_status)
    
    def PyApiCmdBCAcycSend(self, handle, mode, timetag_high=0, timetag_low=0):
        """ApiCmdBCAcycSend	Starts the insertion of the acyclic transfers into the BC framing sequence “on-the-fly” or at a pre-defined time"""
        ret = self.lib.ApiCmdBCAcycSend(handle, 0, mode, timetag_high, timetag_low )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCAcycSend failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBCBHDef(self, handle, hid, bid, qsize=amb.API_QUEUE_SIZE_1, bqm=amb.API_BQM_CYCLIC, bsm=amb.API_BSM_RX_DISCARD, sqm=amb.API_SQM_ONE_ENTRY_ONLY ):
        """ApiCmdBCBHDef	Defines a BC Buffer Header ID, Buffer Queue size, Queue mode & error protocol"""
        pbh = amb.TY_API_BC_BH_INFO()
        ret = self.lib.ApiCmdBCBHDef(handle, 0, hid, bid, 0, 0, qsize, bqm, bsm, sqm, 0, 0, ctypes.byref(pbh))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCBHDef failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ambt.PY_TY_API_BC_BH_INFO.fromStruct(pbh)

    def PyApiCmdBCBHRead(self, handle, uw_HeaderId ):
        """ApiCmdBCBHRead	Read the Data Buffer ID, Buffer Queue size, Queue mode, and error protocol of a BC Buffer Header ID"""
        px_Pbh = amb.TY_API_BC_BH_INFO()
        ret = self.lib.ApiCmdBCBHRead(handle, 0, uw_HeaderId, ctypes.byref(px_Pbh))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCBHRead failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ambt.PY_TY_API_BC_BH_INFO.fromStruct(px_Pbh)

    def PyApiCmdBCDytagDef( self, handle, 
                                     con,
                                     bc_hid,
                                     mode,
                                     bc_dytag = [ambt.PY_TY_API_BC_DYTAG() for i in range(4)] ):
        """ApiCmdBCDytagDef	Defines the generation of dynamic data words for BC transmissions"""
        ctypes_bc_dytag = (amb.TY_API_BC_DYTAG * 4)()
        for i in range(4):
            ctypes_bc_dytag[i] = bc_dytag[i].toStruct()

        ret = self.lib.ApiCmdBCDytagDef(handle, 0, con, bc_hid, mode, ctypes.byref(ctypes_bc_dytag) )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCDytagDef failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBCFrameDef( self, handle, pframe = ambt.PY_TY_API_BC_FRAME ):
        """ApiCmdBCFrameDef	Defines the sequence of 1553 transfers within a minor frame with options for inserting delays,
           strobe pulse outputs, and skip transfer instructions"""
        assert isinstance(pframe, ambt.PY_TY_API_BC_FRAME)
        ctypes_pframe = pframe.toStruct()

        ret = self.lib.ApiCmdBCFrameDef(handle, 0, ctypes.byref(ctypes_pframe))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCFrameDef failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBCGetDytagDef( self, handle, bc_hid ):
        """ApiCmdBCGetDytagDef	Read Dytag settings for the generation of dynamic data words for BC-RT transfer type or for BC broadcast transfer type"""
        ctypes_mode     = amb.AiUInt16()
        ctypes_bc_dytag = (amb.TY_API_BC_DYTAG * 4)()

        ret = self.lib.ApiCmdBCGetDytagDef(handle, 0, bc_hid, ctypes.byref(ctypes_mode), ctypes.byref(ctypes_bc_dytag))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCGetDytagDef failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ctypes_mode.value, [ambt.PY_TY_API_BC_DYTAG.fromStruct(d) for d in ctypes_bc_dytag]

    def PyApiCmdBCGetXferBufferHeaderInfo( self, handle, ul_XferId ):
        """ApiCmdBCGetXferBufferHeaderInfo	Get the buffer header id of given transfer"""
        pul_BufHeaderIndex = amb.AiUInt32()
        pul_BufHeaderAddr  = amb.AiUInt32()

        ret = self.lib.ApiCmdBCGetXferBufferHeaderInfo(handle, 0, ul_XferId, ctypes.byref(pul_BufHeaderIndex), ctypes.byref(pul_BufHeaderAddr))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCGetXferBufferHeaderInfo failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return pul_BufHeaderIndex.value, pul_BufHeaderAddr.value
    
    def PyApiCmdBCGetXferDef( self, handle, ul_XferId ):
        """ApiCmdBCGetXferDef	Get all transfer properties of a Bus Controller Transfer"""
        px_BCXfer  = amb.TY_API_BC_XFER()

        ret = self.lib.ApiCmdBCGetXferDef(handle, 0, ul_XferId, ctypes.byref(px_BCXfer))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCGetXferDef failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ambt.PY_TY_API_BC_XFER.fromStruct(px_BCXfer)
    
    def PyApiCmdBCHalt( self, handle ):
        """ApiCmdBCHalt	Stops BC transfers"""
        ret = self.lib.ApiCmdBCHalt( handle, 0 )
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCHalt failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBCIni( self, handle, retry=amb.API_DIS, svrq=amb.API_DIS, tbm=amb.API_TBM_TRANSFER, gsb=amb.API_BC_XFER_BUS_PRIMARY ):
        """ApiCmdBCIni	Initializes the BC with information controlling # of retries and bus switching"""
        ret = self.lib.ApiCmdBCIni( handle, 0, retry, svrq, tbm, gsb )
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCIni failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBCInstrTblGen(self, handle, mode, cnt, dest_count, dest_offset, tbl = [] ):
        """ Call ApiCmdBCinstrTblGen with mode 0 to clear the table or mode 3 to convert and write the table."""
        ctbl       = (amb.AiUInt32           * cnt)()
        err_line   = amb.AiUInt32()
        status     = amb.AiUInt8()
        ctypes_tbl = (amb.TY_API_BC_FW_INSTR * cnt)()

        for i in range(cnt):
            assert isinstance(tbl[i], ambt.PY_TY_API_BC_FW_INSTR)
            ctypes_tbl[i] = tbl[i].toStruct()

        # Write instruction list
        ret = self.lib.ApiCmdBCInstrTblGen(handle,
                                            0,
                                            mode,
                                            cnt,
                                            dest_count,
                                            dest_offset,
                                            ctypes.byref(ctypes_tbl), # in/out
                                            ctypes.byref(ctbl),       # out
                                            ctypes.byref(err_line),   # out
                                            ctypes.byref(status))     # out

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCInstrTblGen failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return [ambt.PY_TY_API_BC_FW_INSTR.fromStruct(s) for s in ctypes_tbl], [v for v in ctbl], err_line.value, status.value

    def PyApiCmdBCInstrTblGen(self, handle, mode, cnt, dest_count, dest_offset, tbl = [] ):
        """ Call ApiCmdBCinstrTblGen with mode 0 to clear the table or mode 3 to convert and write the table."""
        ctbl       = (amb.AiUInt32           * cnt)()
        err_line   = amb.AiUInt32()
        status     = amb.AiUInt8()
        ctypes_tbl = (amb.TY_API_BC_FW_INSTR * cnt)()

        for i in range(cnt):
            assert isinstance(tbl[i], ambt.PY_TY_API_BC_FW_INSTR)
            ctypes_tbl[i] = tbl[i].toStruct()

        # Write instruction list
        ret = self.lib.ApiCmdBCInstrTblGen(handle,
                                            0,
                                            mode,
                                            cnt,
                                            dest_count,
                                            dest_offset,
                                            ctypes.byref(ctypes_tbl), # in/out
                                            ctypes.byref(ctbl),       # out
                                            ctypes.byref(err_line),   # out
                                            ctypes.byref(status))     # out

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCInstrTblGen failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return [ambt.PY_TY_API_BC_FW_INSTR.fromStruct(s) for s in ctypes_tbl], [v for v in ctbl], err_line.value, status.value
    
    def PyApiCmdBCInstrTblGetAddrFromLabel(self, handle, label, cnt, tbl = [] ):
        """ApiCmdBCInstrTblGetAddrFromLabel Obtains the address of a BC Instruction Table entry pre-defined by the user using the ApiCmdBCInstrTblGen function"""
        ctypes_tbl = (amb.TY_API_BC_FW_INSTR * cnt)()
        raddr      = amb.AiUInt32()
        line       = amb.AiUInt32()

        for i in range(cnt):
            assert isinstance(tbl[i], ambt.PY_TY_API_BC_FW_INSTR)
            ctypes_tbl[i] = tbl[i].toStruct()

        # Write instruction list
        ret = self.lib.ApiCmdBCInstrTblGetAddrFromLabel(handle,
                                            0,
                                            label,
                                            cnt,
                                            ctypes.byref(ctypes_tbl),  # in
                                            ctypes.byref(raddr),       # out
                                            ctypes.byref(line))        # out

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCInstrTblGetAddrFromLabel failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return raddr.value, line.value

    def PyApiCmdBCInstrTblIni(self, handle):
        """ApiCmdBCInstrTblIni	Initializes the memory area associated with creating a BC Instruction Table for major and minor frame sequencing"""
        ret = self.lib.ApiCmdBCInstrTblIni(handle,0)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCInstrTblIni failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
    def PyApiCmdBCMFrameDefEx(self, handle, pmframe = ambt.PY_TY_API_BC_MFRAME_EX() ):
        """ApiCmdBCMFrameDefEx	Defines the sequence of minor fames within the major frame"""
        assert isinstance(pmframe, ambt.PY_TY_API_BC_MFRAME_EX)
        ctypes_pmframe = pmframe.toStruct()

        ret = self.lib.ApiCmdBCMFrameDefEx(handle, 0, ctypes.byref(ctypes_pmframe))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCMFrameDefEx failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBCSrvReqVecCon( self, handle, uc_RtAddr, px_SrvReqVecCon = ambt.PY_TY_API_BC_SRVW_CON() ): 
        """ApiCmdBCSrvReqVecCon	Set the sub address where the modecode “Last Vector Word” is sent to in case of a service request handling"""
        assert isinstance(px_SrvReqVecCon, ambt.PY_TY_API_BC_SRVW_CON)
        ctypes_px_SrvReqVecCon = px_SrvReqVecCon.toStruct()
        ret = self.lib.ApiCmdBCSrvReqVecCon( handle, 0, uc_RtAddr, ctypes.byref(ctypes_px_SrvReqVecCon) )
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCSrvReqVecCon failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBCSrvReqVecStatus( self, handle, uc_RtAddr ):
        """ApiCmdBCSrvReqVecStatus	Read BC Service Request and Vector Word Status information maintained by the BC for a specific RT"""
        px_SrvReqVecStatus = amb.TY_API_BC_SRVW()
        ret = self.lib.ApiCmdBCSrvReqVecStatus( handle, 0, uc_RtAddr, ctypes.byref(px_SrvReqVecStatus) )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCSrvReqVecStatus failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ambt.PY_TY_API_BC_SRVW.fromStruct(px_SrvReqVecStatus)

    def PyApiCmdBCStart( self, handle, smode=amb.API_BC_START_IMMEDIATELY, cnt=0, frame_time=16.0, saddr = 0):
        """ApiCmdBCStart	Starts the execution of pre-defined BC transfers within minor/major frame structure and defines minor fame timing"""
        ulMajorAddr  = amb.AiUInt32(0)
        aulMinorAddr = (amb.AiUInt32 * 64)(0)
        ctypes_frame_time = amb.AiFloat(frame_time)
        
        ret = self.lib.ApiCmdBCStart( handle, 0, smode, cnt, ctypes_frame_time, saddr, ctypes.byref(ulMajorAddr), ctypes.byref(aulMinorAddr) )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCStart failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return ulMajorAddr.value, [v for v in aulMinorAddr]

    def PyApiCmdBCStatusRead(self, handle):
        """ApiCmdBCStatusRead	Reads execution status of the BC"""
        pdsp = amb.TY_API_BC_STATUS_DSP()

        ret = self.lib.ApiCmdBCStatusRead(handle, 0, ctypes.byref(pdsp))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCStatusRead failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ambt.PY_TY_API_BC_STATUS_DSP.fromStruct(pdsp)

    def PyApiCmdBCTrafficOverrideControl(self, handle, con ):
        """ApiCmdBCTrafficOverrideControl	Enable/disable the bus idle check for BC transmissions"""
        ret = self.lib.ApiCmdBCTrafficOverrideControl(handle, 0, con)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCTrafficOverrideControl failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBCTrafficOverrideGet(self, handle ):
        """ApiCmdBCTrafficOverrideGet	Check if the bus idle check for BC transmissions is enabled"""
        con = amb.AiUInt32()
        ret = self.lib.ApiCmdBCTrafficOverrideGet(handle, 0, ctypes.byref(con))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCTrafficOverrideGet failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return con.value
    
    def PyApiCmdBCXferCtrl(self, handle, xid, mode ):
        """ApiCmdBCXferCtrl	Enables/Disables the BC Transfer """
        ret = self.lib.ApiCmdBCXferCtrl(handle, 0, xid, mode)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCXferCtrl failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
    def PyApiCmdBCXferDef(self, handle, pxfer = ambt.PY_TY_API_BC_XFER() ):
        """ApiCmdBCXferDef	Defines all transfer properties including source/destination information, error insertion and interrupt generation"""
        assert isinstance(pxfer, ambt.PY_TY_API_BC_XFER)
        ctyps_pxfer = pxfer.toStruct()
        desc_addr = amb.AiUInt32()

        ret = self.lib.ApiCmdBCXferDef(handle, 0, ctypes.byref(ctyps_pxfer), ctypes.byref(desc_addr))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCXferDef failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        desc_addr.value

    def PyApiCmdBCXferDefErr(self, handle, xid, pxError = ambt.PY_TY_API_BC_ERR() ):
        """ApiCmdBCXferDefErr	Defines a transfer error injection on the fly."""
        assert isinstance(pxError, ambt.PY_TY_API_BC_ERR)
        ctypes_pxError = pxError.toStruct()

        ret = self.lib.ApiCmdBCXferDefErr(handle, 0, xid, ctypes.byref(ctypes_pxError))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCXferDefErr failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBCXferDescGet(self, handle, xid, mode ):
        """ApiCmdBCXferDescGet	Get a transfer descriptor value"""
        ctypes_value = (amb.AiUInt32 * 4)()

        ret = self.lib.ApiCmdBCXferDescGet(handle, 0, xid, mode, ctypes.byref(ctypes_value))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCXferDescGet failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return [v for v in ctypes_value]
    
    def PyApiCmdBCXferDescMod(self, handle, xid, mode, value = [0,0,0,0] ):
        """ApiCmdBCXferDescMod	Modify a transfer descriptor value"""
        ctypes_value = (amb.AiUInt32 * 4)()

        for i in range(4):
            ctypes_value[i] = value[i]
        
        ret = self.lib.ApiCmdBCXferDescMod(handle, 0, xid, mode, ctypes.byref(ctypes_value))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCXferDescMod failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
   
    def PyApiCmdBCXferRead(self, handle, xid, clr = 0x7 ):
        """ApiCmdBCXferRead	Reads status of an individual BC transfer"""
        pxfer_dsp = amb.TY_API_BC_XFER_DSP()

        ret = self.lib.ApiCmdBCXferRead(handle, 0, xid, clr, ctypes.byref(pxfer_dsp))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCXferRead failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ambt.PY_TY_API_BC_XFER_DSP.fromStruct(pxfer_dsp)

    def PyApiCmdBCXferReadEx(self, handle, px_XferReadIn = ambt.PY_TY_API_BC_XFER_READ_IN() ):
        """ApiCmdBCXferReadEx	Reads status of an individual BC transfer"""
        assert isinstance(px_XferReadIn, ambt.PY_TY_API_BC_XFER_READ_IN)
        ctypes_px_XferReadIn  = px_XferReadIn.toStruct()
        px_XferStat = amb.TY_API_BC_XFER_STATUS_EX()

        ret = self.lib.ApiCmdBCXferReadEx(handle, ctypes.byref(ctypes_px_XferReadIn), ctypes.byref(px_XferStat))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCXferReadEx failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ambt.PY_TY_API_BC_XFER_STATUS_EX.fromStruct(px_XferStat)

    def PyApiCmdBCModeCtrl( self, handle, px_BcModeCtrl = ambt.PY_TY_API_BC_MODE_CTRL() ):
        """This function is used to enable / disable various BC functionality on-the-fly."""
        assert isinstance(px_BcModeCtrl, ambt.PY_TY_API_BC_MODE_CTRL)
        ctypes_px_BcModeCtrl = px_BcModeCtrl.toStruct()

        ret = self.lib.ApiCmdBCModeCtrl( handle, 0, ctypes.byref(ctypes_px_BcModeCtrl))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBCModeCtrl failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
    '''
    DONE ApiCmdBCAcycPrep	Defines the properties of the acyclic “on-the-fly” BC transfers to be inserted into the BC framing sequence
    DONE ApiCmdBCAcycPrepAndSendTransferBlocking	Defines a single transfer, sends it as acyclic, blocks until the transfer status is updated and returns the data buffer.
    DONE ApiCmdBCAcycSend	Starts the insertion of the acyclic transfers into the BC framing sequence “on-the-fly” or at a pre-defined time
    DONE ApiCmdBCBHDef	Defines a BC Buffer Header ID, Buffer Queue size, Queue mode & error protocol
    DONE ApiCmdBCBHRead	Read the Data Buffer ID, Buffer Queue size, Queue mode, and error protocol of a BC Buffer Header ID
    DONE ApiCmdBCDytagDef	Defines the generation of dynamic data words for BC transmissions
    DONE ApiCmdBCFrameDef	Defines the sequence of 1553 transfers within a minor frame with options for inserting delays, strobe pulse outputs, and skip transfer instructions
    DONE ApiCmdBCGetDytagDef	Read Dytag settings for the generation of dynamic data words for BC-RT transfer type or for BC broadcast transfer type
    SKIP ApiCmdBCGetMajorFrameDefinition	Read the sequence of Minor Frames within the Major Frame
    SKIP ApiCmdBCGetMinorFrameDefinition	Read the sequence of Bus Controller Transfers within a Minor Frame sequence
    DONE ApiCmdBCGetXferBufferHeaderInfo	Get the buffer header id of given transfer
    DONE ApiCmdBCGetXferDef	Get all transfer properties of a Bus Controller Transfer
    DONE ApiCmdBCHalt	Stops BC transfers
    DONE ApiCmdBCIni	Initializes the BC with information controlling # of retries and bus switching  
    DONE ApiCmdBCInstrTblGen	Provides an alternate method of defining minor and major frame sequences
    DONE ApiCmdBCInstrTblGetAddrFromLabel Obtains the address of a BC Instruction Table entry pre-defined by the user using the ApiCmdBCInstrTblGen function
    DONE ApiCmdBCInstrTblIni	Initializes the memory area associated with creating a BC Instruction Table for major and minor frame sequencing
    SKIP ApiCmdBCMFrameDef	Defines the sequence of minor fames within the major frame
    DONE ApiCmdBCMFrameDefEx	Defines the sequence of minor fames within the major frame
    DONE ApiCmdBCSrvReqVecCon	Set the sub address where the modecode “Last Vector Word” is sent to in case of a service request handling
    DONE ApiCmdBCSrvReqVecStatus	Read BC Service Request and Vector Word Status information maintained by the BC for a specific RT
    DONE ApiCmdBCStart	Starts the execution of pre-defined BC transfers within minor/major frame structure and defines minor fame timing
    DONE ApiCmdBCStatusRead	Reads execution status of the BC
    DONE ApiCmdBCTrafficOverrideControl	Enable/disable the bus idle check for BC transmissions
    DONE ApiCmdBCTrafficOverrideGet	Check if the bus idle check for BC transmissions is enabled
    DONE ApiCmdBCXferCtrl	Enables/Disables the BC Transfer 
    DONE ApiCmdBCXferDef	Defines all transfer properties including source/destination information, error insertion and interrupt generation
    DONE ApiCmdBCXferDefErr	Defines a transfer error injection on the fly.
    DONE ApiCmdBCXferDescGet	Get a transfer descriptor value
    DONE ApiCmdBCXferDescMod	Modify a transfer descriptor value
    DONE ApiCmdBCXferRead	Reads status of an individual BC transfer
    DONE ApiCmdBCXferReadEx	Reads status of an individual BC transfer
    DONE ApiCmdBCModeCtrl This function is used to enable / disable various BC functionality on-the-fly.
    '''

    ###########################################################################
    #                                                                         #
    #                                RT Functions                             #
    #                                                                         #
    ###########################################################################

    def PyApiCmdRTBHDef(self, handle, hid, bid, qsize=amb.API_QUEUE_SIZE_1, bqm=amb.API_BQM_CYCLIC, bsm=amb.API_BSM_RX_DISCARD, sqm=amb.API_SQM_ONE_ENTRY_ONLY ):
        """ApiCmdRTBHDef	Defines an RT Buffer Header to be assigned to an RT SA/Mode code"""
        pbh = amb.TY_API_RT_BH_INFO()
        ret = self.lib.ApiCmdRTBHDef(handle, 0, hid, bid, 0, 0, qsize, bqm, bsm, sqm, 0, 0, ctypes.byref(pbh))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTBHDef failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        return ambt.PY_TY_API_RT_BH_INFO.fromStruct(pbh)

    def PyApiCmdRTBHRead(self, handle, uw_Headerid ):
        """ApiCmdRTBHRead	Read the RT-SA buffer header structure"""
        px_Pbh = amb.TY_API_RT_BH_INFO()
        ret = self.lib.ApiCmdRTBHRead(handle, 0, uw_Headerid, ctypes.byref(px_Pbh))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTBHRead failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        return ambt.PY_TY_API_RT_BH_INFO.fromStruct(px_Pbh)

    def PyApiCmdRTDytagDef( self, handle, 
                                     con,
                                     rt_hid,
                                     mode,
                                     rt_dytag = [ambt.PY_TY_API_RT_DYTAG() for i in range(4)] ):
        """ApiCmdRTDytagDef	Defines dynamic data to be inserted into the RT transmit Data words"""
        ctypes_rt_dytag = (amb.TY_API_RT_DYTAG * 4)()
        for i in range(4):
            assert isinstance(rt_dytag[i], ambt.PY_TY_API_RT_DYTAG)
            ctypes_rt_dytag[i] = rt_dytag[i].toStruct()

        ret = self.lib.ApiCmdRTDytagDef(handle, 0, con, rt_hid, mode, ctypes.byref(ctypes_rt_dytag) )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTDytagDef failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdRTEnaDis( self, handle, rt_addr, con ):
        """ApiCmdRTEnaDis	Enables/Disables  a selected RT on the fly"""
        ret = self.lib.ApiCmdRTEnaDis(handle, 0, rt_addr, con )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTEnaDis failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
    
    def PyApiCmdRTGetDytagDef( self, handle, rt_hid  ):
        """ApiCmdRTGetDytagDef	Read the Dytag settings for the generation of dynamic data words for a RT transmit SA"""
        ctypes_mode     = amb.AiUInt16()
        ctypes_rt_dytag = (amb.TY_API_RT_DYTAG * 4)()

        ret = self.lib.ApiCmdRTGetDytagDef(handle, 0, rt_hid, ctypes.byref(ctypes_mode), ctypes.byref(ctypes_rt_dytag))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTGetDytagDef failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ctypes_mode.value, [ambt.PY_TY_API_RT_DYTAG.fromStruct(d) for d in ctypes_rt_dytag]
    
    def PyApiCmdRTGetSABufferHeaderInfo( self, handle, rt_addr, sa_type, sa ):
        """ApiCmdRTGetSABufferHeaderInfo	Get the buffer header id of a certain RT/SA combination"""
        pul_BufHeaderIndex    = amb.AiUInt16()
        pul_BufHeaderAddr     = amb.AiUInt32()

        ret = self.lib.ApiCmdRTGetSABufferHeaderInfo(handle, 0, rt_addr, sa_type, sa, ctypes.byref(pul_BufHeaderIndex), ctypes.byref(pul_BufHeaderAddr))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTGetSABufferHeaderInfo failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return pul_BufHeaderIndex.value, pul_BufHeaderAddr.value

    def PyApiCmdRTGetSAConErr( self, handle, rt_addr, sa, sa_type ):
        """ApiCmdRTGetSAConErr	Read the error injection settings of the specified RT Sub-address/Mode code"""
        perr = amb.TY_API_RT_ERR()

        ret = self.lib.ApiCmdRTGetSAConErr(handle, 0, rt_addr, sa, sa_type, ctypes.byref(perr))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTGetSAConErr failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ambt.PY_TY_API_RT_ERR.fromStruct(perr)

    def PyApiCmdRTHalt(self, handle):
        """ApiCmdRTHalt	Stops the RT operation for all assigned RTs"""
        ret = self.lib.ApiCmdRTHalt(handle, 0)
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTHalt failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdRTIni(self, handle, rt_addr, con, bus=amb.API_RT_RSP_BOTH_BUSSES, resp_time=8.0, nxw=None):
        """ApiCmdRTIni	Initializes a select  RT including configuration for simulation/mailbox mode, Response time and Next Status word"""
        if nxw == None:
            nxw = rt_addr<<11
        ret = self.lib.ApiCmdRTIni(handle, 0, rt_addr, con, bus, amb.AiFloat(resp_time), nxw)
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTIni failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdRTLCW(self, handle, rt_addr, lcw ):
        """ApiCmdRTLCW	Redefines the Last Command word associated with the RT"""
        ret = self.lib.ApiCmdRTLCW(handle, 0, rt_addr, lcw )
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTLCW failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdRTLSW(self, handle, rt_addr, lsw ):
        """ApiCmdRTLSW	Redefines the Last Status word associated with the RT"""
        ret = self.lib.ApiCmdRTLSW(handle, 0, rt_addr, lsw )
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTLSW failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
    def PyApiCmdRTMsgRead(self, handle, rt_addr):
        """ApiCmdRTMsgRead	Reads the individual RT’s Next/Last Status word, Last Command word and message and error counter"""
        pmsg_dsp = amb.TY_API_RT_MSG_DSP()
        ret = self.lib.ApiCmdRTMsgRead(handle, 0, rt_addr, ctypes.byref(pmsg_dsp))
        
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTMsgRead failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return ambt.PY_TY_API_RT_MSG_DSP.fromStruct(pmsg_dsp)

    def PyApiCmdRTGetSimulationInfo(self, handle, rt_addr):
        """ApiCmdRTGetSimulationInfo	Reads the individual RT’s simulation and monitoring status"""
        psim_info = amb.TY_API_RT_INFO()
        ret = self.lib.ApiCmdRTGetSimulationInfo(handle, 0, rt_addr, ctypes.byref(psim_info))
        
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTGetSimulationInfo failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return ambt.PY_TY_API_RT_INFO.fromStruct(psim_info)

    def PyApiCmdRTSACon(self, handle, rt_addr, sa, hid, sa_type, con, smod=amb.API_RT_SWM_OR, swm=0 ):
        """ApiCmdRTSACon	Defines the properties of the RT SA/Mode code such as interrupt control, and unique Next Status word setup """
        ret = self.lib.ApiCmdRTSACon(handle, 0, rt_addr, sa, hid, sa_type, con, 0, smod, swm)
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTSACon failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdRTSAConErr(self, handle, rt_addr, sa, sa_type, perr = ambt.PY_TY_API_RT_ERR() ):
        """ApiCmdRTSAConErr	Defines the error injection of the RT SA/Mode code"""
        assert isinstance(perr, ambt.PY_TY_API_RT_ERR)
        ctypes_perr = perr.toStruct()

        ret = self.lib.ApiCmdRTSAConErr(handle, 0, rt_addr, sa, sa_type, ctypes.byref(ctypes_perr))
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTSAConErr failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdRTSADWCSet(self, handle, uc_RtAddr, uc_SA, uc_SAType, ul_WordCnt ):
        """ApiCmdRTSADWCSet	Defines the defined word count of the RT SA"""
        ret = self.lib.ApiCmdRTSADWCSet(handle, 0, uc_RtAddr, uc_SA, uc_SAType, ul_WordCnt)
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTSADWCSet failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdRTSADWCGet(self, handle, uc_RtAddr, uc_SA, uc_SAType ):
        """ApiCmdRTSADWCGet	Reads the defined word count of the RT SA"""
        ul_WordCnt = amb.AiUInt32(0)

        ret = self.lib.ApiCmdRTSADWCGet(handle, 0, uc_RtAddr, uc_SA, uc_SAType, ctypes.byref(ul_WordCnt))
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTSADWCGet failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ul_WordCnt.value
    
    def PyApiCmdRTSAMsgRead(self, handle, rt_addr, sa, sa_type, clr=3):
        """ApiCmdRTSAMsgRead	Reads the execution status for an RT SA/Mode code"""
        psa_dsp = amb.TY_API_RT_SA_MSG_DSP()
        ret = self.lib.ApiCmdRTSAMsgRead(handle, 0, rt_addr, sa, sa_type, clr, ctypes.byref(psa_dsp))
        
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTSAMsgRead failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ambt.PY_TY_API_RT_SA_MSG_DSP.fromStruct(psa_dsp)

    def PyApiCmdRTMsgReadAll(self, handle):
        """ApiCmdRTMsgReadAll	Reads the RT message and error counter for all 32 RTs"""
        pall_dsp = amb.TY_API_RT_MSG_ALL_DSP()
        ret = self.lib.ApiCmdRTMsgReadAll(handle, 0, ctypes.byref(pall_dsp))
        
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTMsgReadAll failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ambt.PY_TY_API_RT_MSG_ALL_DSP.fromStruct(pall_dsp)
    
    def PyApiCmdRTNXW(self, handle, rt_addr, nxw ):
        """ApiCmdRTNXW	Redefines the Next Status word associated with the RT"""
        ret = self.lib.ApiCmdRTNXW(handle, 0, rt_addr, nxw )
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTNXW failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdRTRespTime(self, handle, rt_addr, resp_time = 8.0 ):
        """ApiCmdRTRespTime	Redefines the Response time associated with the RT"""
        ret = self.lib.ApiCmdRTRespTime(handle, 0, rt_addr, amb.AiFloat(resp_time) )
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTRespTime failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdRTRespTimeGet(self, handle, rt_addr ):
        """ApiCmdRTRespTimeGet	Gets the Response time associated with the RT"""
        pResp_time = amb.AiFloat(0)

        ret = self.lib.ApiCmdRTRespTimeGet(handle, 0, rt_addr, ctypes.byref(pResp_time) )
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTRespTimeGet failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return pResp_time.value
    
    def PyApiCmdRTSAMsgReadEx(self, handle, px_MsgReadIn = ambt.PY_TY_API_RT_SA_MSG_READ_IN()):
        """PyApiCmdRTSAMsgReadEx	Reads the execution status for an RT SA/Mode code"""
        assert isinstance(px_MsgReadIn, ambt.PY_TY_API_RT_SA_MSG_READ_IN)
        ctypes_px_MsgReadIn = px_MsgReadIn.toStruct()
        ctypes_px_RtSaStatus = amb.TY_API_RT_SA_STATUS_EX()

        ret = self.lib.ApiCmdRTSAMsgReadEx(handle, ctypes.byref(ctypes_px_MsgReadIn), ctypes.byref(ctypes_px_RtSaStatus))
        
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTSAMsgReadEx failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ambt.PY_TY_API_RT_SA_STATUS_EX.fromStruct(ctypes_px_RtSaStatus)

    def PyApiCmdRTStart(self, handle):
        """ApiCmdRTStart	Starts the RT operation for all assigned RTs """
        ret = self.lib.ApiCmdRTStart(handle, 0)
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTStart failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdRTStatusRead(self, handle):
        """ApiCmdRTStatusRead	Reads the execution status of the general RT operation and the  RT global message and error counters"""
        pdsp = amb.TY_API_RT_STATUS_DSP()
        ret = self.lib.ApiCmdRTStatusRead(handle, 0, ctypes.byref(pdsp))
        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdRTStatusRead failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        return ambt.PY_TY_API_RT_STATUS_DSP.fromStruct(pdsp)    
    '''
    DONE ApiCmdRTBHDef	Defines an RT Buffer Header to be assigned to an RT SA/Mode code
    DONE ApiCmdRTBHRead	Read the RT-SA buffer header structure
    DONE ApiCmdRTDytagDef	Defines dynamic data to be inserted into the RT transmit Data words
    DONE ApiCmdRTEnaDis	Enables/Disables  a selected RT on the fly
    Done ApiCmdRTGetDytagDef	Read the Dytag settings for the generation of dynamic data words for a RT transmit SA
    DONE ApiCmdRTGetSABufferHeaderInfo	Get the buffer header id of a certain RT/SA combination
    DONE ApiCmdRTGetSAConErr	Read the error injection settings of the specified RT Sub-address/Mode code
    SKIP ApiCmdRTGetSimulationInfo	Read the simulation and monitoring status of an RT
    SKIP ApiCmdRTGlobalCon	Initializes multiple RTs at one time (combination of ApiCmdRTIni and ApiCmdRTSACon)
    DONE ApiCmdRTHalt	Stops the RT operation for all assigned RTs
    DONE ApiCmdRTIni	Initializes a select  RT including configuration for simulation/mailbox mode, Response time and Next Status word
    DONE ApiCmdRTLCW	Redefines the Last Command word associated with the RT
    DONE ApiCmdRTLSW	Redefines the Last Status word associated with the RT
    DONE ApiCmdRTMsgRead	Reads the individual RT’s Next/Last Status word, Last Command word and message and error counter
    DONE ApiCmdRTMsgReadAll	Reads the RT message and error counter for all 32 RTs
    DONE ApiCmdRTNXW	Redefines the Next Status word associated with the RT
    DONE ApiCmdRTRespTime	Redefines the Response time associated with the RT
    DONE ApiCmdRTRespTimeGet	Gets the Response time associated with the RT
    DONE ApiCmdRTSACon	Defines the properties of the RT SA/Mode code such as interrupt control, and unique Next Status word setup 
    DONE ApiCmdRTSAConErr	Defines the error injection of the RT SA/Mode code
    DONE ApiCmdRTSADWCSet	Defines the defined word count of the RT SA
    DONE ApiCmdRTSADWCGet	Reads the defined word count of the RT SA
    DONE ApiCmdRTSAMsgRead	Reads the execution status for an RT SA/Mode code
    DONE ApiCmdRTSAMsgReadEx	Reads the execution status for an RT SA/Mode code
    DONE ApiCmdRTStart	Starts the RT operation for all assigned RTs 
    DONE ApiCmdRTStatusRead	Reads the execution status of the general RT operation and the  RT global message and error counters
    '''

    ###########################################################################
    #                                                                         #
    #                                BM Functions                             #
    #                                                                         #
    ###########################################################################
    def PyApiCmdBMActRead( self, handle, entry_no ):
        """ApiCmdBMActRead	Reads BM Bus Activity transfer/error counters"""
        pact = amb.TY_API_BM_ACT_DSP()
        ret = self.lib.ApiCmdBMActRead(handle, 0, entry_no, ctypes.byref(pact))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBMActRead failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ambt.PY_TY_API_BM_ACT_DSP.fromStruct(pact)

    def PyApiCmdBMCapMode( self, handle, pcap = ambt.PY_TY_API_BM_CAP_SETUP() ):
        """ApiCmdBMCapMode	Configures the Capture/Recording mode of the BM"""
        assert isinstance(pcap, ambt.PY_TY_API_BM_CAP_SETUP)
        ctypes_pcap = pcap.toStruct()

        ret = self.lib.ApiCmdBMCapMode(handle, 0, ctypes.byref(ctypes_pcap))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBMCapMode failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBMFilterIni( self, handle, rt_addr, rx_sa, tx_sa, rx_mc, tx_mc ):
        """ApiCmdBMFilterIni	Disables the monitoring of specific RT SA/Mode codes """
        ret = self.lib.ApiCmdBMFilterIni(handle, 0, rt_addr, rx_sa, tx_sa, rx_mc, tx_mc)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBMFilterIni failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBMFTWIni( self, handle, con, htm, htc, stm, stc ):
        """ApiCmdBMFTWIni	Defines the bit pattern to be used by the BM to initiate a Start Trigger Event and/or Stop Trigger Event used for Start/Stop of the “Data Capture”"""
        ret = self.lib.ApiCmdBMFTWIni(handle, 0, con, htm, htc, stm, stc)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBMFTWIni failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
    
    def PyApiCmdBMHalt( self, handle ):
        """ApiCmdBMHalt	Starts the chronological BM operation"""
        ret = self.lib.ApiCmdBMHalt(handle, 0)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBMHalt failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
    
    def PyApiCmdBMIllegalIni( self, handle, rt_addr, rx_sa, tx_sa, rx_mc, tx_mc ):
        """ApiCmdBMIllegalIni	Sets up the BM to tag/not tag illegal command transfers to specific RT SA/Mode codes"""
        ret = self.lib.ApiCmdBMIllegalIni(handle, 0, rt_addr, rx_sa, tx_sa, rx_mc, tx_mc)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBMIllegalIni failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBMIni( self, handle ):
        """ApiCmdBMIni	Initializes the Bus Monitor"""
        ret = self.lib.ApiCmdBMIni(handle, 0)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBMIni failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBMIntrMode( self, handle, imod = amb.API_BM_MODE_NO_INT, smod = amb.API_BM_NO_STROBE ):
        """ApiCmdBMIntrMode	Enables/disables the generation of interrupt and strobe outputs for various BM conditions"""
        ret = self.lib.ApiCmdBMIntrMode(handle, 0, imod, smod, 0)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBMIntrMode failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBMRTActRead( self, handle, rt ):
        """ApiCmdBMRTActRead	Reads the BM transfer/error counters for a specified RT"""
        pact = amb.TY_API_BM_RT_ACT()
        ret = self.lib.ApiCmdBMRTActRead(handle, 0, rt, ctypes.byref(pact))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBMRTActRead failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        ambt.PY_TY_API_BM_RT_ACT.fromStruct(pact)

    def PyApiCmdBMRTSAActRead( self, handle, rt, sa, sa_type ):
        """ApiCmdBMRTSAActRead	Reads the BM transfer/error counters for a specified RT Subaddress"""
        pact = amb.TY_API_BM_RT_ACT()
        ret = self.lib.ApiCmdBMRTSAActRead(handle, 0, rt, sa, sa_type, ctypes.byref(pact))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBMRTSAActRead failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        ambt.PY_TY_API_BM_RT_ACT.fromStruct(pact)

    def PyApiCmdBMStart( self, handle ):
        """ApiCmdBMStart	Starts the chronological BM operation"""
        ret = self.lib.ApiCmdBMStart(handle, 0)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBMStart failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdBMStatusRead( self, handle ):
        """ApiCmdBMStatusRead	Reads the status of the BM"""
        pdsp = amb.TY_API_BM_STATUS_DSP()
        ret = self.lib.ApiCmdBMStatusRead(handle, 0, ctypes.byref(pdsp))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBMStatusRead failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return ambt.PY_TY_API_BM_STATUS_DSP.fromStruct(pdsp)

    def PyApiCmdBMSWXMIni( self, handle, swxm = 0x7FF ):
        """ApiCmdBMSWXMIni	Enables the bits in the BM Status Word Exception Mask to be used by the BM to check the status word for errors/exceptions"""
        ret = self.lib.ApiCmdBMSWXMIni(handle, 0, swxm)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBMSWXMIni failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
    
    def PyApiCmdBMTCBIni( self, handle, tid, ten, ptcb = ambt.PY_TY_API_BM_TCB() ):
        """ApiCmdBMTCBIni	Sets up the Trigger Control Block which defines the conditions evaluated by the BM to generate a Start/Stop Trigger Event """
        assert isinstance(ptcb, ambt.PY_TY_API_BM_TCB)
        ctypes_ptcb = ptcb.toStruct()
        ret = self.lib.ApiCmdBMTCBIni(handle, 0, tid, ten, ctypes.byref(ctypes_ptcb))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBMTCBIni failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
    
    def PyApiCmdBMTCIIni( self, handle, rt, sa, sa_type, tagm, tfct, tid ):
        """ApiCmdBMTCIIni	Defines the next Trigger Control Block to be evaluated for the next trigger"""
        ret = self.lib.ApiCmdBMTCIIni(handle, 0, rt, sa, sa_type, tagm, tfct, tid)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBMTCIIni failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
    
    def PyApiCmdBMTIWIni( self, handle, con, eti, aei, ti0, ti1 ):
        """ApiCmdBMTIWIni	Arms the BM with the Triggers to be evaluated """
        ret = self.lib.ApiCmdBMTIWIni(handle, 0, con, eti, aei, ti0, ti1)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdBMTIWIni failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
    
    def PyApiCmdDataQueueOpen( self, handle, id ):
        """ApiCmdDataQueueOpen	Creates a Data Queue on the ASP"""
        size = amb.AiUInt32(0)

        ret = self.lib.ApiCmdDataQueueOpen(handle, id, ctypes.byref(size))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdDataQueueOpen failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return size.value

    def PyApiCmdDataQueueClose( self, handle, id ):
        """ApiCmdDataQueueClose	Closes the Data Queue """
        ret = self.lib.ApiCmdDataQueueClose(handle, id)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdDataQueueClose failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdDataQueueRead( self, handle, data_queue_read = ambt.PY_TY_API_DATA_QUEUE_READ() ):
        """ApiCmdDataQueueRead	Reads from the Data Queue"""
        assert isinstance(data_queue_read, ambt.PY_TY_API_DATA_QUEUE_READ)
        ctypes_data_queue_read = data_queue_read.toStruct()
        ctypes_info = amb.TY_API_DATA_QUEUE_STATUS()

        buffer = array.array('B', [0] * data_queue_read.bytes_to_read)
        ctypes_data_queue_read.buffer = ctypes.cast(buffer.buffer_info()[0], ctypes.c_void_p)

        ret = self.lib.ApiCmdDataQueueRead(handle, ctypes.byref(ctypes_data_queue_read), ctypes.byref(ctypes_info))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdDataQueueRead failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return buffer.tobytes(), ambt.PY_TY_API_DATA_QUEUE_STATUS.fromStruct(ctypes_info)
    
    def PyApiCmdDataQueueControl( self, handle, id, mode ):
        """ApiCmdDataQueueControl	Starts/stops/resumes/flushes the Data Queue"""
        ret = self.lib.ApiCmdDataQueueControl(handle, id, mode)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdDataQueueControl failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdQueueFlush( self, handle):
        """ApiCmdQueueFlush	Flush the messages recorded while in Record with Queuing mode """
        ret = self.lib.ApiCmdQueueFlush(handle, 0)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdQueueFlush failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdQueueHalt( self, handle ):
        """ApiCmdQueueHalt	Stops queueing bus data to the Monitor buffer"""
        ret = self.lib.ApiCmdQueueHalt(handle, 0)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdQueueHalt failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdQueueIni( self, handle ):
        """ApiCmdQueueIni	Initializes the Record with Queueing process"""
        ret = self.lib.ApiCmdQueueIni(handle, 0)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdQueueIni failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdQueueRead(self, handle):
        """ApiCmdQueueRead	Reads from the Data Queue """
        qmesg = amb.TY_API_QUEUE_BUF()

        ret = self.lib.ApiCmdQueueRead(handle, 0, ctypes.byref(qmesg))

        if ret == amb.API_ERR_QUEUE_EMPTY:
            return None
        elif ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdQueueRead failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        else:
            return ambt.PY_TY_API_QUEUE_BUF.fromStruct(qmesg)
    
    def PyApiCmdQueueStart( self, handle ):
        """ApiCmdQueueStart	Starts queueing bus data to the Monitor buffer"""

        ret = self.lib.ApiCmdQueueStart(handle)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdQueueStart failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdScopeSetup( self, handle, px_ScopeSetup = ambt.PY_TY_API_SCOPE_SETUP() ):
        """ApiCmdScopeSetup	Setup and initialize the MIL-Scope"""
        assert isinstance( px_ScopeSetup, ambt.PY_TY_API_SCOPE_SETUP)
        ctypes_setup = px_ScopeSetup.toStruct()

        ret = self.lib.ApiCmdScopeSetup(handle, ctypes.byref(ctypes_setup))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdScopeSetup failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdScopeStart( self, handle ):
        """ApiCmdScopeStart	Start the APE MIL-Scope"""
        ret = self.lib.ApiCmdScopeStart(handle)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdScopeStart failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdScopeStatus( self, handle ):
        """ApiCmdScopeStatus	Status of the APE MIL-Scope"""
        p_ScopeStatus     = amb.AiUInt32(0) # Enum
        pulNumBuffersLeft = amb.AiUInt32(0)
        ret = self.lib.ApiCmdScopeStatus(handle, ctypes.byref(p_ScopeStatus), ctypes.byref(pulNumBuffersLeft))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdScopeStatus failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return p_ScopeStatus.value, pulNumBuffersLeft.value
    
    def PyApiCmdScopeStop( self, handle ):
        """ApiCmdScopeStop	Stop the APE-Mil-Scope"""
        ret = self.lib.ApiCmdScopeStop(handle)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdScopeStop failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
    
    def PyApiCmdScopeReset( self, handle ):
        """ApiCmdScopeReset	Reset the APE MIL-Scope"""
        ret = self.lib.ApiCmdScopeReset(handle)

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdScopeReset failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
    
    def PyApiCmdScopeOffsetCompensation( self, handle, ucMode ):
        """ApiCmdScopeOffsetCompensation	Perform an offset compensation on a APE MIL-Scope"""
        pxOffsets = amb.TY_API_SCOPE_OFFSETS()

        ret = self.lib.ApiCmdScopeOffsetCompensation(handle, ucMode, ctypes.byref(pxOffsets))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdScopeOffsetCompensation failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return ambt.PY_TY_API_SCOPE_OFFSETS.fromStruct(pxOffsets)
        
    def PyApiCmdScopeTriggerDefEx( self, handle, px_ScopeTrg = ambt.PY_TY_API_SCOPE_TRG_EX() ):
        """ApiCmdScopeTriggerDefEx	Define a trigger condition for the APX, ACX, APE MIL-Scope"""
        assert isinstance(px_ScopeTrg, ambt.PY_TY_API_SCOPE_TRG_EX )
        ctypes_px_ScopeTrg= px_ScopeTrg.toStruct()

        ret = self.lib.ApiCmdScopeTriggerDefEx(handle, ctypes.byref(ctypes_px_ScopeTrg))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdScopeTriggerDefEx failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
    def PyApiCreateScopeBuffer(self, handle, ulID, eBufferType, pBufferHandler):
        """Allocate a buffer to receive APE MIL-Scope data."""
        ctypes_pvUserData = ctypes.c_void_p(None) # Currently not supported
        self.lib.ApiCreateScopeBuffer.restype = ctypes.c_void_p
        buffer_address = self.lib.ApiCreateScopeBuffer(handle, ulID, eBufferType, pBufferHandler, ctypes_pvUserData )

        if buffer_address == 0:
            raise MilApiException(ambd.API_ERR, "Error: ApiCreateScopeBuffer failed.")

        return buffer_address

    def PyApiCreateScopeBufferList( self, handle, ulNumBuffers, pBufferHandler ):
        """ApiCreateScopeBufferList	Allocate a list of buffers to receive APE MIL-Scope data."""
        paxBufferList = (ctypes.c_void_p * ulNumBuffers)()
        ctypes_pvUserData = ctypes.c_void_p(None) # Currently not supported
        ret = self.lib.ApiCreateScopeBufferList(handle, ulNumBuffers, ctypes.byref(paxBufferList), pBufferHandler, ctypes_pvUserData )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCreateScopeBufferList failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        return [x for x in paxBufferList]

    def PyApiWaitForScopeFinished( self, handle, lTimeOut ):
        """ApiWaitForScopeFinished	Block the current execution thread until the data is available."""
        pWaitResultFlags= amb.AiUInt32(0)

        ret = self.lib.ApiWaitForScopeFinished(handle, lTimeOut, ctypes.byref(pWaitResultFlags))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiWaitForScopeFinished failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return pWaitResultFlags.value
    
    def PyApiProvideScopeBuffers( self, handle, axScopeBuffers):
        """ApiProvideScopeBuffers	Provide a list of scope buffers to the system driver."""
        paxBufferList = (ctypes.c_void_p * len(axScopeBuffers))()
        for i in range(len(axScopeBuffers)):
            paxBufferList[i] = axScopeBuffers[i]

        ret =  self.lib.ApiProvideScopeBuffers(handle, len(axScopeBuffers), ctypes.byref(paxBufferList))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiProvideScopeBuffers failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiFreeScopeBuffer(self, handle, px_Buffer):
        """ApiFreeScopeBuffer	Free a buffer scope data buffer."""
        ret =  self.lib.ApiFreeScopeBuffer(handle, ctypes.byref(ctypes.c_void_p(px_Buffer)))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiFreeScopeBuffer failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        

    '''
    DONE ApiCmdBMActRead	Reads BM Bus Activity transfer/error counters
    DONE ApiCmdBMCapMode	Configures the Capture/Recording mode of the BM
    SKIP ApiCmdBMDytagMonDef	Define a dytag monitor id
    SKIP ApiCmdBMDytagMonRead	Read the actual dytag monitor status
    DONE ApiCmdBMFilterIni	Disables the monitoring of specific RT SA/Mode codes 
    DONE ApiCmdBMFTWIni	Defines the bit pattern to be used by the BM to initiate a Start Trigger Event and/or Stop Trigger Event used for Start/Stop of the “Data Capture”
    DONE ApiCmdBMHalt	Starts the chronological BM operation
    DONE ApiCmdBMIllegalIni	Sets up the BM to tag/not tag illegal command transfers to specific RT SA/Mode codes
    DONE ApiCmdBMIni	Initializes the Bus Monitor
    SKIP ApiCmdBMIniMsgFltRec	Defines the command words used for filtering 1553 transfers to determine what data the BM will record when in Message Filter Recording Mode
    DONE ApiCmdBMIntrMode	Enables/disables the generation of interrupt and strobe outputs for various BM conditions
    SKIP ApiCmdBMReadMsgFltRec	Retrieves multiple 1553 message transfers from the Monitor Buffer in one of four special formats (for data recorded in Message Filter Recording Mode)
    DONE ApiCmdBMRTActRead	Reads the BM transfer/error counters for a specified RT
    DONE ApiCmdBMRTSAActRead	Reads the BM transfer/error counters for a specified RT Subaddress
    SKIP ApiCmdBMStackEntryFind	Finds a specific BM entry in the Monitor buffer
    SKIP ApiCmdBMStackEntryRead	Obtains information about a specific BM entry in the BM buffer
    SKIP ApiCmdBMStackpRead	Obtains the BM buffer pointers to be used to index into the Monitor Buffer to read entries
    DONE ApiCmdBMStart	Starts the chronological BM operation
    DONE ApiCmdBMStatusRead	Reads the status of the BM
    DONE ApiCmdBMSWXMIni	Enables the bits in the BM Status Word Exception Mask to be used by the BM to check the status word for errors/exceptions
    DONE ApiCmdBMTCBIni	Sets up the Trigger Control Block which defines the conditions evaluated by the BM to generate a Start/Stop Trigger Event 
    DONE ApiCmdBMTCIIni	Defines the next Trigger Control Block to be evaluated for the next trigger
    DONE ApiCmdBMTIWIni	Arms the BM with the Triggers to be evaluated 
    DONE ApiCmdDataQueueOpen	Creates a Data Queue on the ASP
    DONE ApiCmdDataQueueClose	Closes the Data Queue 
    DONE ApiCmdDataQueueRead	Reads from the Data Queue 
    DONE ApiCmdDataQueueControl	Starts/stops/resumes/flushes the Data Queue 
    DONE ApiCmdQueueFlush	Flush the messages recorded while in Record with Queuing mode 
    DONE ApiCmdQueueHalt	Stops queueing bus data to the Monitor buffer
    DONE ApiCmdQueueIni	Initializes the Record with Queueing process
    DONE ApiCmdQueueRead	Read a queued 1553 transfer message in the Monitor buffer
    DONE ApiCmdQueueStart	Starts queueing bus data to the Monitor buffer
    DONE ApiCmdScopeSetup	Setup and initialize the MIL-Scope
    DONE ApiCmdScopeStart	Start the APE MIL-Scope
    DONE ApiCmdScopeStatus	Status of the APE MIL-Scope
    DONE ApiCmdScopeStop	Stop the APE-Mil-Scope
    DONE ApiCmdScopeReset	Reset the APE MIL-Scope
    SKIP ApiCmdScopeCalibrate	Calibrate a APX, ACX MIL-Scope
    DONE ApiCmdScopeOffsetCompensation	Perform an offset compensation on a APE MIL-Scope
    SKIP ApiCmdScopeTriggerDef	Define a trigger condition for the APX, ACX MIL-Scope
    DONE ApiCmdScopeTriggerDefEx	Define a trigger condition for the APX, ACX, APE MIL-Scope
    DONE ApiCreateScopeBuffer	Allocate a buffer to receive APE MIL-Scope data.
    DONE ApiCreateScopeBufferList	Allocate a list of buffers to receive APE MIL-Scope data.
    DONE ApiFreeScopeBuffer	Free a buffer scope data buffer.
    DONE ApiProvideScopeBuffers	Provide a list of scope buffers to the system driver.
    DONE ApiWaitForScopeFinished	Block the current execution thread until the data is available.
    '''

    ###########################################################################
    #                                                                         #
    #                                Replay Functions                         #
    #                                                                         #
    ###########################################################################
    def PyApiCmdReplayIni( self, handle, alt, rlt, rint, fsize ):
        """ApiCmdReplayIni    Initializes Replay interrupts, Time tag replay and defines the size of the data to be replayed"""

        ret = self.lib.ApiCmdReplayIni( handle, 0, 1, 0, 0, 0, alt, rlt, rint, 0, 0, 1, fsize )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdReplayIni failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdReplayStart( self, handle ):
        """ApiCmdReplayStart    Starts the Replay of data in the Replay buffer"""

        ret = self.lib.ApiCmdReplayStart( handle, 0 )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdReplayStart failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdReplayStop( self, handle ):
        """ApiCmdReplayStop    Stops the Replay of data in the Replay buffer"""

        ret = self.lib.ApiCmdReplayStop( handle, 0 )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdReplayStop failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiCmdReplayStatus( self, handle ):
        """ApiCmdReplayStatus     Reads the status of the Replay activity"""
        prep = amb.TY_API_REP_STATUS()
        ret = self.lib.ApiCmdReplayStatus( handle, 0, ctypes.byref(prep) )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: PyApiCmdReplayStatus failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return ambt.PY_TY_API_REP_STATUS.fromStruct(prep)

    def PyApiCmdReplayRT( self, handle, con, mode, rt ):
        """ApiCmdReplayRT    Disables replay of one or more specific RT(s)"""
        ret = self.lib.ApiCmdReplayRT( handle, 0, con, mode, rt )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiCmdReplayRT failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

    def PyApiReadRecData( self, handle, size = 0x200000):
        """ApiReadRecData Provides for the storing of data recorded by the BM function to an application buffer"""
        api_rec_status = amb.TY_API_BM_REC()
        lp_Buf         = (amb.AiUInt8 * size)()
        l_BytesRead    = amb.AiUInt32()

        ret = self.lib.ApiReadRecData(handle, 0, ctypes.byref(api_rec_status), ctypes.byref(lp_Buf), ctypes.byref(l_BytesRead))

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiReadRecData failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))

        # data, PY_TY_API_BM_REC, pul_BytesRead
        if l_BytesRead.value < size:
            data = bytearray(lp_Buf)[0:l_BytesRead.value]
        else:
            data = bytearray(lp_Buf)
        return bytes(data), ambt.PY_TY_API_BM_REC.fromStruct(api_rec_status), l_BytesRead.value

    def PyApiWriteRepData( self, handle, api_rep_stat = ambt.PY_TY_API_REP_STATUS(), lpBuf = [] ):
        """ApiWriteRepData This function copies previously Bus Monitored recorded entries into the Replay area."""
        assert isinstance(api_rep_stat, ambt.PY_TY_API_REP_STATUS)
        c_api_rep_stat = api_rep_stat.toStruct() # in/out parameter
        c_replay_data = (amb.AiUInt8 * api_rep_stat.size)()
        c_data_written = amb.AiUInt32()
        
        for i in range(c_api_rep_stat.size):
            c_replay_data[i] = lpBuf[i]

        ret = self.lib.ApiWriteRepData( handle, 0, 
                                        ctypes.byref(c_api_rep_stat), 
                                        ctypes.byref(c_replay_data), 
                                        ctypes.byref(c_data_written) )

        if ret != amb.API_OK:
            raise MilApiException(ret, "Error: ApiWriteRepData failed with %x (%s)." % (ret, self.PyApiGetErrorMessage(ret)))
        
        return ambt.PY_TY_API_REP_STATUS.fromStruct(c_api_rep_stat), c_data_written.value 
    '''
    DONE ApiCmdReplayIni    Initializes Replay interrupts, Time tag replay and defines the size of the data to be replayed
    DONE ApiCmdReplayStart    Starts the Replay of data in the Replay buffer
    DONE ApiCmdReplayStop    Stops the Replay of data in the Replay buffer
    DONE ApiCmdReplayStatus     Reads the status of the Replay activity
    DONE ApiCmdReplayRT    Disables replay of one or more specific RT(s)
    DONE ApiWriteRepData
    '''
