# SPDX-FileCopyrightText: 2012-2024 AIM GmbH <info@aim-online.com>
# SPDX-License-Identifier: MIT

__version__ = '24.22.0'
