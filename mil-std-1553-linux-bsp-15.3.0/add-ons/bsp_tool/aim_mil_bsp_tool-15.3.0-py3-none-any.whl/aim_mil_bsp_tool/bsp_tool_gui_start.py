# SPDX-FileCopyrightText: 2024-2024 AIM GmbH <info@aim-online.com>
# SPDX-License-Identifier: MIT
import sys
from aim_mil_bsp_tool.bsp_tool_gui import main

if __name__ == '__main__':
    sys.exit(main())
    