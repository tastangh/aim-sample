# SPDX-FileCopyrightText: 2024-2024 AIM GmbH <info@aim-online.com>
# SPDX-License-Identifier: MIT

import os
import json
import sys
from PyQt5  import QtCore
from PyQt5.uic import loadUi
from PyQt5.QtWidgets import QMainWindow, QApplication, QTableWidgetItem, QListWidgetItem, QStyle, QMessageBox, QFileDialog, QInputDialog

from aim_mil import mil_bindings_defines as ambd
from aim_mil import mil_bindings_types as ambt
from aim_mil.mil_bindings_api import MilApi

from aim_mil_bsp_tool.__init__ import __version__ as BSP_TOOL_VERSION

name   = "BSP Tool GUI"


class BspVersionSpecs(object):
    def __init__(self, board, path="version_specs"):
        self._data = {}
        self._path = path
        self._config = board.device_config
        self._mlca   = board.get_novram_value(0x70)
        self.init_file_names()
        self.lookup_versions_from_json_dir()

    def init_file_names(self):
        if sys.platform.startswith("linux"):
            self._bsp_specs = "mil-linux-bsp.json"
        else:
            self._bsp_specs = "mil-windows-bsp.json"

        if self._config in (ambd.AI_PLATFORM_PCI_SHORT_ZYNQMP, ambd.AI_PLATFORM_PCI_E_1L_ZYNQMP, ambd.AI_PLATFORM_XMC_ZYNQMP, ambd.AI_PLATFORM_CPCIE_3U_ZYNQMP):
            self._onboard_spec = "apxx3910-update.json"
        elif self._config in (ambd.AI_PLATFORM_MINI_PCIE_CARD, ambd.AI_PLATFORM_MINI_PCIE_CARD_AP):
            self._onboard_spec = "ame1553-update.json"
        elif self._config == ambd.AI_PLATFORM_ASC:
            self._onboard_spec = "asc1553-update.json"
        elif self._config == ambd.AI_PLATFORM_USB3:
            self._onboard_spec = "asc1553-gen2-update.json"
        elif self._config == ambd.AI_PLATFORM_ANET_AYS:
            self._onboard_spec = "anet3910-update.json"
        elif self._config in (ambd.AI_PLATFORM_MINI_PCIE_ARTIX7, ambd.AI_PLATFORM_M2_B_M_ARTIX7, ambd.AI_PLATFORM_XMC_ARTIXUS):
            self._onboard_spec = "MLCA%4X_MERGE.json" % (self._mlca)
        else:
            self._onboard_spec = None

    def lookup_versions_from_json_dir(self):
        # First load the host versions
        try:
            with open(os.path.join(self._path, self._bsp_specs ), 'r') as fp:
                new = json.load(fp)
                self._data.update(new)
        except:
            pass

        # Second load the on-board package versions
        # Load second to over write versions that are also in the host versions. E.g. MIL-TSW
        try:
            if self._onboard_spec is not None:
                with open(os.path.join(self._path, self._onboard_spec ), 'r') as fp:
                    new = json.load(fp)
                    self._data.update(new)
        except:
            pass

    def version(self, name):
        return self._data[name]


class MilBoard(object):
    def __init__(self, pymilapi, id, url='local'):
        self._pymilapi = pymilapi
        self.versions   = []
        self.sn   = ""
        self.name = ""

        self._handle = pymilapi.PyApiOpenEx( ambt.PY_TY_API_OPEN(id, ambd.API_STREAM_1, url) )
        self.init_board_name()
        self.read_device_versions()
    
    def close(self):
        self._pymilapi.PyApiClose(self._handle)

    def init_board_name(self):
        self.sn   = self._pymilapi.PyApiCmdSysGetBoardInfo(self._handle, ambd.TY_BOARD_INFO_SERIAL)
        self.name = self._pymilapi.PyApiGetBoardName(self._handle)

    @property
    def device_group(self):
        info = self._pymilapi.PyApiGetDriverInfo(self._handle)
        return info.uc_DeviceGroup

    @property
    def device_config(self):
        info = self._pymilapi.PyApiCmdSysGetBoardInfo(self._handle, ambd.TY_BOARD_INFO_BOARD_CONFIG)
        return info & 0xFF

    def read_version(self, id):
        return self._pymilapi.PyApiReadVersion(self._handle, id )

    def read_device_versions(self):
        for id in range(ambd.AI_MAX_VERSIONS):
            version = self.read_version(id)
            if version is not None:
                self.versions.append(version)

    def get_novram_value(self, offset):
        return self._pymilapi.PyApiCmdUtility(self._handle, [1, offset] )



class BspVersionCheck(object):
    def __init__(self, board, bsp_version_specs):
        self.board = board
        self.version_specs = bsp_version_specs
        self.build_expected_versions_lookup()
        self.match_tables()

    def get_bip_name(self, offset):
        return "BIP_%04X" % self.board.get_novram_value(offset)

    def get_mlca_name(self, offset):
        return "MLCA%04X" % self.board.get_novram_value(offset)
    
    def get_kernel_name(self):
        if self.board.device_group is ambd.AI_DEVICE_ZYNQMP_ASP:
            return "Linux-XLNX-ZynqMP"
        elif self.board.device_group in (ambd.AI_DEVICE_AYS, ambd.AI_DEVICE_AYS_ASP):
            return "Linux-XLNX"
        else:
            return "Linux-AT91"

    def get_driver_name(self):
        if self.board.device_config in (ambd.AI_PLATFORM_USB, ambd.AI_PLATFORM_ASC, ambd.AI_PLATFORM_USB3):
            return "USB-Driver"
        else:
            return "PCI-Driver"

    def get_nvr_name(self, version_id):
        if version_id == ambd.AI_SYS_DRV_VER:
            return self.get_driver_name()
        if version_id == ambd.AI_FIRMWARE_VER_BIU1:
            return self.get_bip_name(0x80)
        if version_id == ambd.AI_FIRMWARE_VER_BIU2:
            return self.get_bip_name(0x84)
        if version_id == ambd.AI_MAIN_LCA_VER:
            return self.get_mlca_name(0x70)
        if version_id in (ambd.AI_MAIN_LCA_VER, ambd.AI_FPGA_VER):
            return self.get_mlca_name(0x70)
        if version_id == ambd.AI_TARGET_OS_VER:
            return self.get_kernel_name()
        

    def name(self, version_id):
        '''Convert the version_id into the BSP component name'''

        # easy cases first
        if version_id == ambd.AI_ANS_VER:
            return "ANS1553"
        if version_id in (ambd.AI_DLL_VER, ambd.AI_REMOTE_DLL_VER):
            return "MIL-API"
        if version_id == ambd.AI_TARGET_VER:
            return "MIL-TSW"

        return self.get_nvr_name(version_id)

    def build_expected_versions_lookup(self):
        for version in self.board.versions:
            n = self.name(version.ul_VersionType)
            try:
                expected = self.version_specs.version(n)
                if "/" in expected:
                    expected = expected.split("/")[-1]
                version.expected = expected
            except:
                version.expected =  ""

    def match_tables(self):
        self._bsp_status = True
        for version in self.board.versions:
            if version.expected != "":
                if version.ac_FullVersion == version.expected:  
                    version.match    =  "True"
                else:
                    version.match    =  "False"
                    self._bsp_status = False
            else:
                version.match    =  ""



class BspVersionUi(QMainWindow):
    def __init__(self, parent=None):
        super(BspVersionUi, self).__init__(parent)

        self.bsp_dir_selector()

        ui = os.path.join(os.path.dirname(__file__), "bsp_tool_gui.ui")
        loadUi(ui, self)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose) 
        self.setWindowTitle('%s %s' % (name, BSP_TOOL_VERSION))
        self.ok_icon = self.style().standardIcon(QStyle.SP_DialogApplyButton)
        self.error_icon = self.style().standardIcon(QStyle.SP_MessageBoxWarning)

        self.bsp_version = ""
        self.data = []        
        self.num_devices = 0
        self.init_local_boards()

        self.deviceSelector.currentRowChanged.connect(self.update_table)
        self.addButton.clicked.connect(self.add_anet)
        self.closeButton.clicked.connect(self.close)

        if self.num_devices > 0:
            self.init_device_selector(0)
            self.update_table(0)
        else:
            # Open empty GUI to be able to add ANET devices
            pass
        self.statusbar.showMessage(self.bsp_version)

    def message_box( self, text ):
        msgBox = QMessageBox()
        msgBox.setIcon(QMessageBox.Information)
        msgBox.setText(text)
        msgBox.setWindowTitle(name)
        msgBox.setStandardButtons(QMessageBox.Ok)
        msgBox.buttonClicked.connect(self.close)
        msgBox.setAttribute(QtCore.Qt.WA_DeleteOnClose) 
        msgBox.exec()
        sys.exit(0)

    def bsp_dir_selector( self ):
        # Get BSP root directory
        self._bsp_dir = str(QFileDialog.getExistingDirectory(self, "Select BSP directory", os.getcwd()))
        print(self._bsp_dir)

        if self._bsp_dir == "":
            # Abort if no BSP directory has been selected
            sys.exit(0)

        # find version_specs sub folder
        version_specs = ""
        for root, d_names, _ in os.walk(self._bsp_dir):
            for d in d_names:
                if d == "version_specs":
                    version_specs = os.path.join(root,d)

        if version_specs == "":
            self.message_box("No valid BSP directory.\nPlease note that the required version specification files are only included in BSP 15.3.0 and newer.")

        # store path to json files
        self._bsp_dir = version_specs

    def init_local_boards(self):
        pymilapi = MilApi()

        try:
            self.num_devices = pymilapi.PyApiInit()
        except:
            self.num_devices = 0

        if self.num_devices > 0:
            for id in range(self.num_devices):
                board = MilBoard(pymilapi, id)
                vs = BspVersionSpecs(board, self._bsp_dir)
                self.bsp_version = "Expected versions for BSP " + vs.version("skeleton")
                self.data.append(BspVersionCheck(board, vs))
                board.close()

        pymilapi.PyApiExit()

    def add_anet(self):
        pymilapi = MilApi()
        
        url, _ = QInputDialog.getText(self, name, 'Enter ANET IP address or network name:') 

        try:
            anet_devices = pymilapi.PyApiConnectToServer(url)
        except:
            anet_devices = 0

        if anet_devices > 0:
            for id in range(anet_devices):
                board = MilBoard(pymilapi, id, url)
                vs = BspVersionSpecs(board, self._bsp_dir)
                self.bsp_version = "Expected versions for BSP " + vs.version("skeleton")
                self.data.append(BspVersionCheck(board, vs))
                self.num_devices += 1
                board.close()
            self.update_table(self.num_devices - 1)
            self.init_device_selector(self.num_devices - 1)
            self.statusbar.showMessage(self.bsp_version)
            pymilapi.PyApiDisconnectFromServer(url)

    def init_device_selector(self, index):
        self.deviceSelector.clear()
        for i, value in enumerate(self.data):
            icon = self.ok_icon if value._bsp_status else self.error_icon
            self.deviceSelector.addItem( QListWidgetItem(icon, "%2d: %s (SN %s)" % (i, value.board.name, value.board.sn)) )
        if len(self.data)>0:
            self.deviceSelector.setCurrentRow(index)

    def update_table(self, index):
        versions = self.data[index].board.versions
        self.data_table.setRowCount(len(versions))
        for i, v in enumerate(versions):
            self.data_table.setItem( i, 0, QTableWidgetItem(str(v.ul_VersionType)) )
            self.data_table.setItem( i, 1, QTableWidgetItem(str(v.ac_Description)) )
            self.data_table.setItem( i, 2, QTableWidgetItem(str(v.ac_FullVersion)) )
            self.data_table.setItem( i, 3, QTableWidgetItem(str(v.expected)) )
            self.data_table.setItem( i, 4, QTableWidgetItem(str(v.match)) )


def main():
    app = QApplication(sys.argv)
    form = BspVersionUi()
    form.show()
    app.exec_()

